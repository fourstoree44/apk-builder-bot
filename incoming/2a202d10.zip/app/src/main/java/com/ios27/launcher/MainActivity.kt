package com.ios27.launcher

import android.app.Activity
import android.app.ActivityOptions
import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioManager
import android.hardware.camera2.CameraManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.app.AlertDialog
import android.app.Dialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Button
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var scroller: PagerScroller
    private lateinit var pagesRow: LinearLayout
    private lateinit var dotsRow: LinearLayout
    private lateinit var bottomBox: LinearLayout
    private lateinit var dockBox: LinearLayout
    private lateinit var island: DynamicIslandView
    private lateinit var search: SearchOverlay
    private lateinit var widgetColumn: LinearLayout
    private val appWidgetHost by lazy { AppWidgetHost(this, APP_WIDGET_HOST_ID) }
    private val hostedWidgetViews = mutableMapOf<Int, AppWidgetHostView>()
    private var pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    private var apps: List<AppEntry> = emptyList()
    private var dockApps: List<AppEntry> = emptyList()
    private var widgetBattery: TextView? = null
    private val iconCache = ConcurrentHashMap<String, Bitmap>()

    private val screenW by lazy { resources.displayMetrics.widthPixels }
    private val screenH by lazy { resources.displayMetrics.heightPixels }
    private val prefs by lazy { getSharedPreferences("island", MODE_PRIVATE) }

    private var navInset = 0
    private var statusInset = 0
    private var pageCount = 1
    private var batteryLevel = 100
    private var charging = false
    private var batteryKnown = false

    // ---------------------------------------------------------------- pager

    inner class PagerScroller(ctx: Context) : HorizontalScrollView(ctx) {
        private var flung = false

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) flung = false
            val r = super.onTouchEvent(ev)
            if ((ev.actionMasked == MotionEvent.ACTION_UP ||
                    ev.actionMasked == MotionEvent.ACTION_CANCEL) && !flung) snapNearest()
            return r
        }

        override fun fling(velocityX: Int) {
            flung = true
            val p = scrollX.toFloat() / screenW
            val target = when {
                velocityX > 600 -> Math.floor(p.toDouble()).toInt() + 1
                velocityX < -600 -> Math.ceil(p.toDouble()).toInt() - 1
                else -> Math.round(p)
            }
            smoothScrollTo(target.coerceIn(0, pageCount - 1) * screenW, 0)
        }

        fun snapNearest() {
            val i = Math.round(scrollX.toFloat() / screenW).coerceIn(0, pageCount - 1)
            smoothScrollTo(i * screenW, 0)
        }
    }

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.isNavigationBarContrastEnforced = false

        root = FrameLayout(this)
        setContentView(root)
        applySavedWallpaper()

        scroller = PagerScroller(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setOnScrollChangeListener { _, x, _, _, _ -> updateDots((x + screenW / 2) / screenW) }
        }
        pagesRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        scroller.addView(pagesRow, FrameLayout.LayoutParams(WRAP, MATCH))
        root.addView(scroller, FrameLayout.LayoutParams(MATCH, MATCH))

        bottomBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        dotsRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        bottomBox.addView(dotsRow, LinearLayout.LayoutParams(WRAP, dp(16)))

        val searchPill = TextView(this).apply {
            text = "Search"
            textSize = 14f
            setTextColor(Color.parseColor("#E5E5EA"))
            gravity = Gravity.CENTER
            background = glass(18)
            setPadding(dp(34), 0, dp(34), 0)
            softShadow()
            setOnClickListener { search.show(apps, null, null) }
        }
        bottomBox.addView(searchPill, LinearLayout.LayoutParams(WRAP, dp(36)).apply {
            topMargin = dp(4); bottomMargin = dp(10)
        })

        dockBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = glass(32)
            setPadding(dp(10), 0, dp(10), 0)
        }
        bottomBox.addView(dockBox, LinearLayout.LayoutParams(MATCH, dp(92)).apply {
            marginStart = dp(16); marginEnd = dp(16)
        })
        root.addView(bottomBox, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))

        island = DynamicIslandView(this)
        root.addView(island, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        applyIslandPosition()

        // Tombol pengaturan selalu terlihat di Home.
        val settingsButton = TextView(this).apply {
            text = "⚙"
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = glass(18)
            contentDescription = "Pengaturan rzkylauncher"
            isClickable = true
            isFocusable = true
            setOnClickListener { showSettingsDashboard() }
        }
        root.addView(settingsButton, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(42)
            marginEnd = dp(14)
        })

        search = SearchOverlay(this, root, { app, px -> iconFor(app, px) }, { app, v -> launch(app, v) })

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val nav = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            if (nav != navInset || top != statusInset) {
                navInset = nav; statusInset = top
                rebuild()
            }
            insets
        }

        ContextCompat.registerReceiver(this, pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }, ContextCompat.RECEIVER_EXPORTED)
        reloadApps()
        askOverlayPermissionOnce()
    }

    override fun onResume() {
        super.onResume()
        try {
            appWidgetHost.startListening()
            registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        } catch (e: Exception) {
            android.util.Log.w("rzkylauncher", "Widget/battery listener could not start", e)
        }
        applyIslandMode()
    }

    override fun onPause() {
        try { unregisterReceiver(batteryReceiver) } catch (e: Exception) {
            android.util.Log.d("rzkylauncher", "Battery receiver already stopped", e)
        }
        try { appWidgetHost.stopListening() } catch (e: Exception) {
            android.util.Log.d("rzkylauncher", "Widget host already stopped", e)
        }
        super.onPause()
    }

    override fun onDestroy() {
        try { unregisterReceiver(pkgReceiver) } catch (e: Exception) {}
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) {
            search.close()
            island.setState(DynamicIslandView.State.COLLAPSED)
            scroller.smoothScrollTo(0, 0)
        }
    }

    @Deprecated("Launcher tidak keluar dengan tombol back")
    override fun onBackPressed() {
        if (search.isShowing) search.close() else scroller.smoothScrollTo(0, 0)
    }

    // ---------------------------------------------------------------- data

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { reloadApps() }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val nowCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            val changed = batteryKnown && nowCharging != charging
            batteryLevel = if (scale > 0) level * 100 / scale else level
            charging = nowCharging
            batteryKnown = true
            island.batteryLevel = batteryLevel
            island.charging = charging
            if (changed) island.pulse()
            widgetBattery?.text =
                if (charging) "⚡ Mengisi daya · $batteryLevel%" else "Baterai $batteryLevel%"
        }
    }

    private fun reloadApps() {
        Thread {
            val list = loadApps(this)
            val dock = resolveDock(this, list)
            (list + dock).forEach { iconFor(it, dp(60)) }
            runOnUiThread { apps = list; dockApps = dock; rebuild() }
        }.start()
    }

    private fun iconFor(app: AppEntry, px: Int): Bitmap =
        iconCache.getOrPut("${app.component.flattenToString()}:$px") { makeIcon(this, app, px) }

    private fun launch(app: AppEntry, from: View) {
        val i = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = app.component
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
        }
        try {
            val opts = ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height)
            startActivity(i, opts.toBundle())
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak bisa membuka ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------------ UI

    private fun rebuild() {
        if (apps.isEmpty()) return
        (bottomBox.layoutParams as FrameLayout.LayoutParams).bottomMargin = navInset + dp(8)
        bottomBox.requestLayout()
        buildDock()
        buildPages()
    }

    private fun buildDock() {
        dockBox.removeAllViews()
        dockApps.forEach { dockBox.addView(appCell(it, prefs.getInt("icon_size", 60), false), LinearLayout.LayoutParams(0, MATCH, 1f)) }
    }

    private fun buildPages() {
        pagesRow.removeAllViews()
        val rowH = dp(96)
        val topPad = statusInset + dp(14)
        val bottomPad = dp(176) + navInset
        val rows = ((screenH - topPad - bottomPad) / rowH).coerceIn(4, 7)
        val dockPkgs = dockApps.map { it.pkg }.toSet()
        val grid = apps.filter { it.pkg !in dockPkgs }

        var idx = 0
        var n = 0
        while (idx < grid.size || n == 0) {
            val capacity = (rows - if (n == 0) 2 else 0) * 4
            val slice = grid.subList(idx, minOf(idx + capacity, grid.size))
            pagesRow.addView(gridPage(slice, n == 0, rowH, topPad, bottomPad), LinearLayout.LayoutParams(screenW, MATCH))
            idx += capacity
            n++
        }
        pagesRow.addView(libraryPage(grid, topPad, bottomPad), LinearLayout.LayoutParams(screenW, MATCH))
        pagesRow.addView(widgetsPage(topPad, bottomPad), LinearLayout.LayoutParams(screenW, MATCH))
        pageCount = n + 2
        buildDots(pageCount)
    }

    private fun gridPage(list: List<AppEntry>, withWidget: Boolean, rowH: Int, topPad: Int, bottomPad: Int): View {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), topPad, dp(14), bottomPad)
            isLongClickable = true
            setOnLongClickListener { showHomeMenu(); true }
        }
        if (withWidget) page.addView(widgetCard(rowH), LinearLayout.LayoutParams(MATCH, rowH * 2 - dp(12)).apply {
            marginStart = dp(6); marginEnd = dp(6); bottomMargin = dp(12)
        })
        list.chunked(4).forEach { rowApps ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowApps.forEach { row.addView(appCell(it, prefs.getInt("icon_size", 60), true), LinearLayout.LayoutParams(0, MATCH, 1f)) }
            repeat(4 - rowApps.size) { row.addView(View(this), LinearLayout.LayoutParams(0, MATCH, 1f)) }
            page.addView(row, LinearLayout.LayoutParams(MATCH, rowH))
        }
        return page
    }

    private fun widgetCard(rowH: Int): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            background = glass(26)
            setPadding(dp(22), dp(10), dp(22), dp(10))
        }
        card.addView(TextClock(this).apply {
            format24Hour = "HH:mm"; format12Hour = "HH:mm"
            textSize = 54f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }, LinearLayout.LayoutParams(WRAP, WRAP))
        card.addView(TextClock(this).apply {
            format24Hour = "EEEE, d MMMM"; format12Hour = "EEEE, d MMMM"
            textSize = 16f
            setTextColor(Color.parseColor("#E5E5EA"))
        }, LinearLayout.LayoutParams(WRAP, WRAP))
        widgetBattery = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#AEAEB2"))
            text = if (charging) "⚡ Mengisi daya · $batteryLevel%" else "Baterai $batteryLevel%"
        }
        card.addView(widgetBattery, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(4) })

        val quickRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(2))
        }
        val quickActions = listOf(
            "Wi-Fi" to Settings.ACTION_WIFI_SETTINGS,
            "Bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
            "Layar" to Settings.ACTION_DISPLAY_SETTINGS,
            "Suara" to Settings.ACTION_SOUND_SETTINGS
        )
        quickActions.forEach { (label, action) ->
            val chip = TextView(this).apply {
                text = label
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = glass(14)
                setPadding(dp(9), dp(7), dp(9), dp(7))
                setOnClickListener {
                    try { this@MainActivity.startActivity(Intent(action)) } catch (e: Exception) {
                        Toast.makeText(this@MainActivity, "Pengaturan tidak tersedia", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            quickRow.addView(chip, LinearLayout.LayoutParams(0, WRAP, 1f).apply {
                marginEnd = dp(5)
            })
        }
        card.addView(quickRow, LinearLayout.LayoutParams(MATCH, WRAP))

        val photoUri = prefs.getString("photo_widget_uri", null)
        val photoRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        val photo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = glass(12)
            clipToOutline = true
            if (photoUri != null) {
                try {
                    contentResolver.openInputStream(Uri.parse(photoUri))?.use { setImageBitmap(BitmapFactory.decodeStream(it)) }
                } catch (e: Exception) {}
            }
            setOnClickListener { openImagePicker(REQUEST_PHOTO_WIDGET) }
        }
        photoRow.addView(photo, LinearLayout.LayoutParams(dp(54), dp(54)))
        photoRow.addView(TextView(this).apply {
            text = if (photoUri == null) "  Tambahkan foto dari Galeri" else "  Foto pilihan kamu"
            textSize = 13f
            setTextColor(Color.parseColor("#E5E5EA"))
            setOnClickListener { openImagePicker(REQUEST_PHOTO_WIDGET) }
        }, LinearLayout.LayoutParams(WRAP, WRAP))
        card.addView(photoRow, LinearLayout.LayoutParams(MATCH, WRAP))
        return card
    }

    private fun widgetsPage(topPad: Int, bottomPad: Int): View {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), topPad + dp(12), dp(18), bottomPad)
        }
        page.addView(TextView(this).apply {
            text = "Widget"
            textSize = 30f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            setShadowLayer(dp(3).toFloat(), 0f, dp(1).toFloat(), Color.BLACK)
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) })

        val add = TextView(this).apply {
            text = "＋  Tambah widget"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = glass(18)
            setPadding(dp(16), dp(13), dp(16), dp(13))
            setOnClickListener { pickWidget() }
        }
        page.addView(add, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(14) })

        widgetColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(8))
        }
        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(widgetColumn, FrameLayout.LayoutParams(MATCH, WRAP))
        }
        page.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        restoreHostedWidgets()
        return page
    }

    private fun pickWidget() {
        val widgetId = try { appWidgetHost.allocateAppWidgetId() } catch (e: Exception) {
            Toast.makeText(this, "Widget tidak dapat disiapkan", Toast.LENGTH_SHORT).show()
            return
        }
        pendingWidgetId = widgetId
        val pickIntent = Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).apply {
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
        }
        try {
            startActivityForResult(pickIntent, REQUEST_PICK_WIDGET)
        } catch (e: Exception) {
            appWidgetHost.deleteAppWidgetId(widgetId)
            pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
            Toast.makeText(this, "Pemilih widget tidak tersedia", Toast.LENGTH_SHORT).show()
        }
    }

    private fun attachWidget(widgetId: Int) {
        val manager = AppWidgetManager.getInstance(this)
        val info: AppWidgetProviderInfo = manager.getAppWidgetInfo(widgetId) ?: run {
            appWidgetHost.deleteAppWidgetId(widgetId)
            return
        }
        try {
            val hostView = appWidgetHost.createView(this, widgetId, info)
            hostView.setAppWidget(widgetId, info)
            hostView.setPadding(dp(4), dp(4), dp(4), dp(4))
            hostView.setOnLongClickListener {
                AlertDialog.Builder(this)
                    .setTitle("Hapus widget?")
                    .setMessage("Widget ini akan dilepas dari rzkylauncher.")
                    .setNegativeButton("Batal", null)
                    .setPositiveButton("Hapus") { _, _ ->
                        widgetColumn.removeView(hostView)
                        hostedWidgetViews.remove(widgetId)
                        appWidgetHost.deleteAppWidgetId(widgetId)
                        removeStoredWidgetId(widgetId)
                        restoreHostedWidgets()
                    }
                    .show()
                true
            }
            hostedWidgetViews[widgetId] = hostView
            if (::widgetColumn.isInitialized) {
                widgetColumn.addView(hostView, LinearLayout.LayoutParams(MATCH, WRAP).apply {
                    bottomMargin = dp(12)
                })
            }
            val ids = getSharedPreferences("island", MODE_PRIVATE)
                .getStringSet(KEY_WIDGET_IDS, emptySet())?.toMutableSet() ?: mutableSetOf()
            ids.add(widgetId.toString())
            getSharedPreferences("island", MODE_PRIVATE).edit()
                .putStringSet(KEY_WIDGET_IDS, ids).apply()
        } catch (e: Exception) {
            android.util.Log.e("rzkylauncher", "Failed to attach widget id=$widgetId", e)
            appWidgetHost.deleteAppWidgetId(widgetId)
            Toast.makeText(this, "Widget gagal dimuat", Toast.LENGTH_SHORT).show()
        }
    }

    private fun restoreHostedWidgets() {
        if (!::widgetColumn.isInitialized) return
        widgetColumn.removeAllViews()
        hostedWidgetViews.clear()
        val ids = getSharedPreferences("island", MODE_PRIVATE)
            .getStringSet(KEY_WIDGET_IDS, emptySet())?.toList().orEmpty()
        ids.forEach { raw ->
            val id = raw.toIntOrNull() ?: return@forEach
            val info = AppWidgetManager.getInstance(this).getAppWidgetInfo(id)
            if (info == null) {
                removeStoredWidgetId(id)
            } else {
                try {
                    val hostView = appWidgetHost.createView(this, id, info)
                    hostView.setAppWidget(id, info)
                    hostView.setOnLongClickListener {
                        AlertDialog.Builder(this)
                            .setTitle("Hapus widget?")
                            .setMessage("Widget ini akan dilepas dari rzkylauncher.")
                            .setNegativeButton("Batal", null)
                            .setPositiveButton("Hapus") { _, _ ->
                                appWidgetHost.deleteAppWidgetId(id)
                                removeStoredWidgetId(id)
                                restoreHostedWidgets()
                            }
                            .show()
                        true
                    }
                    hostedWidgetViews[id] = hostView
                    widgetColumn.addView(hostView, LinearLayout.LayoutParams(MATCH, WRAP).apply {
                        bottomMargin = dp(12)
                    })
                } catch (e: Exception) {
                    android.util.Log.w("rzkylauncher", "Skipping unavailable widget $id", e)
                }
            }
        }
        if (widgetColumn.childCount == 0) {
            widgetColumn.addView(TextView(this).apply {
                text = """Widget dari aplikasi Android kamu akan muncul di sini.

Tekan Tambah widget untuk memilih jam, kalender, musik, cuaca, dan widget lain yang tersedia."""
                textSize = 14f
                setTextColor(Color.parseColor("#E5E5EA"))
                gravity = Gravity.CENTER
                background = glass(22)
                setPadding(dp(24), dp(28), dp(24), dp(28))
            }, LinearLayout.LayoutParams(MATCH, WRAP))
        }
    }

    private fun removeStoredWidgetId(id: Int) {
        val prefs = getSharedPreferences("island", MODE_PRIVATE)
        val ids = prefs.getStringSet(KEY_WIDGET_IDS, emptySet())?.toMutableSet() ?: mutableSetOf()
        ids.remove(id.toString())
        prefs.edit().putStringSet(KEY_WIDGET_IDS, ids).apply()
    }

    private fun libraryPage(grid: List<AppEntry>, topPad: Int, bottomPad: Int): View {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), topPad, dp(14), bottomPad)
        }
        page.addView(TextView(this).apply {
            text = getString(R.string.app_library)
            textSize = 16f
            setTextColor(Color.parseColor("#E5E5EA"))
            gravity = Gravity.CENTER_VERTICAL
            background = glass(14)
            setPadding(dp(16), 0, dp(16), 0)
            softShadow()
            setOnClickListener { search.show(apps, null, null) }
        }, LinearLayout.LayoutParams(MATCH, dp(44)).apply { bottomMargin = dp(14) })

        val groups = grid.groupBy { categoryName(it) }
        val names = CATEGORY_ORDER.filter { it in groups }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        names.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { name ->
                row.addView(libraryCard(name, groups.getValue(name)),
                    LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(6), 0, dp(6), dp(14)) })
            }
            if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            body.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        page.addView(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
        }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return page
    }

    private fun libraryCard(name: String, list: List<AppEntry>): View {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(24)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { search.show(apps, name, list) }
        }
        list.take(4).chunked(2).forEach { two ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_HORIZONTAL }
            two.forEach { app ->
                val cell = appCell(app, 52, false)
                r.addView(cell, LinearLayout.LayoutParams(0, dp(66), 1f))
            }
            if (two.size == 1) r.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            panel.addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        card.addView(panel, LinearLayout.LayoutParams(MATCH, WRAP))
        card.addView(TextView(this).apply {
            text = name
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            softShadow()
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        return card
    }

    private fun appCell(app: AppEntry, iconDp: Int, label: Boolean): View {
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (label) Gravity.TOP or Gravity.CENTER_HORIZONTAL else Gravity.CENTER
            setPadding(0, if (label) dp(6) else 0, 0, 0)
        }
        val iv = ImageView(this).apply { setImageBitmap(iconFor(app, dp(iconDp))) }
        cell.addView(iv, LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)))
        if (label) {
            cell.addView(TextView(this).apply {
                text = app.label
                textSize = 11f
                maxLines = 1
                gravity = Gravity.CENTER
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(Color.WHITE)
                softShadow()
            }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6); marginStart = dp(2); marginEnd = dp(2) })
        }
        cell.setOnClickListener { launch(app, iv) }
        cell.setOnLongClickListener { showAppMenu(iv, app); true }
        return cell
    }

    private fun buildDots(n: Int) {
        dotsRow.removeAllViews()
        repeat(n) {
            val dot = View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
                alpha = 0.4f
            }
            dotsRow.addView(dot, LinearLayout.LayoutParams(dp(7), dp(7)).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        updateDots((scroller.scrollX + screenW / 2) / screenW)
    }

    private fun updateDots(sel: Int) {
        for (i in 0 until dotsRow.childCount) dotsRow.getChildAt(i).alpha = if (i == sel) 1f else 0.4f
    }

    // ---------------------------------------------------------------- menus

    private fun showAppMenu(anchor: View, app: AppEntry) {
        PopupMenu(this, anchor).apply {
            menu.add(0, 1, 0, "Info aplikasi")
            menu.add(0, 2, 1, "Copot pemasangan")
            setOnMenuItemClickListener {
                val uri = Uri.parse("package:${app.pkg}")
                when (it.itemId) {
                    1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                    2 -> startActivity(Intent(Intent.ACTION_DELETE, uri))
                }
                true
            }
            show()
        }
    }

    private fun overlayEnabled() = Settings.canDrawOverlays(this) && prefs.getBoolean("overlay_enabled", true)

    /** Dashboard Settings rzkylauncher: panel internal + pintasan Settings Android. */
    private fun showSettingsDashboard() {
        val dialog = Dialog(this)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(18))
            setBackgroundColor(Color.rgb(13, 15, 22))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        heading.addView(TextView(this).apply {
            text = "RZKYLAUNCHER"
            textSize = 11f
            letterSpacing = 0.16f
            setTextColor(Color.rgb(150, 170, 210))
        })
        heading.addView(TextView(this).apply {
            text = "Pengaturan"
            textSize = 29f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.WHITE)
        })
        heading.addView(TextView(this).apply {
            text = "Atur tampilan launcher dan akses pengaturan perangkat"
            textSize = 12f
            setTextColor(Color.rgb(174, 178, 190))
        })
        header.addView(heading, LinearLayout.LayoutParams(0, WRAP, 1f))
        val close = TextView(this).apply {
            text = "✕"
            textSize = 19f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = glass(18)
            isClickable = true
            setOnClickListener { dialog.dismiss() }
        }
        header.addView(close, LinearLayout.LayoutParams(dp(42), dp(42)))
        page.addView(header, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(18) })

        val scroll = ScrollView(this).apply { isFillViewport = false; isVerticalScrollBarEnabled = false }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content, FrameLayout.LayoutParams(MATCH, WRAP))

        fun section(label: String, note: String? = null) {
            content.addView(TextView(this).apply {
                text = label.uppercase()
                textSize = 11f
                letterSpacing = 0.12f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setTextColor(Color.rgb(145, 160, 190))
            }, LinearLayout.LayoutParams(MATCH, WRAP).apply {
                topMargin = dp(18); bottomMargin = dp(8)
            })
            if (note != null) content.addView(TextView(this).apply {
                text = note
                textSize = 11f
                setTextColor(Color.rgb(150, 154, 166))
            }, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
        }

        fun row(icon: String, title: String, detail: String, action: () -> Unit) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(11), dp(12), dp(11))
                background = glass(17)
                isClickable = true
                isFocusable = true
                setOnClickListener { action() }
            }
            val glyph = TextView(this).apply {
                text = icon
                textSize = 19f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = GradientDrawable().apply {
                    cornerRadius = dp(12).toFloat()
                    setColor(Color.argb(65, 105, 145, 235))
                }
            }
            item.addView(glyph, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(12) })
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            labels.addView(TextView(this).apply {
                text = title
                textSize = 14f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setTextColor(Color.WHITE)
            })
            labels.addView(TextView(this).apply {
                text = detail
                textSize = 11f
                setTextColor(Color.rgb(174, 178, 190))
                maxLines = 2
            }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(3) })
            item.addView(labels, LinearLayout.LayoutParams(0, WRAP, 1f))
            item.addView(TextView(this).apply {
                text = "›"
                textSize = 25f
                setTextColor(Color.rgb(160, 165, 180))
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(22), WRAP))
            content.addView(item, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
        }

        section("Personalisasi", "Semua pengaturan tampilan rzkylauncher ada di sini.")
        row("◈", "Home Screen & ikon", "Ukuran ikon, tata letak, dan tampilan aplikasi") { dialog.dismiss(); showDisplaySettings() }
        row("▧", "Wallpaper & foto", "Pilih wallpaper atau foto dari galeri") { dialog.dismiss(); openImagePicker(REQUEST_WALLPAPER) }
        row("▦", "Widget Android", "Tambahkan widget yang disediakan aplikasi lain") { dialog.dismiss(); pickWidget() }
        row("◫", "App Library", "Lihat semua aplikasi yang terpasang") { dialog.dismiss(); scroller.smoothScrollTo((pageCount - 2).coerceAtLeast(0) * screenW, 0) }
        row("✧", "Dynamic Glass & Blur", if (android.os.Build.VERSION.SDK_INT >= 33) "Efek kaca dan transparansi · Android 13+" else "Mode transparan standar pada perangkat ini") { dialog.dismiss(); showGlassSettings() }
        row("☷", "Warna aksen & tema", "Pilih warna utama tampilan launcher") { dialog.dismiss(); showAccentSettings() }

        section("Kontrol & navigasi")
        row("⌁", "Control Center", "Akses cepat volume, senter, Wi-Fi, Bluetooth, dan layar") { dialog.dismiss(); showControlCenter() }
        row("●", "Dynamic Island", "Atur overlay, posisi, dan izin tampilan") {
            dialog.dismiss()
            val islandItems = arrayOf(
                if (overlayEnabled()) "Matikan Dynamic Island" else "Aktifkan Dynamic Island",
                "Geser posisi ke bawah", "Geser posisi ke atas", "Atur izin overlay"
            )
            AlertDialog.Builder(this).setTitle("Dynamic Island").setItems(islandItems) { _, action ->
                when (action) { 0 -> toggleOverlay(); 1 -> moveIsland(4); 2 -> moveIsland(-4); 3 -> showLauncherPermissions() }
            }.setNegativeButton("Tutup", null).show()
        }
        row("▣", "Lock Screen", "Pratinjau jam dan tanggal gaya iPhone") { dialog.dismiss(); showLockScreenPreview() }
        row("⇆", "Navigasi & gesture", "Swipe halaman, App Library, dan pintasan navigasi Android") { dialog.dismiss(); showNavigationSettings() }
        row("✓", "Izin rzkylauncher", "Atur launcher default, overlay, dan notifikasi") { dialog.dismiss(); showLauncherPermissions() }

        section("Pengaturan perangkat", "Bagian ini membuka halaman Settings resmi Android. Launcher tidak mengubah tombol sistem atau pengaturan keamanan secara paksa.")
        row("⚙", "Settings Android", "Buka aplikasi Pengaturan perangkat") { dialog.dismiss(); openAndroidSettings(Settings.ACTION_SETTINGS) }
        row("⌂", "Aplikasi Home default", "Pilih rzkylauncher sebagai launcher bawaan") { dialog.dismiss(); openAndroidSettings(Settings.ACTION_HOME_SETTINGS) }
        row("☼", "Layar & kecerahan", "Resolusi, kecerahan, ukuran tampilan") { dialog.dismiss(); openAndroidSettings(Settings.ACTION_DISPLAY_SETTINGS) }
        row("♫", "Suara & getaran", "Volume sistem, nada dering, getaran") { dialog.dismiss(); openAndroidSettings(Settings.ACTION_SOUND_SETTINGS) }
        row("◉", "Wi-Fi", "Kelola jaringan Wi-Fi perangkat") { dialog.dismiss(); openAndroidSettings(Settings.ACTION_WIFI_SETTINGS) }
        row("ᛒ", "Bluetooth", "Kelola perangkat Bluetooth") { dialog.dismiss(); openAndroidSettings(Settings.ACTION_BLUETOOTH_SETTINGS) }
        row("▤", "Notifikasi rzkylauncher", "Izin dan notifikasi aplikasi launcher") { dialog.dismiss(); openAndroidSettings(Settings.ACTION_APP_NOTIFICATION_SETTINGS) }
        row("ⓘ", "Info aplikasi rzkylauncher", "Penyimpanan, baterai, izin, dan uninstall") { dialog.dismiss(); openAndroidSettings(Settings.ACTION_APPLICATION_DETAILS_SETTINGS) }

        page.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        dialog.setContentView(page)
        dialog.setCancelable(true)
        dialog.window?.let { win ->
            win.setBackgroundDrawableResource(android.R.color.transparent)
            win.setLayout(MATCH, MATCH)
            win.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            val attrs = win.attributes
            attrs.dimAmount = 0.28f
            win.attributes = attrs
        }
        dialog.show()
        dialog.window?.setLayout(MATCH, MATCH)
    }

    /** Buka halaman Settings Android resmi dengan fallback aman jika intent tidak tersedia di OEM. */
    private fun openAndroidSettings(action: String) {
        val intent = when (action) {
            Settings.ACTION_APP_NOTIFICATION_SETTINGS -> Intent(action).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS -> Intent(action, Uri.parse("package:$packageName"))
            else -> Intent(action)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            android.util.Log.w("rzkylauncher", "Settings action unavailable: $action", e)
            try {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            } catch (fallback: Exception) {
                Toast.makeText(this, "Pengaturan Android tidak dapat dibuka", Toast.LENGTH_SHORT).show()
            }
        }
    }

    /** Navigasi halaman launcher; tombol sistem Android tetap dikelola OS/OEM. */
    private fun showNavigationSettings() {
        val options = arrayOf(
            "Geser kiri/kanan untuk pindah halaman Home",
            "Titik halaman untuk memilih halaman",
            "Buka App Library",
            "Pengaturan navigasi Android"
        )
        AlertDialog.Builder(this)
            .setTitle("Navigasi & gesture")
            .setMessage("Navigasi Home rzkylauncher memakai swipe dan titik halaman. Tombol Back, Home, Recent Apps, dan gesture sistem tetap dikendalikan Android agar perangkat selalu bisa dipulihkan.")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> Toast.makeText(this, "Geser horizontal di Home untuk pindah halaman", Toast.LENGTH_LONG).show()
                    1 -> Toast.makeText(this, "Ketuk titik halaman di bawah", Toast.LENGTH_LONG).show()
                    2 -> scroller.smoothScrollTo((pageCount - 2).coerceAtLeast(0) * screenW, 0)
                    3 -> {
                        try {
                            startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
                        } catch (e: Exception) {
                            startActivity(Intent(Settings.ACTION_SETTINGS))
                        }
                    }
                }
            }
            .setPositiveButton("Selesai", null)
            .show()
    }

    private fun showHomeMenu() {
        val items = arrayOf(
            "Pilih wallpaper dari Galeri",
            "Hapus wallpaper foto",
            "Pilih foto widget",
            "Tambah widget Android",
            "Pengaturan tampilan",
            "Warna aksen & tema",
            "Dynamic Glass & Blur (Android 13+)",
            "Control Center",
            if (overlayEnabled()) "Matikan Dynamic Island di semua aplikasi"
            else "Aktifkan Dynamic Island di semua aplikasi",
            "Geser Dynamic Island ke bawah",
            "Geser Dynamic Island ke atas",
            "Lock Screen preview",
            "Izin & pengaturan rzkylauncher",
            "Pengaturan Android"
        )
        AlertDialog.Builder(this)
            .setTitle("rzkylauncher")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> openImagePicker(REQUEST_WALLPAPER)
                    1 -> {
                        prefs.edit().remove("wallpaper_uri").apply()
                        root.background = null
                    }
                    2 -> openImagePicker(REQUEST_PHOTO_WIDGET)
                    3 -> pickWidget()
                    4 -> showDisplaySettings()
                    5 -> showAccentSettings()
                    6 -> showGlassSettings()
                    7 -> showControlCenter()
                    8 -> toggleOverlay()
                    9 -> moveIsland(4)
                    10 -> moveIsland(-4)
                    11 -> showLockScreenPreview()
                    12 -> showLauncherPermissions()
                    13 -> startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun showAccentSettings() {
        val names = arrayOf("Pearl", "Blue", "Purple", "Pink", "Green", "Orange")
        val colors = intArrayOf(
            Color.WHITE,
            Color.rgb(10, 132, 255),
            Color.rgb(175, 82, 222),
            Color.rgb(255, 55, 95),
            Color.rgb(48, 209, 88),
            Color.rgb(255, 159, 10)
        )
        val selected = colors.indexOf(prefs.getInt("accent_color", Color.WHITE)).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Warna aksen rzkylauncher")
            .setSingleChoiceItems(names, selected) { dialog, which ->
                prefs.edit().putInt("accent_color", colors[which]).apply()
                rebuild()
                dialog.dismiss()
                Toast.makeText(this, "Tema ${names[which]} diterapkan", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    /** Pengaturan Dynamic Glass; hanya tersedia pada Android 13 (API 33) ke atas. */
    private fun showGlassSettings() {
        if (android.os.Build.VERSION.SDK_INT < 33) {
            AlertDialog.Builder(this)
                .setTitle("Dynamic Glass belum tersedia")
                .setMessage("Efek Dynamic Glass rzkylauncher memerlukan Android 13 atau lebih baru. Perangkat ini tetap memakai panel transparan standar.")
                .setPositiveButton("Mengerti", null)
                .show()
            return
        }

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(12), dp(22), dp(8))
        }
        val enabled = android.widget.Switch(this).apply {
            text = "Aktifkan Dynamic Glass"
            setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("dynamic_glass_enabled", true)
        }
        content.addView(enabled, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(14) })
        content.addView(TextView(this).apply {
            text = "Glass opacity"
            setTextColor(Color.WHITE)
            textSize = 14f
        })
        val opacity = SeekBar(this).apply {
            max = 60
            progress = (prefs.getInt("glass_opacity", 70) - 35).coerceIn(0, 60)
            isEnabled = enabled.isChecked
        }
        content.addView(opacity, LinearLayout.LayoutParams(MATCH, WRAP))
        val value = TextView(this).apply {
            text = "${opacity.progress + 35}%"
            setTextColor(Color.LTGRAY)
            textSize = 12f
        }
        content.addView(value)
        enabled.setOnCheckedChangeListener { _, checked -> opacity.isEnabled = checked }
        opacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                value.text = "${progress + 35}%"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        AlertDialog.Builder(this)
            .setTitle("Glass & Blur")
            .setView(content)
            .setPositiveButton("Terapkan") { _, _ ->
                prefs.edit()
                    .putBoolean("dynamic_glass_enabled", enabled.isChecked)
                    .putInt("glass_opacity", opacity.progress + 35)
                    .apply()
                rebuild()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    /** Control Center bergaya iOS; kontrol sensitif tetap memakai API resmi Android. */
    private fun showControlCenter() {
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        val camera = getSystemService(CAMERA_SERVICE) as CameraManager
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(8))
            background = glass(28)
        }
        panel.addView(TextView(this).apply {
            text = "Control Center"
            textSize = 23f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(14) })

        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val quickActions = listOf(
            "Wi-Fi" to Settings.ACTION_WIFI_SETTINGS,
            "Bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
            "Hotspot" to Settings.ACTION_WIRELESS_SETTINGS,
            "Layar" to Settings.ACTION_DISPLAY_SETTINGS
        )
        quickActions.forEach { (label, action) ->
            val chip = TextView(this).apply {
                text = label
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = glass(16)
                setPadding(dp(8), dp(13), dp(8), dp(13))
                setOnClickListener {
                    try { startActivity(Intent(action)) }
                    catch (e: Exception) { Toast.makeText(this@MainActivity, "Kontrol tidak tersedia di perangkat ini", Toast.LENGTH_SHORT).show() }
                }
            }
            quick.addView(chip, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(6) })
        }
        panel.addView(quick, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(16) })

        val volumeLabel = TextView(this).apply {
            text = "Volume media"
            textSize = 14f
            setTextColor(Color.WHITE)
        }
        panel.addView(volumeLabel)
        val volume = SeekBar(this).apply {
            max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) audio.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        panel.addView(volume, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) })

        val torch = Button(this).apply {
            text = "Senter · ketuk untuk aktif/nonaktif"
            isAllCaps = false
            setOnClickListener {
                if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA_TORCH)
                } else {
                    toggleTorch(camera)
                }
            }
        }
        panel.addView(torch, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
        panel.addView(TextView(this).apply {
            text = "Kecerahan dan izin sistem dikelola Android demi keamanan perangkat."
            textSize = 11f
            setTextColor(Color.parseColor("#C8C8CE"))
        })
        AlertDialog.Builder(this)
            .setView(panel)
            .setNegativeButton("Selesai", null)
            .setNeutralButton("Pengaturan lainnya") { _, _ -> startActivity(Intent(Settings.ACTION_SETTINGS)) }
            .show()
    }

    private fun toggleTorch(camera: CameraManager) {
        try {
            val id = camera.cameraIdList.firstOrNull { cameraId ->
                camera.getCameraCharacteristics(cameraId).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                Toast.makeText(this, "Senter tidak tersedia", Toast.LENGTH_SHORT).show()
                return
            }
            val enabled = prefs.getBoolean("torch_enabled", false)
            camera.setTorchMode(id, !enabled)
            prefs.edit().putBoolean("torch_enabled", !enabled).apply()
        } catch (e: Exception) {
            android.util.Log.e("rzkylauncher", "Torch toggle failed", e)
            Toast.makeText(this, "Tidak dapat mengubah senter", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showLauncherPermissions() {
        val labels = arrayOf(
            "Jadikan rzkylauncher launcher default",
            "Tampil di atas aplikasi lain",
            "Notifikasi aplikasi",
            "Pengaturan aplikasi rzkylauncher"
        )
        AlertDialog.Builder(this)
            .setTitle("Izin rzkylauncher")
            .setItems(labels) { _, which ->
                try {
                    when (which) {
                        0 -> startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                        1 -> startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                        2 -> startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
                        else -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Halaman izin tidak tersedia", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun showLockScreenPreview() {
        val preview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(36), dp(24), dp(36))
            background = glass(30)
        }
        preview.addView(TextClock(this).apply {
            format24Hour = "HH:mm"
            format12Hour = "hh:mm"
            textSize = 64f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }, LinearLayout.LayoutParams(MATCH, WRAP))
        preview.addView(TextClock(this).apply {
            format24Hour = "EEEE, d MMMM"
            format12Hour = "EEEE, d MMMM"
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(24) })
        preview.addView(TextView(this).apply {
            text = "rzkylauncher · Lock Screen preview\nLayar kunci keamanan tetap dikelola Android."
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
        })
        AlertDialog.Builder(this).setView(preview).setPositiveButton("Selesai", null).show()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CAMERA_TORCH && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            toggleTorch(getSystemService(CAMERA_SERVICE) as CameraManager)
        } else if (requestCode == REQUEST_CAMERA_TORCH) {
            Toast.makeText(this, "Izin kamera diperlukan untuk mengontrol senter", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openImagePicker(request: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, request)
        } catch (e: Exception) {
            Toast.makeText(this, "Galeri tidak tersedia di perangkat ini", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Dipakai untuk kompatibilitas pemilih gambar Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_PICK_WIDGET || requestCode == REQUEST_CONFIGURE_WIDGET) {
            val widgetId = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId)
                ?: pendingWidgetId
            if (requestCode == REQUEST_PICK_WIDGET && resultCode == RESULT_OK && widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
                val info = AppWidgetManager.getInstance(this).getAppWidgetInfo(widgetId)
                if (info?.configure != null) {
                    try {
                        val configure = Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).apply {
                            component = info.configure
                            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                        }
                        startActivityForResult(configure, REQUEST_CONFIGURE_WIDGET)
                    } catch (e: Exception) {
                        attachWidget(widgetId)
                        pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
                    }
                } else {
                    attachWidget(widgetId)
                    pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
                }
            } else if (requestCode == REQUEST_CONFIGURE_WIDGET && resultCode == RESULT_OK && widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) {
                attachWidget(widgetId)
                pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
            } else {
                if (widgetId != AppWidgetManager.INVALID_APPWIDGET_ID) appWidgetHost.deleteAppWidgetId(widgetId)
                pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
            }
            return
        }
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            android.util.Log.d("rzkylauncher", "Persistable photo permission unavailable", e)
        }
        when (requestCode) {
            REQUEST_WALLPAPER -> {
                prefs.edit().putString("wallpaper_uri", uri.toString()).apply()
                applyWallpaper(uri)
                Toast.makeText(this, "Wallpaper rzkylauncher diperbarui", Toast.LENGTH_SHORT).show()
            }
            REQUEST_PHOTO_WIDGET -> {
                prefs.edit().putString("photo_widget_uri", uri.toString()).apply()
                rebuild()
                Toast.makeText(this, "Foto widget diperbarui", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun applySavedWallpaper() {
        prefs.getString("wallpaper_uri", null)?.let {
            try { applyWallpaper(Uri.parse(it)) } catch (e: Exception) {}
        }
    }

    private fun applyWallpaper(uri: Uri) {
        val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        if (bitmap != null && bitmap.width > 0 && bitmap.height > 0) {
            val targetW = resources.displayMetrics.widthPixels
            val targetH = resources.displayMetrics.heightPixels
            val scale = maxOf(targetW.toFloat() / bitmap.width, targetH.toFloat() / bitmap.height)
            val cropW = (targetW / scale).toInt().coerceAtMost(bitmap.width)
            val cropH = (targetH / scale).toInt().coerceAtMost(bitmap.height)
            val cropped = Bitmap.createBitmap(
                bitmap,
                ((bitmap.width - cropW) / 2).coerceAtLeast(0),
                ((bitmap.height - cropH) / 2).coerceAtLeast(0),
                cropW.coerceAtLeast(1),
                cropH.coerceAtLeast(1)
            )
            root.background = BitmapDrawable(resources, Bitmap.createScaledBitmap(cropped, targetW, targetH, true))
        }
    }

    private fun showDisplaySettings() {
        val modes = arrayOf("Lite · animasi dan efek minimal", "Seimbang · rekomendasi", "Full · efek visual maksimal")
        val current = prefs.getInt("performance_mode", 1).coerceIn(0, 2)
        AlertDialog.Builder(this)
            .setTitle("Mode performa")
            .setSingleChoiceItems(modes, current) { dialog, which ->
                prefs.edit().putInt("performance_mode", which).apply()
                dialog.dismiss()
                Toast.makeText(this, "Mode ${listOf("Lite", "Seimbang", "Full")[which]} dipilih", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Ukuran ikon") { _, _ -> showIconSizeSettings() }
            .setNegativeButton("Selesai", null)
            .show()
    }

    private fun showIconSizeSettings() {
        val sizes = arrayOf("Kecil · 52 dp", "Normal · 60 dp", "Besar · 68 dp")
        val values = intArrayOf(52, 60, 68)
        val current = prefs.getInt("icon_size", 60)
        val selected = values.indexOf(current).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Ukuran ikon")
            .setSingleChoiceItems(sizes, selected) { dialog, which ->
                prefs.edit().putInt("icon_size", values[which]).apply()
                iconCache.clear()
                rebuild()
                dialog.dismiss()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    companion object {
        private const val REQUEST_WALLPAPER = 7101
        private const val REQUEST_PHOTO_WIDGET = 7102
        private const val REQUEST_PICK_WIDGET = 7103
        private const val REQUEST_CONFIGURE_WIDGET = 7104
        private const val REQUEST_CAMERA_TORCH = 7105
        private const val APP_WIDGET_HOST_ID = 0x525A
        private const val KEY_WIDGET_IDS = "hosted_widget_ids"
    }

    // --------------------------------------------------------------- island

    private fun islandY() = prefs.getInt("y", 12)

    private fun applyIslandPosition() {
        (island.layoutParams as FrameLayout.LayoutParams).topMargin = dp(islandY())
        island.requestLayout()
    }

    private fun moveIsland(deltaDp: Int) {
        prefs.edit().putInt("y", (islandY() + deltaDp).coerceIn(0, 60)).apply()
        applyIslandPosition()
        IslandOverlayService.refresh(this)
    }

    private fun applyIslandMode() {
        if (overlayEnabled()) {
            IslandOverlayService.start(this)
            island.visibility = View.GONE
        } else {
            stopService(Intent(this, IslandOverlayService::class.java))
            island.visibility = View.VISIBLE
        }
    }

    private fun toggleOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.island_overlay_perm, Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        prefs.edit().putBoolean("overlay_enabled", !prefs.getBoolean("overlay_enabled", true)).apply()
        applyIslandMode()
    }

    private fun askOverlayPermissionOnce() {
        if (Settings.canDrawOverlays(this) || prefs.getBoolean("asked", false)) return
        prefs.edit().putBoolean("asked", true).apply()
        AlertDialog.Builder(this)
            .setTitle("Dynamic Island")
            .setMessage(R.string.island_overlay_perm)
            .setPositiveButton("Aktifkan") { _, _ ->
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            .setNegativeButton("Nanti", null)
            .show()
    }
}
