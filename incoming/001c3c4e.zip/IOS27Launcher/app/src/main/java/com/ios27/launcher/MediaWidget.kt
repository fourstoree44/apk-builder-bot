package com.ios27.launcher

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.SurfaceTexture
import android.graphics.drawable.AnimatedImageDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView

/**
 * Widget foto / GIF / video pilihan sendiri. Video diputar berulang tanpa suara, GIF dan WebP animasi ikut bergerak.
 * Berkas dipilih di Settings > Widget Foto/Video. Ketuk widget kosong untuk membuka pengaturannya.
 */
class MediaWidgetView(ctx: Context) : FrameLayout(ctx) {

    private var player: MediaPlayer? = null
    private var tex: TextureView? = null
    private var anim: AnimatedImageDrawable? = null
    private var generation = 0

    init {
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, ctx.dp(28).toFloat())
            }
        }
        setBackgroundColor(Color.parseColor("#33FFFFFF"))
        load()
    }

    private fun hint(text: String) {
        removeAllViews()
        addView(TextView(context).apply {
            this.text = text; textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(context.dp(16), 0, context.dp(16), 0)
        }, LayoutParams(MATCH, MATCH))
        setOnClickListener {
            context.startActivity(
                Intent(context, SettingsActivity::class.java).putExtra("page", "widget").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    /** Memuat ulang sesuai pilihan di pengaturan. */
    fun load() {
        releasePlayer()
        generation++
        val gen = generation
        removeAllViews()
        val raw = Prefs.str(context, Prefs.WIDGET_URI)
        if (raw.isEmpty()) { hint("Ketuk untuk memilih foto atau video"); return }
        val uri = Uri.parse(raw)
        val type = try { context.contentResolver.getType(uri) ?: "" } catch (_: Exception) { "" }
        if (type.startsWith("video")) loadVideo(uri) else loadImage(uri, gen)
    }

    private fun loadVideo(uri: Uri) {
        val t = TextureView(context)
        tex = t
        t.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                try {
                    val mp = MediaPlayer()
                    player = mp
                    mp.setSurface(Surface(st))
                    mp.setDataSource(context, uri)
                    mp.isLooping = true
                    mp.setVolume(0f, 0f)
                    mp.setOnVideoSizeChangedListener { _, vw, vh -> crop(vw, vh) }
                    mp.setOnPreparedListener { it.start() }
                    mp.setOnErrorListener { _, _, _ -> true }
                    mp.prepareAsync()
                } catch (_: Exception) { hint("Video tidak bisa dibuka") }
            }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) {
                player?.let { crop(it.videoWidth, it.videoHeight) }
            }
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean { releasePlayer(); return true }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        addView(t, LayoutParams(MATCH, MATCH))
        setOnClickListener(null)
        isClickable = false
    }

    /** TextureView meregangkan video ke seluruh ukuran view; matriks ini mengembalikan rasio dan memotong tepi (center-crop). */
    private fun crop(vw: Int, vh: Int) {
        val t = tex ?: return
        if (vw <= 0 || vh <= 0 || t.width <= 0 || t.height <= 0) return
        val va = vw.toFloat() / vh
        val ra = t.width.toFloat() / t.height
        val sx = if (va > ra) va / ra else 1f
        val sy = if (va > ra) 1f else ra / va
        val m = Matrix()
        m.setScale(sx, sy, t.width / 2f, t.height / 2f)
        t.setTransform(m)
    }

    private fun loadImage(uri: Uri, gen: Int) {
        val iv = ImageView(context).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        addView(iv, LayoutParams(MATCH, MATCH))
        isClickable = false
        Thread {
            try {
                val src = ImageDecoder.createSource(context.contentResolver, uri)
                val dr = ImageDecoder.decodeDrawable(src) { dec, info, _ ->
                    val m = maxOf(info.size.width, info.size.height)
                    if (m > 1600) dec.setTargetSampleSize(m / 1600)
                }
                post {
                    if (gen != generation) return@post
                    iv.setImageDrawable(dr)
                    if (dr is AnimatedImageDrawable) {
                        dr.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                        anim = dr
                        if (isShown) dr.start()
                    }
                }
            } catch (_: Throwable) {
                post { if (gen == generation) hint("Foto tidak bisa dibuka") }
            }
        }.start()
    }

    private fun releasePlayer() {
        try { player?.release() } catch (_: Exception) {}
        player = null
        anim?.stop(); anim = null
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        try {
            if (visibility == View.VISIBLE) { player?.start(); anim?.start() }
            else { player?.pause(); anim?.stop() }
        } catch (_: Exception) {}
    }

    override fun onDetachedFromWindow() {
        releasePlayer()
        super.onDetachedFromWindow()
    }
}
