package com.ios27.launcher

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import android.text.format.DateUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/** Kartu notifikasi yang bisa digeser ke samping untuk dihapus dan diketuk untuk dibuka. */
class SwipeCard(ctx: Context, backdrop: Boolean) : LinearLayout(ctx) {
    var onDismiss: (() -> Unit)? = null
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop

    init {
        orientation = LinearLayout.HORIZONTAL
        background = ctx.glass(24, false, backdrop)
        setPadding(ctx.dp(14), ctx.dp(12), ctx.dp(14), ctx.dp(12))
        isClickable = true
    }

    private fun settle() {
        if (abs(translationX) > width * 0.35f) {
            val dir = if (translationX > 0) 1f else -1f
            animate().translationX(dir * width).alpha(0f).setDuration(160).withEndAction { onDismiss?.invoke() }.start()
        } else {
            animate().translationX(0f).alpha(1f).setDuration(160).start()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX; downY = e.rawY; dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (!dragging && abs(dx) > slop && abs(dx) > abs(dy)) {
                    dragging = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
                if (dragging) {
                    translationX = dx
                    alpha = (1f - abs(dx) / width).coerceIn(0.2f, 1f)
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) settle()
                else if (abs(e.rawX - downX) < slop && abs(e.rawY - downY) < slop) performClick()
                dragging = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                if (dragging) settle()
                dragging = false
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun performClick(): Boolean = super.performClick()
}

/** Jam raksasa ala layar kunci referensi: angka tebal dengan gradasi kaca (putih di atas, biru bening di bawah). */
class BigClock(ctx: Context) : View(ctx) {
    private val p = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { invalidate(); h.postDelayed(this, 10_000) }
    }

    init {
        p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
        p.textAlign = Paint.Align.CENTER
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); h.post(tick) }
    override fun onDetachedFromWindow() { h.removeCallbacks(tick); super.onDetachedFromWindow() }

    override fun onDraw(c: android.graphics.Canvas) {
        val w = width.toFloat()
        val hh = height.toFloat()
        p.textSize = hh * 1.05f
        p.shader = android.graphics.LinearGradient(
            0f, 0f, 0f, hh,
            intArrayOf(Color.parseColor("#F5FFFFFF"), Color.parseColor("#C8DCE8FF"), Color.parseColor("#6E7FB4FF")),
            floatArrayOf(0f, 0.55f, 1f), android.graphics.Shader.TileMode.CLAMP
        )
        val txt = fmt.format(Date())
        // kalau terlalu lebar, kecilkan supaya muat
        val tw = p.measureText(txt)
        if (tw > w) p.textSize = p.textSize * w / tw
        c.drawText(txt, w / 2f, hh * 0.86f, p)
    }
}

/**
 * Notification Center bergaya iOS: jam besar, kartu lagu, lalu daftar notifikasi asli HP
 * (dibaca lewat akses notifikasi). Geser kartu ke samping untuk menghapus, ketuk untuk membuka.
 */
class NotificationCenter(
    private val ctx: Context,
    private val host: FrameLayout,
    private val topInset: () -> Int,
    private val backdrop: Boolean,
    private val onClosed: () -> Unit = {},
    private val onShown: () -> Unit = {}
) {
    private var view: FrameLayout? = null
    val isShowing: Boolean get() = view != null

    private var list: LinearLayout? = null
    private val handler = Handler(Looper.getMainLooper())
    private val changed: () -> Unit = { rebuild() }

    private fun rebuild() {
        val l = list ?: return
        l.removeAllViews()
        if (!MediaWatcher.isAccessGranted(ctx)) {
            l.addView(infoCard("Beri akses notifikasi", "Ketuk untuk mengizinkan launcher membaca notifikasi") {
                close()
                ctx.startSafe(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            })
            return
        }
        val items = NotifHub.active(ctx)
        if (items.isEmpty()) {
            l.addView(TextView(ctx).apply {
                text = "Tidak ada notifikasi"
                textSize = 15f
                setTextColor(Color.parseColor("#C7C7CC"))
                gravity = Gravity.CENTER
                setPadding(0, ctx.dp(36), 0, ctx.dp(36))
            }, LinearLayout.LayoutParams(MATCH, WRAP))
            return
        }
        items.forEach { l.addView(card(it), LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = ctx.dp(10) }) }
    }

    private fun infoCard(title: String, sub: String, click: () -> Unit): View {
        val c = SwipeCard(ctx, backdrop)
        c.orientation = LinearLayout.VERTICAL
        c.addView(TextView(ctx).apply { text = title; textSize = 16f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD) })
        c.addView(TextView(ctx).apply { text = sub; textSize = 13f; setTextColor(Color.parseColor("#C7C7CC")) })
        c.setOnClickListener { click() }
        return c
    }

    private fun card(sbn: StatusBarNotification): View {
        val c = SwipeCard(ctx, backdrop)
        val icon = ImageView(ctx).apply {
            NotifHub.appIcon(ctx, sbn.packageName, ctx.dp(40))?.let { setImageBitmap(it) }
            background = GradientDrawable().apply { cornerRadius = ctx.dp(10).toFloat(); setColor(Color.parseColor("#33FFFFFF")) }
            clipToOutline = true
        }
        c.addView(icon, LinearLayout.LayoutParams(ctx.dp(38), ctx.dp(38)))

        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(ctx).apply {
            text = NotifHub.appName(ctx, sbn.packageName).uppercase()
            textSize = 11f; setTextColor(Color.parseColor("#AEAEB2")); maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(TextView(ctx).apply {
            text = DateUtils.getRelativeTimeSpanString(
                sbn.postTime, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS, DateUtils.FORMAT_ABBREV_RELATIVE
            )
            textSize = 11f; setTextColor(Color.parseColor("#AEAEB2"))
        })
        col.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
        val title = NotifHub.titleOf(sbn)
        if (title.isNotBlank()) col.addView(TextView(ctx).apply {
            text = title; textSize = 15f; setTextColor(Color.WHITE); maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = ctx.dp(2) })
        val text = NotifHub.textOf(sbn)
        if (text.isNotBlank()) col.addView(TextView(ctx).apply {
            this.text = text; textSize = 14f; setTextColor(Color.parseColor("#E5E5EA")); maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(MATCH, WRAP))
        c.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = ctx.dp(12) })

        c.onDismiss = { NotifHub.dismiss(sbn.key); rebuild() }
        c.setOnClickListener {
            close()
            try { sbn.notification.contentIntent?.send() } catch (_: Exception) {}
            if (sbn.notification.flags and android.app.Notification.FLAG_AUTO_CANCEL != 0) NotifHub.dismiss(sbn.key)
        }
        return c
    }

    fun show() {
        close()
        val scrim = FrameLayout(ctx).apply {
            setBackgroundColor(Color.argb(if (backdrop) 160 else 80, 0, 0, 0))
            isClickable = true
            setOnClickListener { close() }
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.dp(16), topInset() + ctx.dp(18), ctx.dp(16), ctx.dp(40))
        }

        // jam besar dan tanggal, seperti layar kunci iOS
        col.addView(BigClock(ctx), LinearLayout.LayoutParams(MATCH, ctx.dp(150)))
        col.addView(TextView(ctx).apply {
            text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date())
            textSize = 17f
            setTextColor(Color.parseColor("#E5E5EA"))
            gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = ctx.dp(18) })

        if (MediaWatcher.info != null) {
            col.addView(MediaCard(ctx, backdrop) { close(); ctx.startSafe(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) },
                LinearLayout.LayoutParams(MATCH, ctx.dp(128)).apply { bottomMargin = ctx.dp(16) })
        }

        val header = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(ctx).apply {
            text = "Notifikasi"; textSize = 20f; setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, WRAP, 1f))
        header.addView(TextView(ctx).apply {
            text = "Hapus semua"; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = ctx.glass(16, true, backdrop)
            setPadding(ctx.dp(14), 0, ctx.dp(14), 0)
            setOnClickListener { NotifHub.dismissAll(); handler.postDelayed({ rebuild() }, 250) }
        }, LinearLayout.LayoutParams(WRAP, ctx.dp(32)))
        col.addView(header, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = ctx.dp(10) })

        val l = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        list = l
        col.addView(l, LinearLayout.LayoutParams(MATCH, WRAP))

        var downY = 0f
        val scroll = ScrollView(ctx).apply {
            isVerticalScrollBarEnabled = false
            // layar lebar (landscape / tablet): lebar konten dibatasi dan di tengah
            val wide = ctx.resources.displayMetrics.widthPixels > ctx.dp(520)
            addView(col, FrameLayout.LayoutParams(if (wide) ctx.dp(420) else MATCH, WRAP,
                if (wide) Gravity.CENTER_HORIZONTAL else Gravity.START))
            setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> downY = e.rawY
                    MotionEvent.ACTION_UP -> if (downY - e.rawY > ctx.dp(90) && !canScrollVertically(1) && !canScrollVertically(-1)) close()
                }
                false
            }
        }
        scrim.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))

        rebuild()
        NotifHub.addChangeListener(changed)

        scrim.alpha = 0f
        col.translationY = -ctx.dp(30).toFloat()
        host.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))
        val ease = android.view.animation.PathInterpolator(0.2f, 0.85f, 0.25f, 1f)
        scrim.animate().alpha(1f).setDuration(260).setInterpolator(ease).start()
        col.animate().translationY(0f).setDuration(340).setInterpolator(ease).start()
        view = scrim
        onShown()
    }

    fun close() {
        val v = view ?: return
        view = null
        list = null
        NotifHub.removeChangeListener(changed)
        v.animate().alpha(0f).setDuration(160).withEndAction {
            try { host.removeView(v) } catch (_: Exception) {}
            onClosed()
        }.start()
    }
}
