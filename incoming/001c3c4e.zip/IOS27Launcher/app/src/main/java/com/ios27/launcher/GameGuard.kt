package com.ios27.launcher

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.res.Configuration
import android.view.View

/**
 * Menyembunyikan Dynamic Island saat game (atau layar landscape) sedang tampil.
 * Aplikasi di layar depan diketahui dari layanan Aksesibilitas, jadi butuh Aksesibilitas "iOS 27 Panel" aktif.
 */
object GameGuard {
    @Volatile var foreground: String = ""
    private val cache = HashMap<String, Boolean>()

    private fun isGame(ctx: Context, pkg: String): Boolean = synchronized(cache) {
        cache.getOrPut(pkg) {
            try {
                val ai = ctx.packageManager.getApplicationInfo(pkg, 0)
                @Suppress("DEPRECATION")
                ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0
            } catch (_: Exception) { false }
        }
    }

    fun shouldHide(ctx: Context): Boolean {
        if (!Prefs.bool(ctx, Prefs.ISLAND_GAME_OFF)) return false
        val landscape = ctx.resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val pkg = foreground
        if (pkg.isEmpty() || pkg == ctx.packageName) return false
        return landscape || isGame(ctx, pkg)
    }

    /** Dipanggil saat aplikasi di layar depan berganti. */
    fun onForeground(ctx: Context, pkg: String) {
        if (pkg == foreground) return
        foreground = pkg
        apply(ctx)
    }

    fun apply(ctx: Context) {
        val v = DynamicIslandView.overlay ?: return
        val hide = shouldHide(ctx)
        v.post { v.visibility = if (hide) View.GONE else View.VISIBLE }
    }
}
