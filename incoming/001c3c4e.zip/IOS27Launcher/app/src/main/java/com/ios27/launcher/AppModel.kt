package com.ios27.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.graphics.Rect
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.LayerDrawable
import android.os.Process
import android.os.UserHandle
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.drawable.AdaptiveIconDrawable
import android.provider.MediaStore
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin

data class AppEntry(
    val label: String,
    val pkg: String,
    val component: ComponentName,
    val category: Int,
    /** Padanan iOS (App Store, Safari, dll) kalau ada; dipakai untuk ikon dan nama. */
    val ios: IosKind? = null,
    /** Profil pemilik aplikasi (kosong = profil utama). Aplikasi klon / Dual Apps / profil kerja ada di profil lain. */
    val user: UserHandle? = null,
    val clone: Boolean = false
) {
    /** Kunci unik: aplikasi klon memakai paket dan komponen yang sama dengan aslinya, jadi profilnya ikut dihitung. */
    val key: String get() = component.flattenToString() + "#" + (user?.hashCode() ?: 0)
}

/**
 * Semua aplikasi berikon launcher, termasuk aplikasi klon (Dual Apps / profil kerja) lewat LauncherApps.
 * Launcher ini sendiri ikut tampil dan membuka Pengaturan.
 */
fun loadApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    val iosOn = Prefs.bool(ctx, Prefs.IOS_ICONS)
    val out = ArrayList<AppEntry>()
    try {
        val la = ctx.getSystemService(LauncherApps::class.java)
        val me = Process.myUserHandle()
        for (u in la.profiles) {
            for (info in la.getActivityList(null, u)) {
                val pkg = info.applicationInfo.packageName
                val clone = u != me
                val self = pkg == ctx.packageName && !clone
                val raw = info.label.toString()
                val kind = if (!self && iosOn) IosIcons.match(pkg, raw) else null
                out += AppEntry(
                    label = if (self) "Launcher" else kind?.title ?: raw,
                    pkg = pkg,
                    component = info.componentName,
                    category = if (self) ApplicationInfo.CATEGORY_PRODUCTIVITY else info.applicationInfo.category,
                    ios = kind,
                    user = u,
                    clone = clone
                )
            }
        }
    } catch (_: Exception) {}
    if (out.isEmpty()) {
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        for (ri in pm.queryIntentActivities(query, 0)) {
            val ai = ri.activityInfo
            val self = ai.packageName == ctx.packageName
            val raw = ri.loadLabel(pm).toString()
            val kind = if (!self && iosOn) IosIcons.match(ai.packageName, raw) else null
            out += AppEntry(
                label = if (self) "Launcher" else kind?.title ?: raw,
                pkg = ai.packageName,
                component = ComponentName(ai.packageName, ai.name),
                category = if (self) ApplicationInfo.CATEGORY_PRODUCTIVITY else ai.applicationInfo.category,
                ios = kind
            )
        }
    }
    return out.sortedBy { it.label.lowercase() }
}

/** Membuka aplikasi di profil yang benar (aplikasi klon tidak bisa dibuka lewat Intent biasa). Mengembalikan false kalau gagal. */
fun launchApp(ctx: Context, app: AppEntry, opts: android.os.Bundle?): Boolean {
    val me = Process.myUserHandle()
    if (app.user != null && app.user != me) {
        return try {
            ctx.getSystemService(LauncherApps::class.java).startMainActivity(app.component, app.user, null, opts)
            true
        } catch (_: Exception) { false }
    }
    return false
}

/** Dock: Telepon, Pesan, Browser, Kamera. Kalau tidak ketemu, diisi aplikasi lain. */
fun resolveDock(ctx: Context, apps: List<AppEntry>): List<AppEntry> {
    val pm = ctx.packageManager
    val wanted = listOf(
        Intent(Intent.ACTION_DIAL),
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER),
        Intent(MediaStore.ACTION_IMAGE_CAPTURE)
    )
    val result = mutableListOf<AppEntry>()
    for (intent in wanted) {
        val pkg = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName
        val hit = apps.firstOrNull {
            it.pkg == pkg && !it.clone && it.pkg != ctx.packageName && result.none { r -> r.pkg == it.pkg }
        }
        if (hit != null) result += hit
    }
    for (a in apps) {
        if (result.size >= 4) break
        if (a.pkg != ctx.packageName && !a.clone && result.none { it.pkg == a.pkg }) result += a
    }
    return result.take(4)
}

fun categoryName(a: AppEntry): String = when (a.category) {
    ApplicationInfo.CATEGORY_SOCIAL -> "Sosial"
    ApplicationInfo.CATEGORY_AUDIO,
    ApplicationInfo.CATEGORY_VIDEO,
    ApplicationInfo.CATEGORY_IMAGE -> "Hiburan"
    ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Produktivitas"
    ApplicationInfo.CATEGORY_GAME -> "Game"
    ApplicationInfo.CATEGORY_NEWS -> "Berita"
    ApplicationInfo.CATEGORY_MAPS -> "Perjalanan"
    else -> "Utilitas"
}

val CATEGORY_ORDER = listOf(
    "Sosial", "Hiburan", "Produktivitas", "Game", "Berita", "Perjalanan", "Utilitas"
)

/** Bentuk squircle (kotak membulat halus ala iOS). 0 = hampir persegi, 100 = lingkaran. */
fun squirclePath(size: Float, roundness: Int): Path {
    val n = 2.0 + (1.0 - roundness / 100.0) * 10.0
    val a = size / 2f
    val path = Path()
    val steps = 160
    for (i in 0..steps) {
        val t = 2 * Math.PI * i / steps
        val ct = cos(t)
        val st = sin(t)
        val x = a + a * sign(ct) * abs(ct).pow(2.0 / n)
        val y = a + a * sign(st) * abs(st).pow(2.0 / n)
        if (i == 0) path.moveTo(x.toFloat(), y.toFloat()) else path.lineTo(x.toFloat(), y.toFloat())
    }
    path.close()
    return path
}

/**
 * Ikon dipotong menjadi squircle sesuai "Corner rounding", diberi kilau kaca dan garis tepi cahaya.
 * Gaya Glass menaruh ikon di atas ubin kaca tembus pandang. Gaya Original memakai latar ikon aslinya.
 */
fun makeIcon(ctx: Context, app: AppEntry, sizePx: Int): Bitmap {
    val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val s = sizePx.toFloat()
    val glass = Prefs.bool(ctx, Prefs.ICON_GLASS)
    val clip = squirclePath(s, Prefs.int(ctx, Prefs.ICON_ROUND))

    c.save()
    c.clipPath(clip)
    if (app.ios != null) {
        IosIcons.draw(c, app.ios, s)
    } else {
        if (glass) {
            val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    0f, 0f, s, s,
                    Color.parseColor("#5C6A86"), Color.parseColor("#232A3B"), Shader.TileMode.CLAMP
                )
            }
            c.drawRect(0f, 0f, s, s, fill)
        }
        // beberapa aplikasi (mis. Mobile Legends) memakai bitmap hardware yang tidak bisa digambar ke canvas biasa.
        // Dicoba beberapa sumber ikon; kalau semuanya gagal atau kosong, dibuat ubin berisi huruf awal.
        var done = false
        val pm = ctx.packageManager
        val sources = listOf<() -> Drawable>(
            { pm.getActivityIcon(app.component) },
            { pm.getApplicationIcon(app.pkg) }
        )
        for (src in sources) {
            if (done) break
            try {
                val raw = src()
                val layer = renderIconLayer(raw, sizePx, glass)
                if (isBlank(layer.first)) continue
                if (!layer.second && !glass) c.drawColor(Color.WHITE)
                c.drawBitmap(layer.first, 0f, 0f, null)
                done = true
            } catch (_: Throwable) {}
        }
        if (!done) drawLetterTile(c, s, app.label)
    }

    // kilau kaca di bagian atas
    val sheen = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(
            0f, 0f, 0f, s * 0.6f,
            Color.argb(if (glass) 70 else 40, 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
    }
    c.drawRect(0f, 0f, s, s * 0.6f, sheen)
    c.restore()

    // garis tepi cahaya
    val sw = (s * 0.028f).coerceAtLeast(1.5f)
    val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = sw
        shader = LinearGradient(
            0f, 0f, s, s,
            intArrayOf(Color.argb(210, 255, 255, 255), Color.argb(24, 255, 255, 255), Color.argb(120, 255, 255, 255)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
    }
    c.save()
    c.clipPath(clip)
    c.drawPath(clip, edge)
    c.restore()

    if (app.clone) {
        // lencana kecil di pojok kanan bawah: tanda aplikasi klon
        val r = s * 0.17f
        val cx = s - r * 1.05f
        val cy = s - r * 1.05f
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        c.drawCircle(cx, cy, r, ring)
        ring.color = Color.parseColor("#FF9500")
        c.drawCircle(cx, cy, r * 0.82f, ring)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = r * 1.25f; textAlign = Paint.Align.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
        }
        c.drawText("2", cx, cy + r * 0.43f, tp)
    }
    return bmp
}

private fun softDraw(dr: Drawable, c: Canvas, l: Int, t: Int, r: Int, b: Int) {
    if (dr is BitmapDrawable && dr.bitmap?.config == Bitmap.Config.HARDWARE) {
        val soft = dr.bitmap.copy(Bitmap.Config.ARGB_8888, false)
        if (soft != null) { c.drawBitmap(soft, null, Rect(l, t, r, b), null); return }
    }
    if (dr is LayerDrawable) {
        for (i in 0 until dr.numberOfLayers) softDraw(dr.getDrawable(i), c, l, t, r, b)
        return
    }
    dr.setBounds(l, t, r, b)
    dr.draw(c)
}

/** Menggambar ikon aplikasi ke bitmap transparan. Pair.second = true kalau ikonnya adaptif (sudah punya latar sendiri). */
private fun renderIconLayer(raw: Drawable, sizePx: Int, glass: Boolean): Pair<Bitmap, Boolean> {
    val tmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    val tc = Canvas(tmp)
    val dr = raw.constantState?.newDrawable()?.mutate() ?: raw
    if (dr is AdaptiveIconDrawable) {
        // layer adaptif 108dp dengan area aman 72dp: perbesar supaya area aman memenuhi ubin
        val ext = (sizePx * if (glass) 0.10f else 0.25f).toInt()
        if (!glass) dr.background?.let { softDraw(it, tc, -ext, -ext, sizePx + ext, sizePx + ext) }
        dr.foreground?.let { softDraw(it, tc, -ext, -ext, sizePx + ext, sizePx + ext) }
        return tmp to true
    }
    val inset = (sizePx * if (glass) 0.16f else 0.12f).toInt()
    softDraw(dr, tc, inset, inset, sizePx - inset, sizePx - inset)
    return tmp to false
}

/** true kalau bitmap (hampir) sepenuhnya transparan. */
private fun isBlank(b: Bitmap): Boolean {
    val n = 9
    for (i in 1..n) for (j in 1..n) {
        val x = (b.width * i / (n + 1)).coerceIn(0, b.width - 1)
        val y = (b.height * j / (n + 1)).coerceIn(0, b.height - 1)
        if (Color.alpha(b.getPixel(x, y)) > 12) return false
    }
    return true
}

private fun drawLetterTile(c: Canvas, s: Float, label: String) {
    val hue = ((label.hashCode() and 0x7fffffff) % 360).toFloat()
    val top = Color.HSVToColor(floatArrayOf(hue, 0.55f, 0.95f))
    val bottom = Color.HSVToColor(floatArrayOf(hue, 0.75f, 0.65f))
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    p.shader = LinearGradient(0f, 0f, 0f, s, top, bottom, Shader.TileMode.CLAMP)
    c.drawRect(0f, 0f, s, s, p)
    p.shader = null
    p.color = Color.WHITE
    p.textSize = s * 0.5f
    p.textAlign = Paint.Align.CENTER
    p.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
    val ch = label.trim().firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "?"
    c.drawText(ch, s / 2f, s / 2f + p.textSize * 0.35f, p)
}
