package com.ios27.launcher

import android.Manifest
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Status perekam layar, dibaca Control Center untuk menyalakan tombol Rekam. */
object ScreenRecorder {
    @Volatile var recording = false

    /** Dipanggil dari tombol Rekam: mulai kalau belum merekam, berhenti kalau sedang merekam. */
    fun toggle(ctx: Context) {
        if (recording) {
            ctx.startService(Intent(ctx, ScreenRecordService::class.java).setAction(ScreenRecordService.ACTION_STOP))
        } else {
            ctx.startActivity(
                Intent(ctx, ScreenRecordRequestActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}

/**
 * Activity tanpa tampilan untuk meminta izin: mikrofon (opsional) lalu dialog "mulai merekam" dari sistem.
 * Setelah disetujui, perekaman dijalankan oleh [ScreenRecordService].
 */
class ScreenRecordRequestActivity : Activity() {

    private var withAudio = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (ScreenRecorder.recording) { ScreenRecorder.toggle(this); finish(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED && !Prefs.bool(this, Prefs.REC_ASKED)) {
            Prefs.setBool(this, Prefs.REC_ASKED, true)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 31)
        } else askProjection()
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        askProjection()
    }

    private fun askProjection() {
        withAudio = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        try {
            startActivityForResult(mpm.createScreenCaptureIntent(), 32)
        } catch (_: Exception) {
            Toast.makeText(this, "Perekam layar tidak tersedia di HP ini", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 32 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, ScreenRecordService::class.java)
                .setAction(ScreenRecordService.ACTION_START)
                .putExtra("code", resultCode)
                .putExtra("data", data)
                .putExtra("audio", withAudio)
            ContextCompat.startForegroundService(this, i)
        }
        finish()
    }
}

class ScreenRecordService : Service() {

    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var display: VirtualDisplay? = null
    private var pfd: ParcelFileDescriptor? = null
    private var uri: Uri? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_STOP -> stopRecording()
            else -> if (!ScreenRecorder.recording) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Rekam layar", NotificationManager.IMPORTANCE_LOW))
        }
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ScreenRecordService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Merekam layar")
            .setContentText("Ketuk untuk berhenti")
            .setContentIntent(stop)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Berhenti", stop).build())
            .build()
    }

    private fun start(intent: Intent) {
        if (ScreenRecorder.recording) return
        // wajib jadi foreground service sebelum mengambil MediaProjection
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIF_ID, notification())

        val code = intent.getIntExtra("code", Activity.RESULT_CANCELED)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return }
        val withAudio = intent.getBooleanExtra("audio", false) &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

        try {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpm.getMediaProjection(code, data)
            projection = mp
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { handler.post { stopRecording() } }
            }, handler)

            val b = getSystemService(android.view.WindowManager::class.java).maximumWindowMetrics.bounds
            val w = b.width() and 1.inv()
            val h = b.height() and 1.inv()
            val dpi = resources.displayMetrics.densityDpi

            val name = "Rekaman_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Rekaman Layar")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val u = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("tidak bisa membuat file")
            uri = u
            pfd = contentResolver.openFileDescriptor(u, "w")

            @Suppress("DEPRECATION")
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            if (withAudio) r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            if (withAudio) {
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                r.setAudioEncodingBitRate(128_000)
                r.setAudioSamplingRate(44_100)
            }
            r.setVideoSize(w, h)
            r.setVideoFrameRate(30)
            r.setVideoEncodingBitRate(8_000_000)
            r.setOutputFile(pfd!!.fileDescriptor)
            r.prepare()
            recorder = r

            display = mp.createVirtualDisplay(
                "rekam", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
            )
            r.start()
            ScreenRecorder.recording = true
            Toast.makeText(this, "Mulai merekam layar", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal merekam: ${e.message}", Toast.LENGTH_LONG).show()
            cleanup(save = false)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun stopRecording() {
        if (!ScreenRecorder.recording && recorder == null) { stopSelf(); return }
        cleanup(save = true)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun cleanup(save: Boolean) {
        ScreenRecorder.recording = false
        var ok = save
        try { recorder?.stop() } catch (_: Exception) { ok = false }
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { display?.release() } catch (_: Exception) {}
        display = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        try { pfd?.close() } catch (_: Exception) {}
        pfd = null
        val u = uri
        uri = null
        if (u != null) {
            try {
                if (ok) {
                    contentResolver.update(u, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
                    Toast.makeText(this, "Rekaman disimpan di Movies/Rekaman Layar", Toast.LENGTH_LONG).show()
                } else contentResolver.delete(u, null, null)
            } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        if (ScreenRecorder.recording) cleanup(save = true)
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.ios27.launcher.REC_START"
        const val ACTION_STOP = "com.ios27.launcher.REC_STOP"
        private const val CHANNEL = "rekam"
        private const val NOTIF_ID = 28
    }
}
