package com.ios27.launcher

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.min

/** Slider vertikal tebal ala iOS (kecerahan, volume), dengan latar kaca. */
class VSlider(
    ctx: Context, private val glyph: G, backdrop: Boolean, private val onValue: (Float) -> Unit
) : View(ctx) {
    var value = 0.5f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F5FFFFFF") }
    private val clip = Path()
    private val rect = RectF()

    init { background = ctx.glass(30, true, backdrop) }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        val r = context.dp(30).toFloat()
        rect.set(0f, 0f, w, h)
        clip.reset(); clip.addRoundRect(rect, r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        c.drawRect(0f, h * (1f - value), w, h, fill)
        c.restore()
        val gy = h - context.dp(34).toFloat()
        val covered = h * (1f - value) < gy - context.dp(12)
        Glyphs.draw(c, glyph, w / 2f, gy, context.dp(26).toFloat(), if (covered) Color.parseColor("#3A3A3C") else Color.WHITE)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                value = 1f - e.y / height
                onValue(value)
            }
        }
        return true
    }
}
/** Kartu lagu (Control Center dan Notification Center). Mendengarkan lagu selama terpasang di layar. */
class MediaCard(ctx: Context, backdrop: Boolean, private val onNoAccess: () -> Unit) : LinearLayout(ctx) {
    private val art = ImageView(ctx)
    private val title = TextView(ctx)
    private val artist = TextView(ctx)
    private val play = GlyphView(ctx, G.PLAY, Color.WHITE, 0.55f)
    private val listener: (MediaWatcher.Info?) -> Unit = { update(it) }

    init {
        orientation = LinearLayout.VERTICAL
        background = ctx.glass(28, true, backdrop)
        setPadding(ctx.dp(14), ctx.dp(14), ctx.dp(14), ctx.dp(8))
        setOnClickListener {
            if (!MediaWatcher.isAccessGranted(ctx)) onNoAccess() else MediaWatcher.openApp()
        }

        val top = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        art.background = GradientDrawable().apply { cornerRadius = ctx.dp(11).toFloat(); setColor(Color.parseColor("#33FFFFFF")) }
        art.clipToOutline = true
        top.addView(art, LinearLayout.LayoutParams(ctx.dp(46), ctx.dp(46)))
        val names = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        title.apply { textSize = 14f; setTextColor(Color.WHITE); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD) }
        artist.apply { textSize = 12f; setTextColor(Color.parseColor("#C7C7CC")); maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        names.addView(title); names.addView(artist)
        top.addView(names, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = ctx.dp(10) })
        addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        val row = LinearLayout(ctx).apply { gravity = Gravity.CENTER }
        row.addView(GlyphView(ctx, G.PREV, Color.WHITE, 0.5f).apply { setOnClickListener { MediaWatcher.previous() } },
            LinearLayout.LayoutParams(0, MATCH, 1f))
        play.setOnClickListener { MediaWatcher.toggle() }
        row.addView(play, LinearLayout.LayoutParams(0, MATCH, 1f))
        row.addView(GlyphView(ctx, G.NEXT, Color.WHITE, 0.5f).apply { setOnClickListener { MediaWatcher.next() } },
            LinearLayout.LayoutParams(0, MATCH, 1f))
        addView(row, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    private fun update(i: MediaWatcher.Info?) {
        title.text = i?.title ?: "Tidak diputar"
        artist.text = i?.artist ?: if (MediaWatcher.isAccessGranted(context)) "" else "Ketuk untuk beri akses"
        play.glyph = if (i?.playing == true) G.PAUSE else G.PLAY
        if (i?.art != null) art.setImageBitmap(i.art) else art.setImageDrawable(null)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        MediaWatcher.addListener(context, listener)
    }

    override fun onDetachedFromWindow() {
        MediaWatcher.removeListener(listener)
        super.onDetachedFromWindow()
    }
}

/**
 * Tombol Control Center. Mati = abu transparan di atas kaca, hidup = biru iOS (#0A84FF).
 * [circle] true = bulat (kotak besar konektivitas), false = kotak membulat 28dp (grid).
 * Kalau [span] = 2 (lebar), label ikut digambar di samping ikon.
 */
class CcButton(
    ctx: Context, val id: String, private val glyph: G, backdrop: Boolean, private val circle: Boolean = false
) : View(ctx) {
    var on = false
        set(v) { if (field != v) { field = v; invalidate() } }
    var label = ""
    var span = 1
    var editing = false
        set(v) { field = v; if (v) startJiggle() else stopJiggle(); invalidate() }

    private val fillOn = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Prefs.accent(ctx) }
    private val fillOff = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#4D8E8E93") }
    private val badge = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E6FFFFFF") }
    private val minus = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1C1C1E"); strokeWidth = ctx.dp(2).toFloat(); strokeCap = Paint.Cap.ROUND
    }
    private val text = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = ctx.dp(14).toFloat()
        typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
    }
    private val rect = RectF()
    private var jiggle: ObjectAnimator? = null

    init { background = ctx.glass(if (circle) 60 else 28, true, backdrop) }

    private fun startJiggle() {
        stopJiggle()
        jiggle = ObjectAnimator.ofFloat(this, ROTATION, -1.6f, 1.6f).apply {
            duration = 100L + (Math.random() * 40).toLong()
            repeatMode = ObjectAnimator.REVERSE
            repeatCount = ObjectAnimator.INFINITE
            interpolator = LinearInterpolator()
            start()
        }
    }

    private fun stopJiggle() { jiggle?.cancel(); jiggle = null; rotation = 0f }

    override fun onDetachedFromWindow() { stopJiggle(); super.onDetachedFromWindow() }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        val r = if (circle) min(w, h) / 2f else min(context.dp(28).toFloat(), h / 2f)
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, r, r, if (on) fillOn else fillOff)
        val icon = min(w, h) * 0.46f
        val wide = w > h * 1.5f && label.isNotEmpty()
        if (wide) {
            Glyphs.draw(c, glyph, h / 2f, h / 2f, icon, Color.WHITE)
            val x = h * 0.95f
            val t = TextUtils.ellipsize(label, text, w - x - context.dp(12), TextUtils.TruncateAt.END).toString()
            c.drawText(t, x, h / 2f + text.textSize / 3f, text)
        } else {
            Glyphs.draw(c, glyph, w / 2f, h / 2f, icon, Color.WHITE)
        }
        if (editing) {
            val br = context.dp(10).toFloat()
            c.drawCircle(br, br, br, badge)
            c.drawLine(br - br * 0.45f, br, br + br * 0.45f, br, minus)
        }
    }
}

/**
 * Grid tombol 4 kolom. Tombol boleh selebar 1 atau 2 kolom. Di edit mode: ketuk = ganti ukuran,
 * ketuk lencana "−" = hapus, tekan-tahan lalu geser = pindah urutan.
 */
class TileGrid(ctx: Context, private val cols: Int, private val gapPx: Int) : ViewGroup(ctx) {
    var editing = false
        set(v) { field = v; order.forEach { it.editing = v } }
    var onChanged: () -> Unit = {}

    private val order = ArrayList<CcButton>()
    private val pos = ArrayList<Rect>()
    private val handler = Handler(Looper.getMainLooper())
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var cell = 0
    private var dragView: CcButton? = null
    private var dragDx = 0f
    private var dragDy = 0f
    private var downChild: CcButton? = null
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private val longPress = Runnable { downChild?.let { startDrag(it) } }

    val ids: List<CcButton> get() = order

    fun setTiles(list: List<CcButton>) {
        removeAllViews(); order.clear()
        list.forEach { order.add(it); addView(it) }
        order.forEach { it.editing = editing }
        requestLayout()
    }

    private fun computePositions(width: Int): Int {
        cell = (width - gapPx * (cols - 1)) / cols
        pos.clear()
        var col = 0
        var row = 0
        for (b in order) {
            val span = b.span.coerceIn(1, cols)
            if (col + span > cols) { col = 0; row++ }
            val l = col * (cell + gapPx)
            val t = row * (cell + gapPx)
            pos.add(Rect(l, t, l + span * cell + (span - 1) * gapPx, t + cell))
            col += span
            if (col >= cols) { col = 0; row++ }
        }
        return pos.maxOfOrNull { it.bottom } ?: 0
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val width = MeasureSpec.getSize(wSpec)
        val height = computePositions(width)
        order.forEachIndexed { i, b ->
            val r = pos[i]
            b.measure(
                MeasureSpec.makeMeasureSpec(r.width(), MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(r.height(), MeasureSpec.EXACTLY)
            )
        }
        setMeasuredDimension(width, height)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        order.forEachIndexed { i, v -> val p = pos[i]; v.layout(p.left, p.top, p.right, p.bottom) }
    }

    private fun hit(x: Float, y: Float): CcButton? {
        order.forEachIndexed { i, v -> if (pos.getOrNull(i)?.contains(x.toInt(), y.toInt()) == true) return v }
        return null
    }

    override fun onInterceptTouchEvent(e: MotionEvent): Boolean = editing

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!editing) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = e.x; downY = e.y; moved = false
                downChild = hit(e.x, e.y)
                if (downChild != null) handler.postDelayed(longPress, 260)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!moved && hypot(e.x - downX, e.y - downY) > slop) {
                    moved = true
                    if (dragView == null) handler.removeCallbacks(longPress)
                }
                dragView?.let { moveDrag(it, e.x, e.y) }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longPress)
                val c = downChild
                if (dragView != null) endDrag()
                else if (e.actionMasked == MotionEvent.ACTION_UP && !moved && c != null) tapInEdit(c, e.x, e.y)
                downChild = null
            }
        }
        return true
    }

    private fun tapInEdit(c: CcButton, x: Float, y: Float) {
        val p = pos[order.indexOf(c)]
        if (x < p.left + context.dp(28) && y < p.top + context.dp(28)) {
            order.remove(c); removeView(c)
        } else {
            c.span = if (c.span == 1) 2 else 1
            c.invalidate()
        }
        requestLayout(); onChanged()
    }

    private fun startDrag(c: CcButton) {
        dragView = c
        val p = pos[order.indexOf(c)]
        dragDx = downX - p.left; dragDy = downY - p.top
        c.translationZ = context.dp(12).toFloat()
        c.scaleX = 1.08f; c.scaleY = 1.08f
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
    }

    private fun moveDrag(c: CcButton, x: Float, y: Float) {
        var i = order.indexOf(c)
        val target = pos.indices.firstOrNull { it != i && pos[it].contains(x.toInt(), y.toInt()) }
        if (target != null) {
            order.removeAt(i); order.add(target, c)
            computePositions(width)
            requestLayout()
            i = target
        }
        val p = pos[i]
        c.translationX = x - dragDx - p.left
        c.translationY = y - dragDy - p.top
    }

    private fun endDrag() {
        dragView?.let {
            it.animate().translationX(0f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(160).start()
            it.translationZ = 0f
        }
        dragView = null
        requestLayout(); onChanged()
    }
}

/**
 * Control Center bergaya iOS 27 (Liquid Glass). Dipakai di dalam launcher ([host] = layar utama)
 * dan sebagai overlay di atas semua aplikasi ([host] = window overlay, izin SYSTEM_ALERT_WINDOW saja).
 *
 * Toggle Wi-Fi, data, Bluetooth, dan mode pesawat dilarang Android untuk aplikasi biasa. Jalurnya:
 * Shizuku / root kalau ada ([Sys]); kalau tidak ada, tombol membuka panel sistem dan statusnya tetap tampil.
 */
class ControlCenter(
    private val ctx: Context,
    private val host: FrameLayout,
    private val topInset: () -> Int,
    private val backdrop: Boolean,
    private val openSearch: () -> Unit,
    private val onClosed: () -> Unit = {},
    private val onShown: () -> Unit = {}
) {
    private class Spec(
        val glyph: G, val label: String,
        val tap: () -> Unit, val long: () -> Unit, val state: () -> Boolean
    )

    private var view: FrameLayout? = null
    val isShowing: Boolean get() = view != null

    private val handler = Handler(Looper.getMainLooper())
    private val camera = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var torchId: String? = null
    private var torchOn = false
    private var askedWrite = false
    private var editing = false

    private var specs: Map<String, Spec> = emptyMap()
    private val live = ArrayList<CcButton>()          // semua tombol yang tampil, untuk refresh status
    private val hitViews = ArrayList<View>()          // area konten; ketukan di luarnya menutup panel
    private var grid: TileGrid? = null
    private var tray: TileGrid? = null
    private var trayLabel: TextView? = null
    private var plus: TextView? = null
    private var clock: TextView? = null
    private var date: TextView? = null
    private var batt: TextView? = null
    private var bright: VSlider? = null
    private var vol: VSlider? = null

    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(id: String, enabled: Boolean) {
            if (id == torchId) { torchOn = enabled; refreshStates() }
        }
    }

    private val refresher = object : Runnable {
        override fun run() {
            if (view == null) return
            refreshStates()
            handler.postDelayed(this, 1500)
        }
    }

    private fun go(vararg intents: Intent) {
        close()
        if (!ctx.startSafe(*intents)) Toast.makeText(ctx, "Tidak bisa dibuka di HP ini", Toast.LENGTH_SHORT).show()
    }

    private fun bg(block: () -> Unit) {
        Thread { try { block() } catch (_: Throwable) {}; handler.postDelayed({ refreshStates() }, 700) }.start()
    }

    // ------------------------------------------------------------- status

    private fun wifiOn(): Boolean = try {
        (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled
    } catch (_: Exception) { false }

    private fun dataOn(): Boolean = try {
        Settings.Global.getInt(ctx.contentResolver, "mobile_data", 1) == 1
    } catch (_: Exception) { false }

    private fun airplaneOn(): Boolean = try {
        Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
    } catch (_: Exception) { false }

    private fun btOn(): Boolean = try { BluetoothAdapter.getDefaultAdapter()?.isEnabled == true } catch (_: Exception) { false }

    private fun rotationLocked(): Boolean = try {
        Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
    } catch (_: Exception) { false }

    private fun dndOn(): Boolean = try {
        val f = (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).currentInterruptionFilter
        f != NotificationManager.INTERRUPTION_FILTER_ALL && f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
    } catch (_: Exception) { false }

    private fun refreshStates() {
        if (view == null) return
        live.forEach { b -> specs[b.id]?.let { b.on = it.state() } }
        val now = Date()
        clock?.text = SimpleDateFormat("HH.mm", Locale("id")).format(now)
        date?.text = SimpleDateFormat("EEE, d MMM", Locale("id")).format(now)
        try {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val lv = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val ch = (i?.getIntExtra(BatteryManager.EXTRA_STATUS, 0) ?: 0).let {
                it == BatteryManager.BATTERY_STATUS_CHARGING || it == BatteryManager.BATTERY_STATUS_FULL
            }
            if (lv >= 0) batt?.text = (if (ch) "⚡ " else "") + (lv * 100 / sc) + "%"
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------- aksi

    private fun findTorch() {
        if (torchId != null) return
        torchId = try {
            camera.cameraIdList.firstOrNull {
                val ch = camera.getCameraCharacteristics(it)
                ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
        } catch (_: Exception) { null }
    }

    private fun toggleTorch() {
        val id = torchId
        if (id == null) { Toast.makeText(ctx, "HP ini tidak punya senter", Toast.LENGTH_SHORT).show(); return }
        try { camera.setTorchMode(id, !torchOn) } catch (_: Exception) {
            Toast.makeText(ctx, "Senter sedang dipakai aplikasi lain", Toast.LENGTH_SHORT).show()
        }
    }

    private fun askWriteSettings() {
        if (askedWrite) return
        askedWrite = true
        Toast.makeText(ctx, "Izinkan \"Ubah pengaturan sistem\" dulu", Toast.LENGTH_LONG).show()
        close()
        ctx.startSafe(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
    }

    private fun toggleRotation() {
        if (!Settings.System.canWrite(ctx)) { askWriteSettings(); return }
        try {
            Settings.System.putInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (rotationLocked()) 1 else 0)
        } catch (_: Exception) {}
        refreshStates()
    }

    /** Jangan Ganggu butuh izin "Akses Jangan Ganggu" (NOTIFICATION_POLICY_ACCESS). */
    private fun toggleDnd() {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) {
            Toast.makeText(ctx, "Izinkan akses Jangan Ganggu dulu", Toast.LENGTH_LONG).show()
            go(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return
        }
        nm.setInterruptionFilter(
            if (dndOn()) NotificationManager.INTERRUPTION_FILTER_ALL else NotificationManager.INTERRUPTION_FILTER_PRIORITY
        )
        refreshStates()
    }

    /** Dering -> Getar -> Hening -> Dering. Hening butuh akses Jangan Ganggu; tanpa itu hanya Dering <-> Getar. */
    private fun cycleRinger() {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            audio.ringerMode = when (audio.ringerMode) {
                AudioManager.RINGER_MODE_NORMAL -> AudioManager.RINGER_MODE_VIBRATE
                AudioManager.RINGER_MODE_VIBRATE -> if (nm.isNotificationPolicyAccessGranted) AudioManager.RINGER_MODE_SILENT else AudioManager.RINGER_MODE_NORMAL
                else -> AudioManager.RINGER_MODE_NORMAL
            }
            val label = when (audio.ringerMode) {
                AudioManager.RINGER_MODE_VIBRATE -> "Getar"
                AudioManager.RINGER_MODE_SILENT -> "Hening"
                else -> "Dering"
            }
            Toast.makeText(ctx, label, Toast.LENGTH_SHORT).show()
        } catch (_: Exception) { go(Intent(Settings.ACTION_SOUND_SETTINGS)) }
        refreshStates()
    }

    /** Toggle yang butuh Shizuku/root. Kalau tidak ada, buka panel sistem dan beri tahu kenapa. */
    private fun privilegedToggle(want: Boolean, run: (Boolean) -> Boolean, fallback: Intent, vararg more: Intent) {
        Thread {
            val ok = try { run(want) } catch (_: Throwable) { false }
            handler.post {
                if (!ok) {
                    Toast.makeText(ctx, "Satu ketukan butuh Shizuku (Settings > Izin). Sementara dibuka halaman pengaturannya", Toast.LENGTH_LONG).show()
                    go(fallback, *more)
                } else handler.postDelayed({ refreshStates() }, 700)
            }
        }.start()
    }

    private fun setBrightness(v: Float) {
        if (Settings.System.canWrite(ctx)) {
            try {
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS,
                    (v * 255).toInt().coerceIn(1, 255))
            } catch (_: Exception) {}
        } else {
            val win = (ctx as? Activity)?.window
            if (win != null) {
                val lp = win.attributes
                lp.screenBrightness = v.coerceIn(0.02f, 1f)
                win.attributes = lp
            }
            askWriteSettings()
        }
    }

    private fun currentBrightness(): Float = try {
        (Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f).coerceIn(0f, 1f)
    } catch (_: Exception) { 0.5f }

    private fun volumeFraction(): Float =
        audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)

    private fun buildSpecs(): Map<String, Spec> {
        val internet = Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
        val m = LinkedHashMap<String, Spec>()
        m["WIFI"] = Spec(G.WIFI, "Wi-Fi",
            { privilegedToggle(!wifiOn(), { Sys.wifi(it) }, Intent(Settings.Panel.ACTION_WIFI)) },
            { go(Intent(Settings.ACTION_WIFI_SETTINGS)) }, { wifiOn() })
        m["DATA"] = Spec(G.CELL, "Data Seluler",
            { privilegedToggle(!dataOn(), { Sys.mobileData(it) }, internet, Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS), Intent(Settings.ACTION_DATA_ROAMING_SETTINGS), Intent(Settings.ACTION_WIRELESS_SETTINGS)) },
            { go(internet, Intent(Settings.ACTION_NETWORK_OPERATOR_SETTINGS), Intent(Settings.ACTION_DATA_ROAMING_SETTINGS), Intent(Settings.ACTION_WIRELESS_SETTINGS)) }, { dataOn() })
        m["BT"] = Spec(G.BT, "Bluetooth",
            { privilegedToggle(!btOn(), { Sys.bluetooth(it) }, Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) },
            { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }, { btOn() })
        m["AIRPLANE"] = Spec(G.AIRPLANE, "Mode Pesawat",
            { privilegedToggle(!airplaneOn(), { Sys.airplane(it) }, Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) },
            { go(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) }, { airplaneOn() })
        m["TORCH"] = Spec(G.TORCH, "Senter", { toggleTorch() },
            { go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }, { torchOn })
        m["ROTATE"] = Spec(G.ROTATE, "Kunci Rotasi", { toggleRotation() },
            { go(Intent(Settings.ACTION_DISPLAY_SETTINGS)) }, { rotationLocked() })
        m["DND"] = Spec(G.MOON, "Jangan Ganggu", { toggleDnd() },
            { go(Intent("android.settings.ZEN_MODE_SETTINGS"), Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) }, { dndOn() })
        m["RINGER"] = Spec(G.BELL, "Dering / Hening", { cycleRinger() },
            { go(Intent(Settings.ACTION_SOUND_SETTINGS)) },
            { audio.ringerMode != AudioManager.RINGER_MODE_NORMAL })
        m["MIRROR"] = Spec(G.PHONE, "Screen Mirroring",
            { go(Intent("android.settings.CAST_SETTINGS"), Intent(Settings.ACTION_WIRELESS_SETTINGS)) },
            { go(Intent("android.settings.CAST_SETTINGS"), Intent(Settings.ACTION_WIRELESS_SETTINGS)) }, { false })
        val calc = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR)
        m["CALC"] = Spec(G.CALC, "Kalkulator", { go(calc) }, { go(calc) }, { false })
        m["CAMERA"] = Spec(G.CAMERA, "Kamera",
            { go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) },
            { go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }, { false })
        m["HOTSPOT"] = Spec(G.HOTSPOT, "Hotspot", { close(); ctx.openHotspotSettings() },
            { close(); ctx.openHotspotSettings() }, { HotspotState.on })
        m["RECORD"] = Spec(G.RECORD, "Rekam Layar",
            {
                // tutup panel dulu supaya panel tidak ikut terekam
                val stopping = ScreenRecorder.recording
                close()
                handler.postDelayed({ ScreenRecorder.toggle(ctx) }, if (stopping) 0L else 350L)
            },
            { close(); ctx.startSafe(Intent(Intent.ACTION_VIEW).setDataAndType(android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "video/*")) },
            { ScreenRecorder.recording })
        m["SHOT"] = Spec(G.SHOT, "Screenshot",
            {
                val a11y = ShadeAccessibilityService.instance
                if (a11y == null) Toast.makeText(ctx, "Nyalakan Aksesibilitas \"iOS 27 Panel\" dulu (Settings > Izin)", Toast.LENGTH_LONG).show()
                else { close(); handler.postDelayed({ a11y.screenshot() }, 450) }
            },
            { close(); ctx.startSafe(Intent(Intent.ACTION_VIEW).setDataAndType(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*")) },
            { false })
        m["SAVER"] = Spec(G.BOLT, "Hemat Baterai",
            { go(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS), Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) },
            { go(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS), Intent(Intent.ACTION_POWER_USAGE_SUMMARY)) }, { false })
        m["SEARCH"] = Spec(G.SEARCH, "Cari", { close(); openSearch() }, { close(); openSearch() }, { false })
        m["SETTINGS"] = Spec(G.GEAR, "Pengaturan",
            { go(Intent(ctx, SettingsActivity::class.java)) }, { go(Intent(Settings.ACTION_SETTINGS)) }, { false })
        return m
    }

    // ------------------------------------------------------------ tombol

    private fun makeButton(id: String, span: Int, circle: Boolean): CcButton? {
        val s = specs[id] ?: return null
        return CcButton(ctx, id, s.glyph, backdrop, circle).also { b ->
            b.label = s.label
            b.span = span
            b.on = s.state()
            b.setOnClickListener {
                if (Prefs.bool(ctx, Prefs.HAPTIC)) b.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                s.tap()
            }
            b.setOnLongClickListener {
                b.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                s.long(); true
            }
            live.add(b)
        }
    }

    private fun parseTiles(): MutableList<Pair<String, Int>> {
        val raw = Prefs.str(ctx, Prefs.CC_TILES)
        return raw.split(',').mapNotNull {
            val p = it.split(':')
            val id = p.getOrNull(0)?.trim().orEmpty()
            if (id in specs && id !in CONNECT) id to (p.getOrNull(1)?.toIntOrNull() ?: 1).coerceIn(1, 2) else null
        }.distinctBy { it.first }.toMutableList()
    }

    private fun saveTiles() {
        val g = grid ?: return
        Prefs.setStr(ctx, Prefs.CC_TILES, g.ids.joinToString(",") { "${it.id}:${it.span}" })
        rebuildTray()
    }

    private fun rebuildGrid() {
        live.removeAll { it.id !in CONNECT }
        val g = grid ?: return
        g.setTiles(parseTiles().mapNotNull { (id, span) -> makeButton(id, span, false) })
        g.editing = editing
        rebuildTray()
    }

    private fun rebuildTray() {
        val t = tray ?: return
        val used = grid?.ids?.map { it.id }?.toSet() ?: emptySet()
        live.removeAll { b -> b.parent === t }
        val rest = specs.keys.filter { it !in used && it !in CONNECT }
        t.setTiles(rest.mapNotNull { id ->
            makeButton(id, 1, false)?.also { b ->
                b.setOnClickListener {
                    val g = grid ?: return@setOnClickListener
                    val ids = g.ids.map { "${it.id}:${it.span}" } + "${b.id}:1"
                    Prefs.setStr(ctx, Prefs.CC_TILES, ids.joinToString(","))
                    rebuildGrid()
                }
                b.setOnLongClickListener(null)
            }
        })
        val show = editing && rest.isNotEmpty()
        t.visibility = if (show) View.VISIBLE else View.GONE
        trayLabel?.visibility = t.visibility
    }

    private fun setEditing(v: Boolean) {
        editing = v
        grid?.editing = v
        plus?.text = if (v) "Selesai" else "+"
        plus?.textSize = if (v) 17f else 30f
        rebuildTray()
    }

    // --------------------------------------------------------------- tampil

    fun show() {
        close()
        findTorch()
        specs = buildSpecs()
        if (!Prefs.bool(ctx, Prefs.CC_V6)) {
            // pengguna lama: tambahkan tombol Rekam Layar dan Screenshot sekali saja
            Prefs.setBool(ctx, Prefs.CC_V6, true)
            var raw = Prefs.str(ctx, Prefs.CC_TILES)
            for (id in listOf("RECORD", "SHOT")) if (!raw.split(',').any { it.startsWith("$id:") }) raw += ",$id:1"
            Prefs.setStr(ctx, Prefs.CC_TILES, raw.trimStart(','))
        }
        live.clear(); hitViews.clear(); editing = false
        try { camera.registerTorchCallback(torchCb, handler) } catch (_: Exception) {}

        val scrim = FrameLayout(ctx).apply {
            // hitam transparan ~40%; blur di belakang jendela diatur oleh ShadeController (FLAG_BLUR_BEHIND)
            val blurOk = !backdrop && android.os.Build.VERSION.SDK_INT >= 31 &&
                (ctx.getSystemService(android.view.WindowManager::class.java)?.isCrossWindowBlurEnabled == true)
            // di atas aplikasi lain tanpa blur jendela: scrim digelapkan sedikit lebih pekat supaya tetap terbaca
            setBackgroundColor(Color.argb(if (backdrop) 150 else if (blurOk) 90 else 140, 0, 0, 0))
            isClickable = true
            setOnClickListener { close() }
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.dp(16), topInset() + ctx.dp(8), ctx.dp(16), ctx.dp(40))
        }
        val gap = ctx.dp(12)

        // ---- header: jam + tanggal di kiri, baterai di kanan
        val head = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        val sans = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
        clock = TextView(ctx).apply { textSize = 22f; setTextColor(Color.WHITE); typeface = sans }
        date = TextView(ctx).apply { textSize = 14f; setTextColor(Color.parseColor("#D1D1D6")); setPadding(ctx.dp(10), 0, 0, 0) }
        batt = TextView(ctx).apply { textSize = 14f; setTextColor(Color.WHITE); typeface = sans; gravity = Gravity.END }
        head.addView(clock); head.addView(date)
        head.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
        head.addView(batt)
        col.addView(head, LinearLayout.LayoutParams(MATCH, ctx.dp(40)).apply { bottomMargin = gap / 2 })

        // ---- baris 1: kotak konektivitas (kiri) + dua slider vertikal (kanan)
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = ctx.glass(28, true, backdrop)
            setPadding(ctx.dp(6), ctx.dp(6), ctx.dp(6), ctx.dp(6))
        }
        val size = ctx.dp(62)
        listOf(listOf("WIFI", "DATA"), listOf("BT", "AIRPLANE")).forEach { ids ->
            val r = LinearLayout(ctx)
            ids.forEach { id ->
                val cell = FrameLayout(ctx)
                makeButton(id, 1, true)?.let { cell.addView(it, FrameLayout.LayoutParams(size, size, Gravity.CENTER)) }
                r.addView(cell, LinearLayout.LayoutParams(0, MATCH, 1f))
            }
            box.addView(r, LinearLayout.LayoutParams(MATCH, 0, 1f))
        }
        bright = VSlider(ctx, G.SUN, backdrop) { setBrightness(it) }.also { it.value = currentBrightness() }
        vol = VSlider(ctx, G.NOTE, backdrop) {
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (it * max).toInt(), 0)
        }.also { it.value = volumeFraction() }
        val row1 = LinearLayout(ctx)
        row1.addView(box, LinearLayout.LayoutParams(0, MATCH, 1f).apply { marginEnd = gap / 2 })
        row1.addView(bright, LinearLayout.LayoutParams(0, MATCH, 0.5f).apply { marginStart = gap / 2; marginEnd = gap / 2 })
        row1.addView(vol, LinearLayout.LayoutParams(0, MATCH, 0.5f).apply { marginStart = gap / 2 })
        col.addView(row1, LinearLayout.LayoutParams(MATCH, ctx.dp(176)).apply { bottomMargin = gap })
        hitViews.add(box); hitViews.add(bright!!); hitViews.add(vol!!)

        // ---- grid tombol 4 kolom
        val g = TileGrid(ctx, 4, gap)
        g.onChanged = { saveTiles() }
        grid = g
        col.addView(g, LinearLayout.LayoutParams(MATCH, WRAP))
        hitViews.add(g)

        // ---- tray "Tambah tombol" (hanya saat edit mode)
        trayLabel = TextView(ctx).apply {
            text = "Tambah tombol"; textSize = 13f; setTextColor(Color.parseColor("#D1D1D6")); visibility = View.GONE
        }
        col.addView(trayLabel, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = gap * 2; bottomMargin = gap / 2; marginStart = ctx.dp(6) })
        tray = TileGrid(ctx, 4, gap).also { it.visibility = View.GONE }
        col.addView(tray, LinearLayout.LayoutParams(MATCH, WRAP))
        hitViews.add(tray!!)

        // ---- tombol + (Edit / Tambah tombol)
        plus = TextView(ctx).apply {
            text = "+"; textSize = 30f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = ctx.glass(28, true, backdrop)
            minWidth = ctx.dp(64); minHeight = ctx.dp(64)
            setPadding(ctx.dp(18), 0, ctx.dp(18), 0)
            setOnClickListener { setEditing(!editing) }
        }
        col.addView(plus, LinearLayout.LayoutParams(WRAP, ctx.dp(64)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = gap * 2 })
        hitViews.add(plus!!)

        rebuildGrid()

        val scroll = ScrollView(ctx).apply {
            isVerticalScrollBarEnabled = false
            // layar lebar (landscape / tablet): konten dibatasi 400dp dan di tengah, supaya tidak melar
            val wide = ctx.resources.displayMetrics.widthPixels > ctx.dp(520)
            addView(col, FrameLayout.LayoutParams(if (wide) ctx.dp(400) else MATCH, WRAP,
                if (wide) Gravity.CENTER_HORIZONTAL else Gravity.START))
        }
        // geser ke atas = tutup, ketuk di luar kartu = tutup (ScrollView menelan klik, jadi dicek manual)
        var downX = 0f
        var downY = 0f
        val slop = android.view.ViewConfiguration.get(ctx).scaledTouchSlop
        scroll.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY }
                MotionEvent.ACTION_UP -> {
                    val dy = downY - e.rawY
                    if (!editing && dy > ctx.dp(90)) close()
                    else if (kotlin.math.abs(dy) < slop && kotlin.math.abs(e.rawX - downX) < slop && !touchesContent(e.rawX, e.rawY)) {
                        if (editing) setEditing(false) else close()
                    }
                }
            }
            false
        }
        scrim.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))

        refreshStates()
        handler.postDelayed(refresher, 1500)

        scrim.alpha = 0f
        col.scaleX = 0.94f; col.scaleY = 0.94f
        col.pivotX = minOf(ctx.resources.displayMetrics.widthPixels, ctx.dp(400)) * 0.8f
        col.pivotY = 0f
        host.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))
        val ease = android.view.animation.PathInterpolator(0.2f, 0.85f, 0.25f, 1f)
        scrim.animate().alpha(1f).setDuration(260).setInterpolator(ease).start()
        col.animate().scaleX(1f).scaleY(1f).setDuration(340).setInterpolator(ease).start()
        view = scrim
        onShown()
    }

    private fun touchesContent(x: Float, y: Float): Boolean {
        val r = Rect()
        for (v in hitViews) {
            if (v.visibility != View.VISIBLE || !v.getGlobalVisibleRect(r)) continue
            if (r.contains(x.toInt(), y.toInt())) return true
        }
        return false
    }

    fun close() {
        val v = view ?: return
        view = null
        editing = false
        handler.removeCallbacks(refresher)
        try { camera.unregisterTorchCallback(torchCb) } catch (_: Exception) {}
        live.clear(); hitViews.clear()
        grid = null; tray = null; trayLabel = null; plus = null
        clock = null; date = null; batt = null; bright = null; vol = null
        v.animate().alpha(0f).setDuration(160).withEndAction {
            try { host.removeView(v) } catch (_: Exception) {}
            onClosed()
        }.start()
    }

    private companion object {
        val CONNECT = setOf("WIFI", "DATA", "BT", "AIRPLANE")
    }
}
