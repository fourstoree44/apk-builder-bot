package com.ios27.launcher

import android.app.Activity
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Slider vertikal tebal ala iOS (kecerahan, volume), dengan latar kaca. */
class VSlider(
    ctx: Context, private val glyph: G, backdrop: Boolean, private val onValue: (Float) -> Unit
) : View(ctx) {
    var value = 0.5f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F5FFFFFF") }
    private val clip = Path()
    private val rect = RectF()

    init { background = ctx.glass(30, true, backdrop) }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        val r = context.dp(30).toFloat()
        rect.set(0f, 0f, w, h)
        clip.reset(); clip.addRoundRect(rect, r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        c.drawRect(0f, h * (1f - value), w, h, fill)
        c.restore()
        val gy = h - context.dp(34).toFloat()
        val covered = h * (1f - value) < gy - context.dp(12)
        Glyphs.draw(c, glyph, w / 2f, gy, context.dp(26).toFloat(), if (covered) Color.parseColor("#3A3A3C") else Color.WHITE)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                value = 1f - e.y / height
                onValue(value)
            }
        }
        return true
    }
}

/** Tombol bulat (konektivitas): abu-abu transparan saat mati, berwarna saat hidup. */
class RoundToggle(ctx: Context, private val glyph: G, private val onColor: Int, click: () -> Unit) : View(ctx) {
    var on = false
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init { setOnClickListener { click() } }

    override fun onDraw(c: Canvas) {
        val r = minOf(width, height) / 2f
        p.color = if (on) onColor else Color.argb(80, 255, 255, 255)
        c.drawCircle(width / 2f, height / 2f, r, p)
        val dark = on && onColor == Color.WHITE
        Glyphs.draw(c, glyph, width / 2f, height / 2f, r * 1.0f, if (dark) Color.parseColor("#1C1C1E") else Color.WHITE)
    }
}

/** Tombol kotak kaca (senter, hotspot, dsb) yang terisi warna saat hidup. */
class ModuleButton(
    ctx: Context, private val glyph: G, private val onColor: Int, backdrop: Boolean, click: () -> Unit
) : View(ctx) {
    var on = false
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    init {
        background = ctx.glass(26, true, backdrop)
        setOnClickListener { click() }
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        if (on) {
            p.color = onColor
            val r = context.dp(26).toFloat()
            rect.set(0f, 0f, width.toFloat(), height.toFloat())
            c.drawRoundRect(rect, r, r, p)
        }
        val dark = on && onColor == Color.WHITE
        Glyphs.draw(c, glyph, width / 2f, height / 2f, minOf(width, height) * 0.42f,
            if (dark) Color.parseColor("#1C1C1E") else Color.WHITE)
    }
}

/** Kartu lagu (Control Center dan Notification Center). Mendengarkan lagu selama terpasang di layar. */
class MediaCard(ctx: Context, backdrop: Boolean, private val onNoAccess: () -> Unit) : LinearLayout(ctx) {
    private val art = ImageView(ctx)
    private val title = TextView(ctx)
    private val artist = TextView(ctx)
    private val play = GlyphView(ctx, G.PLAY, Color.WHITE, 0.55f)
    private val listener: (MediaWatcher.Info?) -> Unit = { update(it) }

    init {
        orientation = LinearLayout.VERTICAL
        background = ctx.glass(28, true, backdrop)
        setPadding(ctx.dp(14), ctx.dp(14), ctx.dp(14), ctx.dp(8))
        setOnClickListener {
            if (!MediaWatcher.isAccessGranted(ctx)) onNoAccess() else MediaWatcher.openApp()
        }

        val top = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        art.background = GradientDrawable().apply { cornerRadius = ctx.dp(11).toFloat(); setColor(Color.parseColor("#33FFFFFF")) }
        art.clipToOutline = true
        top.addView(art, LinearLayout.LayoutParams(ctx.dp(46), ctx.dp(46)))
        val names = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        title.apply { textSize = 14f; setTextColor(Color.WHITE); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD) }
        artist.apply { textSize = 12f; setTextColor(Color.parseColor("#C7C7CC")); maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        names.addView(title); names.addView(artist)
        top.addView(names, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = ctx.dp(10) })
        addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        val row = LinearLayout(ctx).apply { gravity = Gravity.CENTER }
        row.addView(GlyphView(ctx, G.PREV, Color.WHITE, 0.5f).apply { setOnClickListener { MediaWatcher.previous() } },
            LinearLayout.LayoutParams(0, MATCH, 1f))
        play.setOnClickListener { MediaWatcher.toggle() }
        row.addView(play, LinearLayout.LayoutParams(0, MATCH, 1f))
        row.addView(GlyphView(ctx, G.NEXT, Color.WHITE, 0.5f).apply { setOnClickListener { MediaWatcher.next() } },
            LinearLayout.LayoutParams(0, MATCH, 1f))
        addView(row, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    private fun update(i: MediaWatcher.Info?) {
        title.text = i?.title ?: "Tidak diputar"
        artist.text = i?.artist ?: if (MediaWatcher.isAccessGranted(context)) "" else "Ketuk untuk beri akses"
        play.glyph = if (i?.playing == true) G.PAUSE else G.PLAY
        if (i?.art != null) art.setImageBitmap(i.art) else art.setImageDrawable(null)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        MediaWatcher.addListener(context, listener)
    }

    override fun onDetachedFromWindow() {
        MediaWatcher.removeListener(listener)
        super.onDetachedFromWindow()
    }
}

/**
 * Control Center bergaya iOS. Dipakai di dalam launcher ([host] = layar utama) dan sebagai panel
 * di atas semua aplikasi ([host] = window overlay).
 *
 * Catatan Android: aplikasi biasa tidak boleh menyalakan Wi-Fi, data, atau Bluetooth langsung.
 * Tombol-tombol itu menampilkan statusnya dan membuka panel sistem untuk mengubahnya.
 * Senter, kecerahan, volume, dan kunci rotasi bisa dikontrol langsung.
 */
class ControlCenter(
    private val ctx: Context,
    private val host: FrameLayout,
    private val topInset: () -> Int,
    private val backdrop: Boolean,
    private val openSearch: () -> Unit,
    private val onClosed: () -> Unit = {}
) {
    private var view: FrameLayout? = null
    val isShowing: Boolean get() = view != null

    private val handler = Handler(Looper.getMainLooper())
    private val camera = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var torchId: String? = null
    private var torchOn = false
    private var askedWrite = false

    private var tAirplane: RoundToggle? = null
    private var tData: RoundToggle? = null
    private var tWifi: RoundToggle? = null
    private var tBt: RoundToggle? = null
    private var tHotspot: ModuleButton? = null
    private var tTorch: ModuleButton? = null
    private var tRotate: ModuleButton? = null
    private var tFocus: ModuleButton? = null

    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(id: String, enabled: Boolean) {
            if (id == torchId) { torchOn = enabled; tTorch?.on = enabled }
        }
    }

    private val refresher = object : Runnable {
        override fun run() {
            if (view == null) return
            refreshStates()
            handler.postDelayed(this, 1500)
        }
    }

    private fun go(vararg intents: Intent) {
        close()
        if (!ctx.startSafe(*intents)) Toast.makeText(ctx, "Tidak bisa dibuka di HP ini", Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------- status

    private fun refreshStates() {
        try {
            tAirplane?.on = Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        } catch (_: Exception) {}
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            tData?.on = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
        } catch (_: Exception) {}
        try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            tWifi?.on = wm.isWifiEnabled
        } catch (_: Exception) {}
        try { tBt?.on = BluetoothAdapter.getDefaultAdapter()?.isEnabled == true } catch (_: Exception) {}
        tHotspot?.on = HotspotState.on
        tTorch?.on = torchOn
        try {
            tRotate?.on = Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
        } catch (_: Exception) {}
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            tFocus?.on = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL &&
                nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
        } catch (_: Exception) {}
    }

    private fun findTorch() {
        if (torchId != null) return
        torchId = try {
            camera.cameraIdList.firstOrNull {
                val ch = camera.getCameraCharacteristics(it)
                ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
        } catch (_: Exception) { null }
    }

    private fun toggleTorch() {
        val id = torchId
        if (id == null) { Toast.makeText(ctx, "HP ini tidak punya senter", Toast.LENGTH_SHORT).show(); return }
        try { camera.setTorchMode(id, !torchOn) } catch (_: Exception) {
            Toast.makeText(ctx, "Senter sedang dipakai aplikasi lain", Toast.LENGTH_SHORT).show()
        }
    }

    private fun askWriteSettings() {
        if (askedWrite) return
        askedWrite = true
        Toast.makeText(ctx, "Izinkan \"Ubah pengaturan sistem\" dulu", Toast.LENGTH_LONG).show()
        close()
        ctx.startSafe(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
    }

    private fun toggleRotation() {
        if (!Settings.System.canWrite(ctx)) { askWriteSettings(); return }
        try {
            val locked = Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
            Settings.System.putInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (locked) 1 else 0)
            tRotate?.on = !locked
        } catch (_: Exception) {}
    }

    private fun setBrightness(v: Float) {
        if (Settings.System.canWrite(ctx)) {
            try {
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS,
                    (v * 255).toInt().coerceIn(1, 255))
            } catch (_: Exception) {}
        } else {
            val win = (ctx as? Activity)?.window
            if (win != null) {
                val lp = win.attributes
                lp.screenBrightness = v.coerceIn(0.02f, 1f)
                win.attributes = lp
            }
            askWriteSettings()
        }
    }

    private fun currentBrightness(): Float = try {
        (Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f).coerceIn(0f, 1f)
    } catch (_: Exception) { 0.5f }

    // --------------------------------------------------------------- tampil

    private fun centered(v: View, sizeDp: Int): View = FrameLayout(ctx).apply {
        addView(v, FrameLayout.LayoutParams(ctx.dp(sizeDp), ctx.dp(sizeDp), Gravity.CENTER))
    }

    private fun toggle2x2(a: View, b: View, c: View, d: View, size: Int): LinearLayout {
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = ctx.glass(28, true, backdrop)
            setPadding(ctx.dp(6), ctx.dp(8), ctx.dp(6), ctx.dp(8))
        }
        listOf(listOf(a, b), listOf(c, d)).forEach { pair ->
            val r = LinearLayout(ctx)
            pair.forEach { r.addView(centered(it, size), LinearLayout.LayoutParams(0, MATCH, 1f)) }
            box.addView(r, LinearLayout.LayoutParams(MATCH, 0, 1f))
        }
        return box
    }

    fun show() {
        close()
        val accent = Prefs.accent(ctx)
        findTorch()
        try { camera.registerTorchCallback(torchCb, handler) } catch (_: Exception) {}

        val scrim = FrameLayout(ctx).apply {
            setBackgroundColor(Color.argb(if (backdrop) 150 else 70, 0, 0, 0))
            isClickable = true
            setOnClickListener { close() }
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.dp(16), topInset() + ctx.dp(14), ctx.dp(16), ctx.dp(32))
        }
        val gap = ctx.dp(12)

        // baris 1: konektivitas dan lagu
        tAirplane = RoundToggle(ctx, G.AIRPLANE, Color.parseColor("#FF9F0A")) { go(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) }
        tData = RoundToggle(ctx, G.CELL, Color.parseColor("#30D158")) { go(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) }
        tWifi = RoundToggle(ctx, G.WIFI, accent) { go(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) }
        tBt = RoundToggle(ctx, G.BT, accent) { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        val conn = toggle2x2(tAirplane!!, tData!!, tWifi!!, tBt!!, 58)
        val media = MediaCard(ctx, backdrop) { go(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        val rowA = LinearLayout(ctx)
        rowA.addView(conn, LinearLayout.LayoutParams(0, MATCH, 1f).apply { marginEnd = gap / 2 })
        rowA.addView(media, LinearLayout.LayoutParams(0, MATCH, 1f).apply { marginStart = gap / 2 })
        col.addView(rowA, LinearLayout.LayoutParams(MATCH, ctx.dp(172)).apply { bottomMargin = gap })

        // baris 2: senter, kunci rotasi, hotspot, fokus
        tTorch = ModuleButton(ctx, G.TORCH, Color.WHITE, backdrop) { toggleTorch() }
        tRotate = ModuleButton(ctx, G.ROTATE, Color.parseColor("#FF453A"), backdrop) { toggleRotation() }
        tHotspot = ModuleButton(ctx, G.HOTSPOT, Color.parseColor("#30D158"), backdrop) { close(); ctx.openHotspotSettings() }
        tFocus = ModuleButton(ctx, G.MOON, Color.parseColor("#5E5CE6"), backdrop) {
            go(Intent("android.settings.ZEN_MODE_SETTINGS"), Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        val rowB = LinearLayout(ctx)
        listOf(tTorch!!, tRotate!!, tHotspot!!, tFocus!!).forEachIndexed { i, v ->
            rowB.addView(v, LinearLayout.LayoutParams(0, MATCH, 1f).apply {
                marginStart = if (i == 0) 0 else gap / 2
                marginEnd = if (i == 3) 0 else gap / 2
            })
        }
        col.addView(rowB, LinearLayout.LayoutParams(MATCH, ctx.dp(78)).apply { bottomMargin = gap })

        // baris 3: kecerahan, volume, dan pintasan
        val bright = VSlider(ctx, G.SUN, backdrop) { setBrightness(it) }.also { it.value = currentBrightness() }
        val vol = VSlider(ctx, G.VOLUME, backdrop) {
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (it * max).toInt(), 0)
        }.also {
            it.value = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() /
                audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        }
        val calc = RoundToggle(ctx, G.CALC, Color.WHITE) {
            go(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR))
        }
        val cam = RoundToggle(ctx, G.CAMERA, Color.WHITE) { go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
        val set = RoundToggle(ctx, G.GEAR, Color.WHITE) { go(Intent(ctx, SettingsActivity::class.java)) }
        val find = RoundToggle(ctx, G.SEARCH, Color.WHITE) { close(); openSearch() }
        val tools = toggle2x2(calc, cam, set, find, 50)
        val rowC = LinearLayout(ctx)
        rowC.addView(bright, LinearLayout.LayoutParams(0, MATCH, 1f).apply { marginEnd = gap / 2 })
        rowC.addView(vol, LinearLayout.LayoutParams(0, MATCH, 1f).apply { marginStart = gap / 2; marginEnd = gap / 2 })
        rowC.addView(tools, LinearLayout.LayoutParams(0, MATCH, 1f).apply { marginStart = gap / 2 })
        col.addView(rowC, LinearLayout.LayoutParams(MATCH, ctx.dp(172)))

        val scroll = ScrollView(ctx).apply {
            isVerticalScrollBarEnabled = false
            addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        }
        // geser ke atas di area kosong menutup panel
        var downY = 0f
        scroll.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> downY = e.rawY
                MotionEvent.ACTION_UP -> if (downY - e.rawY > ctx.dp(90)) close()
            }
            false
        }
        scrim.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))

        refreshStates()
        handler.postDelayed(refresher, 1500)

        scrim.alpha = 0f
        col.scaleX = 0.94f; col.scaleY = 0.94f
        col.pivotX = ctx.resources.displayMetrics.widthPixels * 0.8f
        col.pivotY = 0f
        host.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))
        scrim.animate().alpha(1f).setDuration(220).start()
        col.animate().scaleX(1f).scaleY(1f).setDuration(260).start()
        view = scrim
    }

    fun close() {
        val v = view ?: return
        view = null
        handler.removeCallbacks(refresher)
        try { camera.unregisterTorchCallback(torchCb) } catch (_: Exception) {}
        tAirplane = null; tData = null; tWifi = null; tBt = null
        tHotspot = null; tTorch = null; tRotate = null; tFocus = null
        v.animate().alpha(0f).setDuration(160).withEndAction {
            try { host.removeView(v) } catch (_: Exception) {}
            onClosed()
        }.start()
    }
}
