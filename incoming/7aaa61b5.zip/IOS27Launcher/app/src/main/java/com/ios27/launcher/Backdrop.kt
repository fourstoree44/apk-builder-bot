package com.ios27.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.net.Uri
import java.io.File
import kotlin.math.max

/**
 * Wallpaper milik launcher + versi blur-nya. Panel Liquid Glass menggambar potongan versi blur
 * ini persis di belakang dirinya, jadi kacanya benar-benar "melihat" wallpaper di belakangnya.
 *
 * Sumber wallpaper: 0 = bawaan (gradasi aurora), 1 = foto pilihan, 2 = wallpaper sistem (tanpa backdrop).
 */
object Backdrop {
    @Volatile var sharp: Bitmap? = null
        private set
    @Volatile var blurred: Bitmap? = null
        private set
    @Volatile var screenW = 1
        private set
    @Volatile var screenH = 1
        private set
    @Volatile var version = 0
        private set

    private var lastKey = ""

    private class Blob(val x: Float, val y: Float, val r: Float, val color: Int)
    private class Style(val name: String, val top: Int, val bottom: Int, val blobs: List<Blob>)

    val STYLE_NAMES = listOf("Aurora", "Sunset", "Ocean", "Graphite")

    private val styles = listOf(
        Style("Aurora", 0xFF0A0F2E.toInt(), 0xFF1B0B3A.toInt(), listOf(
            Blob(0.15f, 0.10f, 0.55f, 0xDD3D5AFE.toInt()),
            Blob(0.95f, 0.28f, 0.50f, 0xCCB44CFF.toInt()),
            Blob(0.20f, 0.62f, 0.52f, 0xCCFF4F9A.toInt()),
            Blob(0.85f, 0.90f, 0.55f, 0xDD00B8FF.toInt()),
            Blob(0.50f, 0.45f, 0.30f, 0x88FFB36B.toInt())
        )),
        Style("Sunset", 0xFF2A0A24.toInt(), 0xFF120A2E.toInt(), listOf(
            Blob(0.85f, 0.08f, 0.55f, 0xDDFF9F43.toInt()),
            Blob(0.10f, 0.35f, 0.50f, 0xCCFF3D7F.toInt()),
            Blob(0.90f, 0.60f, 0.48f, 0xCCB23CFF.toInt()),
            Blob(0.25f, 0.92f, 0.55f, 0xDD5B5BFF.toInt()),
            Blob(0.55f, 0.40f, 0.28f, 0x88FFD27A.toInt())
        )),
        Style("Ocean", 0xFF031A2B.toInt(), 0xFF020B1A.toInt(), listOf(
            Blob(0.10f, 0.12f, 0.55f, 0xDD00C2C7.toInt()),
            Blob(0.92f, 0.30f, 0.50f, 0xCC1E6BFF.toInt()),
            Blob(0.18f, 0.70f, 0.50f, 0xCC0A84FF.toInt()),
            Blob(0.88f, 0.92f, 0.55f, 0xDD5E5CE6.toInt()),
            Blob(0.55f, 0.50f, 0.28f, 0x8864F0C8.toInt())
        )),
        Style("Graphite", 0xFF0D0E12.toInt(), 0xFF050507.toInt(), listOf(
            Blob(0.15f, 0.10f, 0.55f, 0xAA3A3F55.toInt()),
            Blob(0.90f, 0.40f, 0.50f, 0x99464C66.toInt()),
            Blob(0.30f, 0.85f, 0.55f, 0x99353A52.toInt()),
            Blob(0.60f, 0.55f, 0.28f, 0x55707A9E.toInt())
        ))
    )

    private fun photoFile(ctx: Context) = File(ctx.filesDir, "wallpaper.jpg")

    /** Menyalin foto pilihan ke penyimpanan launcher (sudah diperkecil). true kalau berhasil. */
    fun savePhoto(ctx: Context, uri: Uri, w: Int, h: Int): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= w && bounds.outHeight / (sample * 2) >= h) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val raw = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false
            photoFile(ctx).outputStream().use { raw.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            raw.recycle()
            true
        } catch (_: Throwable) { false }
    }

    private fun loadPhoto(ctx: Context, w: Int, h: Int): Bitmap? {
        val f = photoFile(ctx)
        if (!f.exists()) return null
        return try {
            val raw = BitmapFactory.decodeFile(f.absolutePath) ?: return null
            cropTo(raw, w, h)
        } catch (_: Throwable) { null }
    }

    private fun cropTo(src: Bitmap, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val s = max(w / src.width.toFloat(), h / src.height.toFloat())
        val m = Matrix()
        m.postScale(s, s)
        m.postTranslate((w - src.width * s) / 2f, (h - src.height * s) / 2f)
        Canvas(out).drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    private fun generate(w: Int, h: Int, styleIndex: Int): Bitmap {
        val st = styles[styleIndex.coerceIn(0, styles.size - 1)]
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), st.top, st.bottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        for (b in st.blobs) {
            p.shader = RadialGradient(
                b.x * w, b.y * h, b.r * h, b.color, b.color and 0x00FFFFFF, Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        }
        return bmp
    }

    /** Gambar pratinjau gaya wallpaper bawaan, untuk halaman pengaturan. */
    fun preview(styleIndex: Int, w: Int, h: Int): Bitmap = generate(w, h, styleIndex)

    // ------------------------------------------------------------- blur

    private fun boxPass(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int, horizontal: Boolean) {
        val len = if (horizontal) w else h
        val lines = if (horizontal) h else w
        val div = 2 * r + 1
        for (line in 0 until lines) {
            var sr = 0; var sg = 0; var sb = 0
            for (i in -r..r) {
                val k = i.coerceIn(0, len - 1)
                val p = src[if (horizontal) line * w + k else k * w + line]
                sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
            }
            for (i in 0 until len) {
                dst[if (horizontal) line * w + i else i * w + line] =
                    (0xFF shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val add = src[
                    if (horizontal) line * w + (i + r + 1).coerceAtMost(len - 1)
                    else (i + r + 1).coerceAtMost(len - 1) * w + line
                ]
                val sub = src[
                    if (horizontal) line * w + (i - r).coerceAtLeast(0)
                    else (i - r).coerceAtLeast(0) * w + line
                ]
                sr += ((add shr 16) and 255) - ((sub shr 16) and 255)
                sg += ((add shr 8) and 255) - ((sub shr 8) and 255)
                sb += (add and 255) - (sub and 255)
            }
        }
    }

    private fun makeBlur(src: Bitmap): Bitmap {
        val w = max(8, src.width / 10)
        val h = max(8, src.height / 10)
        val small = Bitmap.createScaledBitmap(src, w, h, true)
        val a = IntArray(w * h)
        val b = IntArray(w * h)
        small.getPixels(a, 0, w, 0, 0, w, h)
        repeat(3) {
            boxPass(a, b, w, h, 4, true)
            boxPass(b, a, w, h, 4, false)
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(a, 0, w, 0, 0, w, h)
        return out
    }

    /** Membuat ulang wallpaper kalau pengaturan atau ukuran layar berubah. true kalau ada yang berubah. */
    @Synchronized
    fun ensure(ctx: Context, w: Int, h: Int): Boolean {
        val mode = Prefs.int(ctx, Prefs.WALL_MODE)
        val style = Prefs.int(ctx, Prefs.WALL_STYLE)
        val stamp = Prefs.int(ctx, Prefs.WALL_STAMP)
        val key = "$mode|$style|$stamp|$w|$h"
        if (key == lastKey) return false
        lastKey = key
        screenW = w; screenH = h
        if (mode == 2) {
            sharp = null; blurred = null; version++
            return true
        }
        val photo = if (mode == 1) loadPhoto(ctx, w, h) else null
        val bmp = photo ?: generate(w, h, style)
        sharp = bmp
        blurred = makeBlur(bmp)
        version++
        return true
    }
}
