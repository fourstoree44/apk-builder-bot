package com.ios27.launcher

import android.app.Notification
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import java.net.Inet4Address
import java.net.NetworkInterface

/**
 * Listener notifikasi. Android hanya mengizinkan aplikasi membaca sesi media aktif (Spotify, dsb)
 * kalau aplikasi itu punya listener notifikasi yang diberi akses oleh pengguna. Listener yang sama
 * dipakai untuk Notification Center dan banner notifikasi di Dynamic Island.
 */
class MediaListenerService : NotificationListenerService() {
    override fun onListenerConnected() {
        NotifHub.service = this
        NotifHub.changed()
        MediaWatcher.ensureStarted(this)
    }

    override fun onListenerDisconnected() {
        if (NotifHub.service === this) NotifHub.service = null
        NotifHub.changed()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        NotifHub.posted(this, sbn)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        NotifHub.changed()
    }
}

/** Pusat data notifikasi: daftar untuk Notification Center dan banner baru untuk Dynamic Island. */
object NotifHub {

    data class Banner(
        val key: String,
        val pkg: String,
        val app: String,
        val title: String,
        val text: String,
        val icon: Bitmap?,
        val intent: PendingIntent?
    )

    @Volatile var service: NotificationListenerService? = null

    private val handler = Handler(Looper.getMainLooper())
    private val changeListeners = ArrayList<() -> Unit>()
    private val bannerListeners = ArrayList<(Banner) -> Unit>()
    private val seen = HashMap<String, Long>()

    fun addChangeListener(l: () -> Unit) { changeListeners += l }
    fun removeChangeListener(l: () -> Unit) { changeListeners -= l }
    fun addBannerListener(l: (Banner) -> Unit) { bannerListeners += l }
    fun removeBannerListener(l: (Banner) -> Unit) { bannerListeners -= l }

    fun changed() {
        handler.post { changeListeners.toList().forEach { it() } }
    }

    /** Notifikasi biasa saja: bukan ringkasan grup, kontrol musik, atau layanan yang berjalan terus. */
    fun isShown(sbn: StatusBarNotification, self: String): Boolean {
        val n = sbn.notification ?: return false
        if (sbn.packageName == self) return false
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return false
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return false
        if (n.flags and Notification.FLAG_FOREGROUND_SERVICE != 0) return false
        if (n.category == Notification.CATEGORY_TRANSPORT) return false
        return true
    }

    fun active(ctx: Context): List<StatusBarNotification> {
        val s = service ?: return emptyList()
        return try {
            s.activeNotifications.orEmpty()
                .filter { isShown(it, ctx.packageName) }
                .sortedByDescending { it.postTime }
        } catch (_: Exception) { emptyList() }
    }

    fun titleOf(sbn: StatusBarNotification): String =
        sbn.notification.extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()

    fun textOf(sbn: StatusBarNotification): String {
        val ex = sbn.notification.extras ?: return ""
        return (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
    }

    fun appName(ctx: Context, pkg: String): String = try {
        val pm = ctx.packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { pkg }

    fun appIcon(ctx: Context, pkg: String, px: Int): Bitmap? = try {
        ctx.packageManager.getApplicationIcon(pkg).toBitmap(px, px)
    } catch (_: Throwable) { null }

    fun posted(ctx: Context, sbn: StatusBarNotification) {
        changed()
        if (!Prefs.bool(ctx, Prefs.ISLAND_NOTIF) || !isShown(sbn, ctx.packageName)) return
        val title = titleOf(sbn)
        val text = textOf(sbn)
        if (title.isBlank() && text.isBlank()) return
        // pembaruan notifikasi yang isinya sama tidak perlu ditampilkan lagi
        val sig = "${sbn.key}|$title|$text"
        val now = SystemClock.elapsedRealtime()
        if (seen[sig]?.let { now - it < 60_000 } == true) return
        seen[sig] = now
        if (seen.size > 80) seen.entries.removeAll { now - it.value > 60_000 }
        val b = Banner(
            key = sbn.key,
            pkg = sbn.packageName,
            app = appName(ctx, sbn.packageName),
            title = title.ifBlank { appName(ctx, sbn.packageName) },
            text = text,
            icon = appIcon(ctx, sbn.packageName, 96),
            intent = sbn.notification.contentIntent
        )
        handler.post { bannerListeners.toList().forEach { it(b) } }
    }

    fun dismiss(key: String) {
        try { service?.cancelNotification(key) } catch (_: Exception) {}
    }

    fun dismissAll() {
        try { service?.cancelAllNotifications() } catch (_: Exception) {}
    }
}

/** Membaca lagu yang sedang diputar (Spotify, YouTube Music, dsb) dari sesi media sistem. */
object MediaWatcher {

    data class Info(
        val title: String,
        val artist: String,
        val art: Bitmap?,
        val playing: Boolean,
        val duration: Long,
        val position: Long,
        val stamp: Long,     // SystemClock.elapsedRealtime saat position diambil
        val speed: Float,
        val pkg: String
    )

    private val handler = Handler(Looper.getMainLooper())
    private val listeners = ArrayList<(Info?) -> Unit>()
    private var appCtx: Context? = null
    private var manager: MediaSessionManager? = null
    private var component: ComponentName? = null
    private var sessionListener: MediaSessionManager.OnActiveSessionsChangedListener? = null
    private var current: MediaController? = null
    private var started = false
    private var lastArtSrc: Bitmap? = null
    private var lastArtOut: Bitmap? = null

    var info: Info? = null
        private set

    fun isAccessGranted(ctx: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { repick() }
        override fun onMetadataChanged(metadata: MediaMetadata?) { rebuild() }
        override fun onSessionDestroyed() { repick() }
    }

    fun addListener(ctx: Context, l: (Info?) -> Unit) {
        appCtx = ctx.applicationContext
        listeners += l
        ensureStarted(ctx)
        l(info)
    }

    fun removeListener(l: (Info?) -> Unit) {
        listeners -= l
        if (listeners.isEmpty()) stop()
    }

    /** Dipanggil lagi saat layar kembali aktif, siapa tahu akses notifikasi baru saja diberikan. */
    fun ensureStarted(ctx: Context) {
        if (started || listeners.isEmpty() || !isAccessGranted(ctx)) return
        try {
            val app = ctx.applicationContext
            val m = app.getSystemService(MediaSessionManager::class.java)
            val cn = ComponentName(app, MediaListenerService::class.java)
            val l = MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }
            m.addOnActiveSessionsChangedListener(l, cn, handler)
            manager = m; component = cn; sessionListener = l; started = true
            pick(m.getActiveSessions(cn))
        } catch (_: SecurityException) {
            started = false
        }
    }

    private fun stop() {
        try { sessionListener?.let { manager?.removeOnActiveSessionsChangedListener(it) } } catch (_: Exception) {}
        try { current?.unregisterCallback(callback) } catch (_: Exception) {}
        sessionListener = null; current = null; started = false; info = null
    }

    private fun repick() {
        try { pick(manager?.getActiveSessions(component)) } catch (_: Exception) { rebuild() }
    }

    private fun pick(list: List<MediaController>?) {
        val all = list.orEmpty()
        val chosen = all.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: all.firstOrNull()
        if (chosen?.sessionToken != current?.sessionToken) {
            try { current?.unregisterCallback(callback) } catch (_: Exception) {}
            current = chosen
            chosen?.registerCallback(callback, handler)
        }
        rebuild()
    }

    private fun rebuild() {
        val c = current
        val md = c?.metadata
        val st = c?.playbackState
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        info = if (c == null || md == null || title.isBlank()) null else {
            val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
            val src = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            if (src !== lastArtSrc) {
                lastArtSrc = src
                lastArtOut = src?.let {
                    if (it.width > 240) Bitmap.createScaledBitmap(it, 240, 240 * it.height / it.width, true) else it
                }
            }
            val state = st?.state
            Info(
                title = title,
                artist = artist,
                art = lastArtOut,
                playing = state == PlaybackState.STATE_PLAYING || state == PlaybackState.STATE_BUFFERING,
                duration = md.getLong(MediaMetadata.METADATA_KEY_DURATION),
                position = st?.position ?: 0L,
                stamp = st?.lastPositionUpdateTime ?: SystemClock.elapsedRealtime(),
                speed = st?.playbackSpeed ?: 1f,
                pkg = c.packageName
            )
        }
        listeners.toList().forEach { it(info) }
    }

    fun previous() { current?.transportControls?.skipToPrevious() }
    fun next() { current?.transportControls?.skipToNext() }
    fun seekTo(ms: Long) { current?.transportControls?.seekTo(ms) }
    fun toggle() {
        val i = info ?: return
        if (i.playing) current?.transportControls?.pause() else current?.transportControls?.play()
    }

    /** Buka aplikasi pemutarnya (Spotify, dsb). */
    fun openApp() {
        val c = current ?: return
        try { c.sessionActivity?.send(); return } catch (_: Exception) {}
        try {
            val ctx = appCtx ?: return
            ctx.packageManager.getLaunchIntentForPackage(c.packageName)?.let {
                ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        } catch (_: Exception) {}
    }
}

/** Status hotspot terakhir yang diketahui, dibaca juga oleh Control Center. */
object HotspotState {
    @Volatile var on = false
        private set
    @Volatile var since = 0L
        private set

    fun update(now: Boolean) {
        if (now && !on) since = SystemClock.elapsedRealtime()
        on = now
    }
}

/**
 * Menghubungkan island ke sumber datanya: baterai, charger, hotspot, notifikasi, dan lagu.
 * Dipakai oleh island di dalam launcher maupun island overlay.
 */
class IslandFeeds(private val ctx: Context, private val island: DynamicIslandView) {

    private val handler = Handler(Looper.getMainLooper())
    private var batteryKnown = false
    private var charging = false
    private var hotspotKnown = false
    private var hotspot = false
    private var running = false

    private val mediaListener: (MediaWatcher.Info?) -> Unit = {
        island.setMedia(if (Prefs.bool(ctx, Prefs.ISLAND_MUSIC)) it else null)
    }

    private val bannerListener: (NotifHub.Banner) -> Unit = { island.showBanner(it) }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_BATTERY_CHANGED -> {
                    val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
                    val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                    val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                    val now = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                        status == BatteryManager.BATTERY_STATUS_FULL
                    island.batteryLevel = if (scale > 0) level * 100 / scale else level
                    island.charging = now
                    if (batteryKnown && now != charging) island.pulseCharge()
                    charging = now
                    batteryKnown = true
                }
                Intent.ACTION_POWER_CONNECTED, Intent.ACTION_POWER_DISCONNECTED -> island.pulseCharge()
                "android.net.wifi.WIFI_AP_STATE_CHANGED", "android.net.conn.TETHER_STATE_CHANGED" ->
                    // antarmuka hotspot butuh sebentar untuk naik, jadi cek lagi sesaat kemudian
                    handler.postDelayed({ checkHotspot() }, 900)
            }
        }
    }

    /** Dicek berkala: siaran sistem untuk hotspot tidak resmi dan tidak muncul di semua HP. */
    private val poll = object : Runnable {
        override fun run() {
            if (!running) return
            checkHotspot()
            handler.postDelayed(this, 2500)
        }
    }

    private val apNames = Regex("^(ap\\d*|ap_br.*|swlan\\d*|softap\\d*|wlan[1-9]|rndis\\d*|ncm\\d*|bt-pan)$")

    private fun hotspotNow(): Boolean {
        try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (wm.javaClass.getMethod("isWifiApEnabled").invoke(wm) as Boolean) return true
        } catch (_: Throwable) {}
        try {
            val all = NetworkInterface.getNetworkInterfaces() ?: return false
            for (ni in all) {
                if (!ni.isUp || ni.isLoopback || !apNames.matches(ni.name.lowercase())) continue
                if (ni.interfaceAddresses.any { it.address is Inet4Address && !it.address.isLoopbackAddress }) return true
            }
        } catch (_: Throwable) {}
        return false
    }

    private fun checkHotspot() = setHotspot(hotspotNow())

    private fun setHotspot(on: Boolean) {
        HotspotState.update(on)
        val enabled = Prefs.bool(ctx, Prefs.ISLAND_HOTSPOT)
        if (hotspotKnown && on == hotspot) return
        val changed = hotspotKnown
        hotspot = on; hotspotKnown = true
        island.setHotspot(on && enabled, HotspotState.since)
        if (changed && enabled) island.pulseHotspot(on)
    }

    fun start() {
        if (running) return
        running = true
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction("android.net.wifi.WIFI_AP_STATE_CHANGED")
            addAction("android.net.conn.TETHER_STATE_CHANGED")
        }
        ContextCompat.registerReceiver(ctx, receiver, f, ContextCompat.RECEIVER_EXPORTED)
        MediaWatcher.addListener(ctx, mediaListener)
        NotifHub.addBannerListener(bannerListener)
        handler.post(poll)
    }

    fun refreshMedia() = MediaWatcher.ensureStarted(ctx)

    fun stop() {
        if (!running) return
        running = false
        handler.removeCallbacksAndMessages(null)
        try { ctx.unregisterReceiver(receiver) } catch (_: Exception) {}
        MediaWatcher.removeListener(mediaListener)
        NotifHub.removeBannerListener(bannerListener)
    }
}
