package com.ios27.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import android.view.Choreographer
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Dynamic Island: kapsul hitam yang berubah bentuk seperti per (spring) mengikuti aktivitas.
 *
 * Aktivitas yang ditampilkan:
 *  - Lagu yang sedang diputar (Spotify, YouTube Music, dsb): cover, equalizer, lalu kontrol penuh saat diketuk
 *  - Hotspot menyala / mati, dengan penghitung waktu
 *  - Charger dicolok / dicabut
 *  - Notifikasi baru
 *  - Jam dan baterai (ketuk kapsul saat tidak ada aktivitas)
 *
 * Ukuran view = kotak yang cukup untuk bentuk terbesar pada animasi yang sedang berjalan, jadi window
 * tidak perlu diubah ukurannya di setiap frame (penting buat overlay di atas aplikasi lain).
 */
class DynamicIslandView(context: Context) : View(context) {

    enum class Kind { IDLE, MUSIC, HOTSPOT, CHARGE, NOTIF, CLOCK }
    enum class Mode { REST, COMPACT, EXPANDED }

    private class Pulse(val kind: Kind, val banner: NotifHub.Banner? = null, val on: Boolean = true)

    private class Spring(var v: Float) {
        var target = v
        var vel = 0f
        fun step(dt: Float, k: Float, c: Float) {
            val a = -k * (v - target) - c * vel
            vel += a * dt
            v += vel * dt
        }
        fun settled() = abs(v - target) < 0.4f && abs(vel) < 4f
        fun snap() { v = target; vel = 0f }
    }

    private val d = resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())
    private val maxW = resources.displayMetrics.widthPixels - 16 * d

    /** Keadaan diam = titik hitam seukuran lubang kamera; kapsul baru melebar kalau ada aktivitas atau titik diketuk. */
    private val restW = 22f * d
    private val restH = 22f * d
    private val bandH = 36f * d
    private val sw = Spring(restW)
    private val sh = Spring(restH)
    private var boxW = (restW + 32 * d).toInt()
    private var boxH = (restH + 16 * d).toInt()
    private var targetW = restW
    private var targetH = restH

    private var kind = Kind.IDLE
    private var mode = Mode.REST
    private var contentT = 1f
    private var expanded = false
    private var pulse: Pulse? = null
    private var media: MediaWatcher.Info? = null
    private var hotspotOn = false
    private var hotspotSince = 0L

    var batteryLevel = 100
        set(v) { field = v.coerceIn(0, 100); invalidate() }
    var charging = false
        set(v) { field = v; invalidate() }

    private var artColor = Color.parseColor("#30D158")
    private var lastArt: Bitmap? = null
    private var glow: Paint? = null

    private var attached = false
    private var running = false
    private var lastFrame = 0L
    private var downInside = false

    private val green = Color.parseColor("#30D158")
    private val grey = Color.parseColor("#AEAEB2")
    private val red = Color.parseColor("#FF453A")

    private val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val medFace = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    private val boldFace = Typeface.create("sans-serif-medium", Typeface.BOLD)
    private val ringBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 6 * d; color = Color.parseColor("#3A3A3C")
        strokeCap = Paint.Cap.ROUND
    }
    private val ringFg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 6 * d; strokeCap = Paint.Cap.ROUND
    }
    private val rect = RectF()
    private val r2 = RectF()
    private val path = Path()
    private val hhmm = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("EEEE, d MMM", Locale.getDefault())

    init {
        val s = Prefs.int(context, Prefs.ISLAND_SCALE) / 100f
        scaleX = s
        scaleY = s
    }

    // ------------------------------------------------------------ siklus

    private val autoCollapse = Runnable { collapse() }
    private val pulseEnd = Runnable { if (!expanded) { pulse = null; resolve() } }

    private val tick = object : Runnable {
        override fun run() {
            invalidate()
            scheduleTick()
        }
    }

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            running = false
            if (!attached) return
            val dt = if (lastFrame == 0L) 1f / 60f
            else ((frameTimeNanos - lastFrame) / 1_000_000_000f).coerceIn(0.002f, 0.033f)
            lastFrame = frameTimeNanos
            repeat(2) {
                sw.step(dt / 2f, 430f, 27f)
                sh.step(dt / 2f, 430f, 27f)
            }
            var busy = false
            if (sw.settled() && sh.settled()) {
                if (sw.v != sw.target || sh.v != sh.target) { sw.snap(); sh.snap(); shrinkBox() }
            } else busy = true
            if (contentT < 1f) { contentT = min(1f, contentT + dt / 0.34f); busy = true }
            invalidate()
            if (busy) {
                running = true
                Choreographer.getInstance().postFrameCallback(this)
            } else {
                lastFrame = 0L
                scheduleTick()
            }
        }
    }

    private fun kick() {
        if (running || !attached) return
        running = true
        lastFrame = 0L
        handler.removeCallbacks(tick)
        Choreographer.getInstance().postFrameCallback(frame)
    }

    private fun scheduleTick() {
        handler.removeCallbacks(tick)
        if (!attached || running) return
        val live = mode != Mode.REST &&
            ((kind == Kind.MUSIC && media?.playing == true) || kind == Kind.HOTSPOT)
        handler.postDelayed(tick, if (live) 33L else 15_000L)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        attached = true
        scheduleTick()
        kick()
    }

    override fun onDetachedFromWindow() {
        attached = false
        running = false
        handler.removeCallbacksAndMessages(null)
        Choreographer.getInstance().removeFrameCallback(frame)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        pivotX = w / 2f
        pivotY = 0f
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(boxW, boxH)
    }

    private fun growBox() {
        val needW = (max(sw.v, targetW) + 32 * d).toInt()
        val needH = (max(sh.v, targetH) + 16 * d).toInt()
        if (needW > boxW || needH > boxH) {
            boxW = max(boxW, needW); boxH = max(boxH, needH)
            requestLayout()
        }
    }

    private fun shrinkBox() {
        val needW = (targetW + 32 * d).toInt()
        val needH = (targetH + 16 * d).toInt()
        if (needW != boxW || needH != boxH) {
            boxW = needW; boxH = needH
            requestLayout()
        }
    }

    // ---------------------------------------------------------- data masuk

    private fun dominant(b: Bitmap): Int = try {
        val px = Bitmap.createScaledBitmap(b, 1, 1, true).getPixel(0, 0)
        val hsv = FloatArray(3)
        Color.colorToHSV(px, hsv)
        hsv[1] = min(1f, hsv[1] * 1.25f + 0.1f)
        hsv[2] = max(hsv[2], 0.85f)
        Color.HSVToColor(hsv)
    } catch (_: Throwable) { Color.WHITE }

    fun setMedia(info: MediaWatcher.Info?) {
        media = info
        val art = info?.art
        if (art !== lastArt) {
            lastArt = art
            artColor = art?.let { dominant(it) } ?: green
            glow = null
        }
        resolve()
        scheduleTick()
        invalidate()
    }

    fun setHotspot(on: Boolean, since: Long) {
        hotspotOn = on
        hotspotSince = since
        resolve()
        scheduleTick()
        invalidate()
    }

    fun pulseCharge() = startPulse(Pulse(Kind.CHARGE), 3200)
    fun pulseHotspot(on: Boolean) = startPulse(Pulse(Kind.HOTSPOT, on = on), 3400)
    fun showBanner(b: NotifHub.Banner) = startPulse(Pulse(Kind.NOTIF, b), 4800)

    val isExpanded: Boolean get() = expanded

    private fun startPulse(p: Pulse, ms: Long) {
        if (expanded) return
        pulse = p
        handler.removeCallbacks(pulseEnd)
        handler.postDelayed(pulseEnd, ms)
        contentT = 0f
        resolve(force = true)
        kick()
    }

    fun collapse() {
        expanded = false
        pulse = null
        handler.removeCallbacks(autoCollapse)
        resolve()
    }

    private fun expand() {
        expanded = true
        bumpCollapse()
        resolve()
        haptic()
    }

    private fun bumpCollapse() {
        handler.removeCallbacks(autoCollapse)
        handler.postDelayed(autoCollapse, if (media?.playing == true) 9000 else 6000)
    }

    private fun haptic() {
        if (Prefs.bool(context, Prefs.HAPTIC)) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    }

    // --------------------------------------------------------------- bentuk

    private fun sizeFor(k: Kind, m: Mode): Pair<Float, Float> = when (m) {
        Mode.REST -> restW to restH
        Mode.COMPACT -> when (k) {
            Kind.MUSIC -> 236f * d to 36f * d
            Kind.HOTSPOT -> 184f * d to 36f * d
            Kind.CHARGE -> 196f * d to 36f * d
            Kind.NOTIF -> 252f * d to 36f * d
            else -> restW to restH
        }
        Mode.EXPANDED -> when (k) {
            Kind.MUSIC -> 360f * d to 184f * d
            Kind.HOTSPOT -> 360f * d to 116f * d
            Kind.CHARGE -> 360f * d to 116f * d
            Kind.NOTIF -> 360f * d to 104f * d
            else -> 360f * d to 150f * d
        }
    }

    /** Menentukan aktivitas dan ukuran kapsul dari data yang ada, lalu menggerakkan per-nya. */
    private fun resolve(force: Boolean = false) {
        val p = pulse
        val nk: Kind
        val nm: Mode
        if (expanded) {
            nm = Mode.EXPANDED
            nk = p?.kind ?: when {
                media != null -> Kind.MUSIC
                hotspotOn -> Kind.HOTSPOT
                else -> Kind.CLOCK
            }
        } else if (p != null) {
            nm = Mode.COMPACT; nk = p.kind
        } else if (media?.playing == true) {
            nm = Mode.COMPACT; nk = Kind.MUSIC
        } else if (hotspotOn) {
            nm = Mode.COMPACT; nk = Kind.HOTSPOT
        } else {
            nm = Mode.REST; nk = Kind.IDLE
        }
        if (nk == kind && nm == mode && !force) return
        if (nk != kind || nm != mode) contentT = 0f
        kind = nk
        mode = nm
        val (w, h) = sizeFor(nk, nm)
        targetW = min(w, maxW)
        targetH = h
        sw.target = targetW
        sh.target = targetH
        growBox()
        kick()
    }

    // ------------------------------------------------------------- sentuhan

    private fun pillLeft() = (width - sw.v) / 2f

    /** Titik/kapsul yang lebih pendek dari 36dp tetap sejajar tengah dengan lubang kamera. */
    private fun topOff() = max(0f, (bandH - sh.v) / 2f)

    private fun insidePill(x: Float, y: Float): Boolean {
        if (mode == Mode.REST && !Prefs.bool(context, Prefs.ISLAND_IDLE)) return false
        val slop = if (mode == Mode.REST) 14 * d else 6 * d   // titik kecil dibuat gampang dipencet
        val t = topOff()
        return x >= pillLeft() - slop && x <= pillLeft() + sw.v + slop &&
            y >= t - slop && y <= t + sh.v + slop
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downInside = insidePill(e.x, e.y)
                return downInside
            }
            MotionEvent.ACTION_UP -> {
                if (downInside && insidePill(e.x, e.y)) {
                    onTap(e.x - pillLeft(), e.y - topOff())
                    performClick()
                }
                downInside = false
            }
            MotionEvent.ACTION_CANCEL -> downInside = false
        }
        return downInside
    }

    override fun performClick(): Boolean = super.performClick()

    private fun onTap(lx: Float, ly: Float) {
        if (mode != Mode.EXPANDED) { expand(); return }
        val w = sw.v
        val h = sh.v
        when (kind) {
            Kind.MUSIC -> {
                val m = media
                if (m == null) { collapse(); return }
                when {
                    ly < 86 * d -> { MediaWatcher.openApp(); collapse() }
                    ly in 90 * d..118 * d -> {
                        if (m.duration > 0) {
                            val frac = ((lx - 22 * d) / (w - 44 * d)).coerceIn(0f, 1f)
                            MediaWatcher.seekTo((m.duration * frac).toLong())
                        }
                        bumpCollapse()
                    }
                    ly > 122 * d -> {
                        when {
                            abs(lx - w * 0.24f) < 36 * d -> MediaWatcher.previous()
                            abs(lx - w * 0.50f) < 36 * d -> MediaWatcher.toggle()
                            abs(lx - w * 0.76f) < 36 * d -> MediaWatcher.next()
                            else -> { collapse(); return }
                        }
                        haptic()
                        bumpCollapse()
                    }
                    else -> collapse()
                }
            }
            Kind.HOTSPOT -> {
                if (lx > w - 128 * d && abs(ly - h / 2f) < 22 * d) context.openHotspotSettings()
                collapse()
            }
            Kind.NOTIF -> {
                try { pulse?.banner?.intent?.send() } catch (_: Exception) {}
                collapse()
            }
            else -> collapse()
        }
    }

    // --------------------------------------------------------------- gambar

    private fun fmt(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60)
    }

    private fun hotspotTime(): String {
        val s = ((SystemClock.elapsedRealtime() - hotspotSince) / 1000).coerceAtLeast(0)
        return if (s >= 3600) String.format(Locale.US, "%d:%02d:%02d", s / 3600, (s / 60) % 60, s % 60)
        else String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    }

    private fun drawText(
        c: Canvas, s: String, x: Float, y: Float, sizeDp: Float, color: Int, a: Int,
        align: Paint.Align = Paint.Align.LEFT, maxWidth: Float = 0f, bold: Boolean = false
    ) {
        text.textSize = sizeDp * d
        text.textAlign = align
        text.typeface = if (bold) boldFace else medFace
        text.color = color
        text.alpha = Color.alpha(color) * a / 255
        val str = if (maxWidth > 0f) TextUtils.ellipsize(s, text, maxWidth, TextUtils.TruncateAt.END).toString() else s
        c.drawText(str, x, y, text)
    }

    /** Garis dasar supaya teks berukuran [sizeDp] berada tepat di tengah vertikal [cy]. */
    private fun mid(cy: Float, sizeDp: Float): Float {
        text.textSize = sizeDp * d
        return cy - (text.descent() + text.ascent()) / 2f
    }

    private fun drawArt(c: Canvas, art: Bitmap?, x: Float, y: Float, size: Float, radius: Float, a: Int) {
        rect.set(x, y, x + size, y + size)
        if (art == null) {
            fill.color = Color.argb(a, 58, 58, 62)
            c.drawRoundRect(rect, radius, radius, fill)
            Glyphs.draw(c, G.NOTE, x + size / 2f, y + size / 2f, size * 0.5f, Color.argb(a, 174, 174, 178))
            return
        }
        c.save()
        path.reset()
        path.addRoundRect(rect, radius, radius, Path.Direction.CW)
        c.clipPath(path)
        fill.color = Color.WHITE
        fill.alpha = a
        c.drawBitmap(art, null, rect, fill)
        fill.alpha = 255
        c.restore()
    }

    private fun drawEq(c: Canvas, x: Float, cy: Float, a: Int, color: Int, active: Boolean) {
        val t = SystemClock.uptimeMillis() / 170.0
        fill.color = color
        fill.alpha = a
        for (i in 0 until 4) {
            val amp = if (active) 0.35f + 0.65f * (0.5f + 0.5f * sin(t + i * 1.7).toFloat()) else 0.25f
            val bh = (4f + 14f * amp) * d
            val bx = x + i * 5.5f * d
            r2.set(bx, cy - bh / 2f, bx + 3 * d, cy + bh / 2f)
            c.drawRoundRect(r2, 1.5f * d, 1.5f * d, fill)
        }
        fill.alpha = 255
    }

    override fun onDraw(canvas: Canvas) {
        val w = sw.v
        val h = sh.v
        val left = (width - w) / 2f
        val atRest = mode == Mode.REST && w <= restW + 1.5f * d
        if (atRest && !Prefs.bool(context, Prefs.ISLAND_IDLE)) return

        canvas.save()
        canvas.translate(0f, topOff())
        val r = min(h / 2f, 34f * d)
        rect.set(left, 0f, left + w, h)
        canvas.drawRoundRect(rect, r, r, body)

        val t = ((contentT - 0.22f) / 0.78f).coerceIn(0f, 1f)
        val a = ((1f - (1f - t) * (1f - t) * (1f - t)) * 255).toInt()
        if (mode == Mode.REST || a < 6) { canvas.restore(); return }

        canvas.save()
        path.reset()
        path.addRoundRect(rect, r, r, Path.Direction.CW)
        canvas.clipPath(path)

        if (kind == Kind.MUSIC && mode == Mode.EXPANDED) {
            val g = glow ?: Paint(Paint.ANTI_ALIAS_FLAG).also {
                it.shader = RadialGradient(
                    0f, 0f, 230 * d,
                    (artColor and 0x00FFFFFF) or (0x4A shl 24), artColor and 0x00FFFFFF,
                    Shader.TileMode.CLAMP
                )
                glow = it
            }
            canvas.save()
            canvas.translate(left + 60 * d, 6 * d)
            canvas.drawCircle(0f, 0f, 230 * d, g)
            canvas.restore()
        }

        val sc = 0.9f + 0.1f * (a / 255f)
        canvas.translate(left + (w - targetW) / 2f, (h - targetH) / 2f)
        canvas.scale(sc, sc, targetW / 2f, targetH / 2f)

        val tw = targetW
        val th = targetH
        when (mode) {
            Mode.COMPACT -> when (kind) {
                Kind.MUSIC -> compactMusic(canvas, tw, th, a)
                Kind.HOTSPOT -> compactHotspot(canvas, tw, th, a)
                Kind.CHARGE -> compactCharge(canvas, tw, th, a)
                Kind.NOTIF -> compactNotif(canvas, tw, th, a)
                else -> {}
            }
            Mode.EXPANDED -> when (kind) {
                Kind.MUSIC -> expandedMusic(canvas, tw, th, a)
                Kind.HOTSPOT -> expandedHotspot(canvas, tw, th, a)
                Kind.CHARGE -> expandedCharge(canvas, tw, th, a)
                Kind.NOTIF -> expandedNotif(canvas, tw, th, a)
                else -> expandedClock(canvas, tw, th, a)
            }
            else -> {}
        }
        canvas.restore()
        canvas.restore()
    }

    private fun levelColor() = when {
        charging -> green
        batteryLevel <= 20 -> red
        else -> Color.WHITE
    }

    // ---- kompak

    private fun compactMusic(c: Canvas, w: Float, h: Float, a: Int) {
        val m = media
        drawArt(c, m?.art, 10 * d, (h - 24 * d) / 2f, 24 * d, 6 * d, a)
        val eqX = w - 16 * d - 19.5f * d
        drawEq(c, eqX, h / 2f, a, artColor, m?.playing == true)
        if (hotspotOn) Glyphs.draw(c, G.HOTSPOT, eqX - 22 * d, h / 2f, 15 * d, Color.argb(a, 48, 209, 88))
    }

    private fun compactHotspot(c: Canvas, w: Float, h: Float, a: Int) {
        val on = pulse?.on ?: hotspotOn
        Glyphs.draw(c, G.HOTSPOT, 24 * d, h / 2f, 18 * d, if (on) green else grey)
        drawText(c, if (on) "Hotspot" else "Hotspot mati", 42 * d, mid(h / 2f, 13f), 13f, Color.WHITE, a)
        if (on) drawText(c, hotspotTime(), w - 16 * d, mid(h / 2f, 13f), 13f, green, a, Paint.Align.RIGHT)
    }

    private fun compactCharge(c: Canvas, w: Float, h: Float, a: Int) {
        Glyphs.draw(c, if (charging) G.BOLT else G.BATTERY, 22 * d, h / 2f, 16 * d, if (charging) green else Color.WHITE)
        drawText(c, if (charging) "Mengisi" else "Baterai", 40 * d, mid(h / 2f, 13f), 13f, Color.WHITE, a)
        drawText(c, "$batteryLevel%", w - 16 * d, mid(h / 2f, 13f), 13f, levelColor(), a, Paint.Align.RIGHT)
    }

    private fun compactNotif(c: Canvas, w: Float, h: Float, a: Int) {
        val b = pulse?.banner ?: return
        drawArt(c, b.icon, 10 * d, (h - 22 * d) / 2f, 22 * d, 6 * d, a)
        drawText(c, b.title, 40 * d, mid(h / 2f, 13f), 13f, Color.WHITE, a, maxWidth = w - 40 * d - 14 * d)
    }

    // ---- diperluas

    private fun expandedMusic(c: Canvas, w: Float, h: Float, a: Int) {
        val m = media ?: return
        drawArt(c, m.art, 20 * d, 20 * d, 64 * d, 14 * d, a)
        val tx = 96 * d
        val maxText = w - tx - 56 * d
        drawText(c, m.title, tx, 46 * d, 17f, Color.WHITE, a, maxWidth = maxText, bold = true)
        drawText(c, m.artist, tx, 68 * d, 14f, grey, a, maxWidth = maxText)
        drawEq(c, w - 20 * d - 19.5f * d, 34 * d, a, artColor, m.playing)

        // progress
        val left = 22 * d
        val right = w - 22 * d
        val y = 100 * d
        fill.color = Color.argb((a * 0.25f).toInt(), 255, 255, 255)
        r2.set(left, y, right, y + 5 * d)
        c.drawRoundRect(r2, 2.5f * d, 2.5f * d, fill)
        val elapsed = if (m.playing) ((SystemClock.elapsedRealtime() - m.stamp) * m.speed).toLong() else 0L
        val pos = (m.position + elapsed).coerceAtLeast(0L)
        if (m.duration > 0) {
            val frac = (pos.toFloat() / m.duration).coerceIn(0f, 1f)
            fill.color = Color.argb(a, 255, 255, 255)
            r2.set(left, y, left + (right - left) * frac, y + 5 * d)
            c.drawRoundRect(r2, 2.5f * d, 2.5f * d, fill)
            drawText(c, fmt(pos), left, 124 * d, 11f, grey, a)
            drawText(c, "-" + fmt(m.duration - pos), right, 124 * d, 11f, grey, a, Paint.Align.RIGHT)
        }

        // kontrol
        val cy = 152 * d
        val white = Color.argb(a, 255, 255, 255)
        Glyphs.draw(c, G.PREV, w * 0.24f, cy, 24 * d, white)
        Glyphs.draw(c, if (m.playing) G.PAUSE else G.PLAY, w * 0.5f, cy, 32 * d, white)
        Glyphs.draw(c, G.NEXT, w * 0.76f, cy, 24 * d, white)
    }

    private fun expandedHotspot(c: Canvas, w: Float, h: Float, a: Int) {
        val on = pulse?.on ?: hotspotOn
        fill.color = if (on) Color.argb(a, 48, 209, 88) else Color.argb(a, 70, 70, 74)
        c.drawCircle(20 * d + 28 * d, h / 2f, 28 * d, fill)
        Glyphs.draw(c, G.HOTSPOT, 48 * d, h / 2f, 30 * d, Color.argb(a, 255, 255, 255))
        drawText(c, if (on) "Hotspot Pribadi" else "Hotspot dimatikan", 92 * d, h / 2f - 4 * d, 17f,
            Color.WHITE, a, maxWidth = w - 92 * d - 130 * d, bold = true)
        drawText(c, if (on) "Aktif · " + hotspotTime() else "Tidak aktif", 92 * d, h / 2f + 20 * d, 14f,
            if (on) green else grey, a)
        r2.set(w - 116 * d, h / 2f - 18 * d, w - 20 * d, h / 2f + 18 * d)
        fill.color = Color.argb((a * 0.16f).toInt(), 255, 255, 255)
        c.drawRoundRect(r2, 18 * d, 18 * d, fill)
        drawText(c, "Buka", r2.centerX(), mid(r2.centerY(), 14f), 14f, Color.WHITE, a, Paint.Align.CENTER)
    }

    private fun expandedCharge(c: Canvas, w: Float, h: Float, a: Int) {
        drawText(c, if (charging) "Mengisi daya" else "Baterai", 24 * d, 38 * d, 13f, grey, a)
        drawText(c, "$batteryLevel%", 24 * d, 84 * d, 38f, levelColor(), a, bold = true)
        val size = 64 * d
        val left = w - 24 * d - size
        val top = (h - size) / 2f
        r2.set(left, top, left + size, top + size)
        ringBg.alpha = a
        c.drawArc(r2, 0f, 360f, false, ringBg)
        ringFg.color = levelColor()
        ringFg.alpha = a
        c.drawArc(r2, -90f, 360f * batteryLevel / 100f, false, ringFg)
        Glyphs.draw(c, if (charging) G.BOLT else G.BATTERY, r2.centerX(), r2.centerY(), 24 * d,
            Color.argb(a, 255, 255, 255))
    }

    private fun expandedNotif(c: Canvas, w: Float, h: Float, a: Int) {
        val b = pulse?.banner ?: return
        drawArt(c, b.icon, 20 * d, 20 * d, 44 * d, 11 * d, a)
        val tx = 76 * d
        val maxText = w - tx - 20 * d
        drawText(c, b.app.uppercase(), tx, 32 * d, 11f, grey, a, maxWidth = maxText)
        drawText(c, b.title, tx, 56 * d, 16f, Color.WHITE, a, maxWidth = maxText, bold = true)
        drawText(c, b.text, tx, 80 * d, 14f, grey, a, maxWidth = maxText)
    }

    private fun expandedClock(c: Canvas, w: Float, h: Float, a: Int) {
        val pad = 24 * d
        drawText(c, hhmm.format(Date()), pad, 66 * d, 40f, Color.WHITE, a, bold = true)
        drawText(c, dateFmt.format(Date()), pad, 92 * d, 14f, grey, a)
        val size = 64 * d
        val left = w - pad - size
        val top = 30 * d
        r2.set(left, top, left + size, top + size)
        ringBg.alpha = a
        c.drawArc(r2, 0f, 360f, false, ringBg)
        ringFg.color = levelColor()
        ringFg.alpha = a
        c.drawArc(r2, -90f, 360f * batteryLevel / 100f, false, ringFg)
        drawText(c, "$batteryLevel", r2.centerX(), mid(r2.centerY(), 15f), 15f, Color.WHITE, a, Paint.Align.CENTER)
        val status = when {
            hotspotOn && charging -> "Hotspot aktif · mengisi daya"
            hotspotOn -> "Hotspot aktif"
            charging -> "Sedang mengisi daya"
            else -> "Baterai"
        }
        drawText(c, status, pad, h - 22 * d, 13f, if (hotspotOn || charging) green else grey, a)
    }
}
