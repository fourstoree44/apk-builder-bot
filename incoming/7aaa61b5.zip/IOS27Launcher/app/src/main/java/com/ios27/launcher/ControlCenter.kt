package com.ios27.launcher

import android.app.Activity
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Slider vertikal tebal ala iOS (kecerahan, volume), dengan latar kaca. */
class VSlider(
    ctx: Context, private val glyph: G, backdrop: Boolean, private val onValue: (Float) -> Unit
) : View(ctx) {
    var value = 0.5f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F5FFFFFF") }
    private val clip = Path()
    private val rect = RectF()

    init { background = ctx.glass(30, true, backdrop) }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        val r = context.dp(30).toFloat()
        rect.set(0f, 0f, w, h)
        clip.reset(); clip.addRoundRect(rect, r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        c.drawRect(0f, h * (1f - value), w, h, fill)
        c.restore()
        val gy = h - context.dp(34).toFloat()
        val covered = h * (1f - value) < gy - context.dp(12)
        Glyphs.draw(c, glyph, w / 2f, gy, context.dp(26).toFloat(), if (covered) Color.parseColor("#3A3A3C") else Color.WHITE)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                value = 1f - e.y / height
                onValue(value)
            }
        }
        return true
    }
}

/** Tombol bulat kaca: bening saat mati, putih penuh (ikon gelap) saat hidup — seperti di video referensi. */
class CircleButton(ctx: Context, private val glyph: G, backdrop: Boolean, click: () -> Unit) : View(ctx) {
    var on = false
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F2FFFFFF") }

    init {
        background = ctx.glass(60, true, backdrop)
        setOnClickListener { click() }
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val r = minOf(width, height) / 2f
        if (on) c.drawCircle(width / 2f, height / 2f, r, p)
        Glyphs.draw(c, glyph, width / 2f, height / 2f, r * 0.98f,
            if (on) Color.parseColor("#1C1C1E") else Color.WHITE)
    }
}

/** Pil lebar (Wi-Fi, Seluler): ikon + dua baris teks. Putih saat aktif. */
class PillButton(
    ctx: Context, private val glyph: G, initialLabel: String, backdrop: Boolean, click: () -> Unit
) : View(ctx) {
    var label = initialLabel
        set(v) { field = v; invalidate() }
    var on = false
        set(v) { field = v; invalidate() }
    var sub = ""
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F2FFFFFF") }
    private val t = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    init {
        background = ctx.glass(40, true, backdrop)
        setOnClickListener { click() }
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        if (on) {
            rect.set(0f, 0f, w, h)
            c.drawRoundRect(rect, h / 2f, h / 2f, p)
        }
        val fg = if (on) Color.parseColor("#1C1C1E") else Color.WHITE
        val sec = if (on) Color.parseColor("#6C6C70") else Color.parseColor("#C7C7CC")
        val ic = h * 0.30f
        Glyphs.draw(c, glyph, h * 0.5f + context.dp(2), h / 2f, ic, fg)
        val x = h * 0.5f + ic + context.dp(12)
        val maxW = w - x - context.dp(10)
        t.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD)
        t.textSize = context.dp(15).toFloat()
        t.color = fg
        c.drawText(TextUtils.ellipsize(label, t, maxW, TextUtils.TruncateAt.END).toString(), x, h / 2f - context.dp(1), t)
        t.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        t.textSize = context.dp(12).toFloat()
        t.color = sec
        c.drawText(TextUtils.ellipsize(sub, t, maxW, TextUtils.TruncateAt.END).toString(), x, h / 2f + context.dp(15), t)
    }
}

/** Kartu lagu (Control Center dan Notification Center). Mendengarkan lagu selama terpasang di layar. */
class MediaCard(ctx: Context, backdrop: Boolean, private val onNoAccess: () -> Unit) : LinearLayout(ctx) {
    private val art = ImageView(ctx)
    private val title = TextView(ctx)
    private val artist = TextView(ctx)
    private val play = GlyphView(ctx, G.PLAY, Color.WHITE, 0.55f)
    private val listener: (MediaWatcher.Info?) -> Unit = { update(it) }

    init {
        orientation = LinearLayout.VERTICAL
        background = ctx.glass(28, true, backdrop)
        setPadding(ctx.dp(14), ctx.dp(14), ctx.dp(14), ctx.dp(8))
        setOnClickListener {
            if (!MediaWatcher.isAccessGranted(ctx)) onNoAccess() else MediaWatcher.openApp()
        }

        val top = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL }
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        art.background = GradientDrawable().apply { cornerRadius = ctx.dp(11).toFloat(); setColor(Color.parseColor("#33FFFFFF")) }
        art.clipToOutline = true
        top.addView(art, LinearLayout.LayoutParams(ctx.dp(46), ctx.dp(46)))
        val names = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        title.apply { textSize = 14f; setTextColor(Color.WHITE); maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.BOLD) }
        artist.apply { textSize = 12f; setTextColor(Color.parseColor("#C7C7CC")); maxLines = 1; ellipsize = TextUtils.TruncateAt.END }
        names.addView(title); names.addView(artist)
        top.addView(names, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = ctx.dp(10) })
        addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        val row = LinearLayout(ctx).apply { gravity = Gravity.CENTER }
        row.addView(GlyphView(ctx, G.PREV, Color.WHITE, 0.5f).apply { setOnClickListener { MediaWatcher.previous() } },
            LinearLayout.LayoutParams(0, MATCH, 1f))
        play.setOnClickListener { MediaWatcher.toggle() }
        row.addView(play, LinearLayout.LayoutParams(0, MATCH, 1f))
        row.addView(GlyphView(ctx, G.NEXT, Color.WHITE, 0.5f).apply { setOnClickListener { MediaWatcher.next() } },
            LinearLayout.LayoutParams(0, MATCH, 1f))
        addView(row, LinearLayout.LayoutParams(MATCH, 0, 1f))
    }

    private fun update(i: MediaWatcher.Info?) {
        title.text = i?.title ?: "Tidak diputar"
        artist.text = i?.artist ?: if (MediaWatcher.isAccessGranted(context)) "" else "Ketuk untuk beri akses"
        play.glyph = if (i?.playing == true) G.PAUSE else G.PLAY
        if (i?.art != null) art.setImageBitmap(i.art) else art.setImageDrawable(null)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        MediaWatcher.addListener(context, listener)
    }

    override fun onDetachedFromWindow() {
        MediaWatcher.removeListener(listener)
        super.onDetachedFromWindow()
    }
}

/**
 * Control Center bergaya iOS. Dipakai di dalam launcher ([host] = layar utama) dan sebagai panel
 * di atas semua aplikasi ([host] = window overlay).
 *
 * Catatan Android: aplikasi biasa tidak boleh menyalakan Wi-Fi, data, atau Bluetooth langsung.
 * Tombol-tombol itu menampilkan statusnya dan membuka panel sistem untuk mengubahnya.
 * Senter, kecerahan, volume, dan kunci rotasi bisa dikontrol langsung.
 */
class ControlCenter(
    private val ctx: Context,
    private val host: FrameLayout,
    private val topInset: () -> Int,
    private val backdrop: Boolean,
    private val openSearch: () -> Unit,
    private val onClosed: () -> Unit = {}
) {
    private var view: FrameLayout? = null
    val isShowing: Boolean get() = view != null

    private val handler = Handler(Looper.getMainLooper())
    private val camera = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var torchId: String? = null
    private var torchOn = false
    private var askedWrite = false

    private var tAirplane: CircleButton? = null
    private var pData: PillButton? = null
    private var pWifi: PillButton? = null
    private var tBt: CircleButton? = null
    private var tHotspot: CircleButton? = null
    private var tTorch: CircleButton? = null
    private var tRotate: CircleButton? = null
    private var tFocus: CircleButton? = null
    private var tRinger: CircleButton? = null

    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(id: String, enabled: Boolean) {
            if (id == torchId) { torchOn = enabled; tTorch?.on = enabled }
        }
    }

    private val refresher = object : Runnable {
        override fun run() {
            if (view == null) return
            refreshStates()
            handler.postDelayed(this, 1500)
        }
    }

    private fun go(vararg intents: Intent) {
        close()
        if (!ctx.startSafe(*intents)) Toast.makeText(ctx, "Tidak bisa dibuka di HP ini", Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------- status

    private fun refreshStates() {
        try {
            tAirplane?.on = Settings.Global.getInt(ctx.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1
        } catch (_: Exception) {}
        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            val tm = ctx.getSystemService(Context.TELEPHONY_SERVICE) as android.telephony.TelephonyManager
            val cell = caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true
            pData?.on = cell
            pData?.sub = if (cell) "Dipakai" else "Nonaktif"
            val op = tm.networkOperatorName
            if (!op.isNullOrBlank()) pData?.label = op
        } catch (_: Exception) {}
        try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            pWifi?.on = wm.isWifiEnabled
            pWifi?.sub = if (wm.isWifiEnabled) "Aktif" else "Mati"
        } catch (_: Exception) {}
        try {
            tRinger?.on = audio.ringerMode != AudioManager.RINGER_MODE_NORMAL
        } catch (_: Exception) {}
        try { tBt?.on = BluetoothAdapter.getDefaultAdapter()?.isEnabled == true } catch (_: Exception) {}
        tHotspot?.on = HotspotState.on
        tTorch?.on = torchOn
        try {
            tRotate?.on = Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
        } catch (_: Exception) {}
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            tFocus?.on = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL &&
                nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
        } catch (_: Exception) {}
    }

    private fun findTorch() {
        if (torchId != null) return
        torchId = try {
            camera.cameraIdList.firstOrNull {
                val ch = camera.getCameraCharacteristics(it)
                ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
        } catch (_: Exception) { null }
    }

    private fun toggleTorch() {
        val id = torchId
        if (id == null) { Toast.makeText(ctx, "HP ini tidak punya senter", Toast.LENGTH_SHORT).show(); return }
        try { camera.setTorchMode(id, !torchOn) } catch (_: Exception) {
            Toast.makeText(ctx, "Senter sedang dipakai aplikasi lain", Toast.LENGTH_SHORT).show()
        }
    }

    private fun askWriteSettings() {
        if (askedWrite) return
        askedWrite = true
        Toast.makeText(ctx, "Izinkan \"Ubah pengaturan sistem\" dulu", Toast.LENGTH_LONG).show()
        close()
        ctx.startSafe(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
    }

    private fun toggleRotation() {
        if (!Settings.System.canWrite(ctx)) { askWriteSettings(); return }
        try {
            val locked = Settings.System.getInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
            Settings.System.putInt(ctx.contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (locked) 1 else 0)
            tRotate?.on = !locked
        } catch (_: Exception) {}
    }

    private fun toggleRinger() {
        try {
            audio.ringerMode = if (audio.ringerMode == AudioManager.RINGER_MODE_NORMAL)
                AudioManager.RINGER_MODE_VIBRATE else AudioManager.RINGER_MODE_NORMAL
            tRinger?.on = audio.ringerMode != AudioManager.RINGER_MODE_NORMAL
        } catch (_: Exception) {
            go(Intent(Settings.ACTION_SOUND_SETTINGS))
        }
    }

    private fun setBrightness(v: Float) {
        if (Settings.System.canWrite(ctx)) {
            try {
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS,
                    (v * 255).toInt().coerceIn(1, 255))
            } catch (_: Exception) {}
        } else {
            val win = (ctx as? Activity)?.window
            if (win != null) {
                val lp = win.attributes
                lp.screenBrightness = v.coerceIn(0.02f, 1f)
                win.attributes = lp
            }
            askWriteSettings()
        }
    }

    private fun currentBrightness(): Float = try {
        (Settings.System.getInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f).coerceIn(0f, 1f)
    } catch (_: Exception) { 0.5f }

    // --------------------------------------------------------------- tampil

    fun show() {
        close()
        val accent = Prefs.accent(ctx)
        findTorch()
        try { camera.registerTorchCallback(torchCb, handler) } catch (_: Exception) {}

        val scrim = FrameLayout(ctx).apply {
            setBackgroundColor(Color.argb(if (backdrop) 150 else 70, 0, 0, 0))
            isClickable = true
            setOnClickListener { close() }
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.dp(16), topInset() + ctx.dp(14), ctx.dp(16), ctx.dp(32))
        }
        val gap = ctx.dp(12)

        // baris 1: dua pil lebar (Wi-Fi, Seluler)
        val internet = Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
        pWifi = PillButton(ctx, G.WIFI, "Wi-Fi", backdrop) { go(internet) }
        pData = PillButton(ctx, G.CELL, "Seluler", backdrop) { go(internet) }
        val rowP = LinearLayout(ctx)
        rowP.addView(pWifi, LinearLayout.LayoutParams(0, MATCH, 1f).apply { marginEnd = gap / 2 })
        rowP.addView(pData, LinearLayout.LayoutParams(0, MATCH, 1f).apply { marginStart = gap / 2 })
        col.addView(rowP, LinearLayout.LayoutParams(MATCH, ctx.dp(68)).apply { bottomMargin = gap })

        // baris 2: kartu lagu + slider kecerahan + slider volume
        val media = MediaCard(ctx, backdrop) { go(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        val bright = VSlider(ctx, G.SUN, backdrop) { setBrightness(it) }.also { it.value = currentBrightness() }
        val vol = VSlider(ctx, G.VOLUME, backdrop) {
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (it * max).toInt(), 0)
        }.also {
            it.value = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() /
                audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        }
        val rowM = LinearLayout(ctx)
        rowM.addView(media, LinearLayout.LayoutParams(0, MATCH, 2.1f).apply { marginEnd = gap / 2 })
        rowM.addView(bright, LinearLayout.LayoutParams(0, MATCH, 1f).apply { marginStart = gap / 2; marginEnd = gap / 2 })
        rowM.addView(vol, LinearLayout.LayoutParams(0, MATCH, 1f).apply { marginStart = gap / 2 })
        col.addView(rowM, LinearLayout.LayoutParams(MATCH, ctx.dp(196)).apply { bottomMargin = gap })

        // baris 3-5: tombol bulat 4 kolom
        tBt = CircleButton(ctx, G.BT, backdrop) { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        tTorch = CircleButton(ctx, G.TORCH, backdrop) { toggleTorch() }
        tAirplane = CircleButton(ctx, G.AIRPLANE, backdrop) { go(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) }
        tRotate = CircleButton(ctx, G.ROTATE, backdrop) { toggleRotation() }
        tRinger = CircleButton(ctx, G.BELL, backdrop) { toggleRinger() }
        val saver = CircleButton(ctx, G.BOLT, backdrop) {
            go(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS), Intent(Intent.ACTION_POWER_USAGE_SUMMARY))
        }
        tHotspot = CircleButton(ctx, G.HOTSPOT, backdrop) { close(); ctx.openHotspotSettings() }
        val cam = CircleButton(ctx, G.CAMERA, backdrop) { go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
        val calc = CircleButton(ctx, G.CALC, backdrop) {
            go(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR))
        }
        tFocus = CircleButton(ctx, G.MOON, backdrop) {
            go(Intent("android.settings.ZEN_MODE_SETTINGS"), Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        val find = CircleButton(ctx, G.SEARCH, backdrop) { close(); openSearch() }
        val set = CircleButton(ctx, G.GEAR, backdrop) { go(Intent(ctx, SettingsActivity::class.java)) }
        val grid = listOf(
            listOf(tBt!!, tTorch!!, tAirplane!!, tRotate!!),
            listOf(tRinger!!, saver, tHotspot!!, cam),
            listOf(calc, tFocus!!, find, set)
        )
        val circle = ctx.dp(66)
        grid.forEachIndexed { ri, row ->
            val r = LinearLayout(ctx)
            row.forEach { v ->
                val cell = FrameLayout(ctx)
                cell.addView(v, FrameLayout.LayoutParams(circle, circle, Gravity.CENTER))
                r.addView(cell, LinearLayout.LayoutParams(0, MATCH, 1f))
            }
            col.addView(r, LinearLayout.LayoutParams(MATCH, circle + ctx.dp(14)).apply {
                bottomMargin = if (ri == grid.lastIndex) 0 else gap / 2
            })
        }

        val scroll = ScrollView(ctx).apply {
            isVerticalScrollBarEnabled = false
            addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        }
        // geser ke atas di area kosong menutup panel
        var downY = 0f
        scroll.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> downY = e.rawY
                MotionEvent.ACTION_UP -> if (downY - e.rawY > ctx.dp(90)) close()
            }
            false
        }
        scrim.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))

        refreshStates()
        handler.postDelayed(refresher, 1500)

        scrim.alpha = 0f
        col.scaleX = 0.94f; col.scaleY = 0.94f
        col.pivotX = ctx.resources.displayMetrics.widthPixels * 0.8f
        col.pivotY = 0f
        host.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))
        scrim.animate().alpha(1f).setDuration(220).start()
        col.animate().scaleX(1f).scaleY(1f).setDuration(260).start()
        view = scrim
    }

    fun close() {
        val v = view ?: return
        view = null
        handler.removeCallbacks(refresher)
        try { camera.unregisterTorchCallback(torchCb) } catch (_: Exception) {}
        tAirplane = null; pData = null; pWifi = null; tBt = null
        tHotspot = null; tTorch = null; tRotate = null; tFocus = null; tRinger = null
        v.animate().alpha(0f).setDuration(160).withEndAction {
            try { host.removeView(v) } catch (_: Exception) {}
            onClosed()
        }.start()
    }
}
