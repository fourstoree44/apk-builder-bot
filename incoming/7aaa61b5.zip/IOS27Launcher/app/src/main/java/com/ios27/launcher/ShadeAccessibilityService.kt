package com.ios27.launcher

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.ComponentName
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/**
 * Cara paling kuat untuk mengganti panel notifikasi / quick settings bawaan HP.
 *
 *  1. Strip di tepi atas layar memakai jendela TYPE_ACCESSIBILITY_OVERLAY. Jendela jenis ini berada
 *     DI ATAS status bar, jadi geseran ke bawah ditangkap launcher dan panel iOS yang terbuka,
 *     bukan panel bawaan HP.
 *  2. Kalau panel bawaan HP sempat terbuka juga (misal lewat gestur dua jari atau tombol), service
 *     langsung menutupnya (GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE) lalu membuka Notification Center iOS.
 *
 * Service ini hanya dipakai untuk dua hal itu. Isi layar aplikasi lain tidak dibaca.
 */
class ShadeAccessibilityService : AccessibilityService() {

    private var shade: ShadeController? = null
    private val handler = Handler(Looper.getMainLooper())
    private var lastHandled = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        rebuild()
        // island memakai strip milik service ini, bukan strip overlay biasa
        IslandOverlayService.refresh(this)
    }

    /** Dipanggil kalau pengaturan "ganti panel" diubah. */
    fun rebuild() {
        shade?.stop()
        shade = ShadeController(this, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY).also { it.start() }
    }

    fun openPanel(control: Boolean) {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (km.isKeyguardLocked) return
        shade?.openPanel(control)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        e ?: return
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (!Prefs.bool(this, Prefs.SHADE_REPLACE)) return
        val pkg = e.packageName?.toString() ?: return
        if (!pkg.contains("systemui")) return
        val cls = e.className?.toString()?.lowercase() ?: return
        val isShade = cls.contains("notificationshade") || cls.contains("statusbarwindow") ||
            cls.contains("notificationpanel") || cls.contains("quicksettings") ||
            cls.contains("shadewindow") || cls.contains("controlcenter")
        if (!isShade || cls.contains("keyguard") || cls.contains("lock")) return
        val now = System.currentTimeMillis()
        if (now - lastHandled < 900 || shade?.isPanelShowing == true) return
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (km.isKeyguardLocked) return
        lastHandled = now
        if (Build.VERSION.SDK_INT >= 31) performGlobalAction(GLOBAL_ACTION_DISMISS_NOTIFICATION_SHADE)
        handler.postDelayed({ shade?.openPanel(false) }, 120)
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        shade?.stop(); shade = null
        IslandOverlayService.refresh(this)
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        shade?.stop(); shade = null
        super.onDestroy()
    }

    companion object {
        @Volatile var instance: ShadeAccessibilityService? = null

        fun isEnabled(ctx: Context): Boolean {
            val me = ComponentName(ctx, ShadeAccessibilityService::class.java).flattenToString()
            val list = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                ?: return false
            return list.split(':').any { it.equals(me, true) }
        }
    }
}
