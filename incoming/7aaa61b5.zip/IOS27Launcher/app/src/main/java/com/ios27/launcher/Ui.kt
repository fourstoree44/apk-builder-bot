package com.ios27.launcher

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.PopupWindow
import android.widget.TextView

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** Panel Liquid Glass, dipakai untuk dock, widget, dan kartu. [backdrop] = false untuk panel di atas aplikasi lain. */
fun Context.glass(radiusDp: Int, strong: Boolean = false, backdrop: Boolean = true): GlassDrawable =
    GlassDrawable(this, dp(radiusDp).toFloat(), strong, backdrop)

fun Context.statusBarHeight(): Int {
    val id = resources.getIdentifier("status_bar_height", "dimen", "android")
    return if (id > 0) resources.getDimensionPixelSize(id) else dp(28)
}

fun TextView.softShadow() {
    setShadowLayer(context.dp(2).toFloat(), 0f, context.dp(1).toFloat(), Color.parseColor("#99000000"))
}

/** Membuka salah satu intent yang bisa dibuka di HP ini. true kalau berhasil. */
fun Context.startSafe(vararg intents: Intent): Boolean {
    for (i in intents) {
        try {
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return true
        } catch (_: Exception) {}
    }
    return false
}

/** Pengaturan hotspot. Nama halamannya berbeda-beda di tiap merek HP, jadi dicoba beberapa. */
fun Context.openHotspotSettings(): Boolean = startSafe(
    Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"),
    Intent().setClassName("com.android.settings", "com.android.settings.Settings\$TetherSettingsActivity"),
    Intent(Settings.ACTION_WIRELESS_SETTINGS)
)

/** ListView tanpa garis pemisah, sorotan, atau efek tarik, supaya terlihat seperti daftar iOS. */
fun Context.plainList(): ListView = ListView(this).apply {
    divider = null
    dividerHeight = 0
    setSelector(android.R.color.transparent)
    cacheColorHint = Color.TRANSPARENT
    overScrollMode = View.OVER_SCROLL_NEVER
    isVerticalScrollBarEnabled = false
    isFastScrollEnabled = false
}

/** Switch ala iOS: jalur hijau dan kenop putih yang meluncur. */
class IosSwitch(ctx: Context) : View(ctx) {
    var onChange: ((Boolean) -> Unit)? = null
    var checked = false
        private set

    private var t = 0f
    private var anim: ValueAnimator? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val eval = ArgbEvaluator()
    private val onColor = Color.parseColor("#30D158")
    private val offColor = Color.parseColor("#48484A")

    init {
        isClickable = true
        setOnClickListener { flip() }
    }

    fun set(v: Boolean) {
        checked = v
        t = if (v) 1f else 0f
        invalidate()
    }

    private fun flip() {
        checked = !checked
        anim?.cancel()
        anim = ValueAnimator.ofFloat(t, if (checked) 1f else 0f).apply {
            duration = 220
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            start()
        }
        onChange?.invoke(checked)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(context.dp(51), context.dp(31))
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.color = eval.evaluate(t, offColor, onColor) as Int
        c.drawRoundRect(0f, 0f, w, h, h / 2f, h / 2f, p)
        val pad = context.dp(2).toFloat()
        val kr = h / 2f - pad
        val cx = pad + kr + t * (w - 2 * pad - 2 * kr)
        p.color = Color.argb(46, 0, 0, 0)
        c.drawCircle(cx, h / 2f + context.dp(1), kr + context.dp(1) * 0.6f, p)
        p.color = Color.WHITE
        c.drawCircle(cx, h / 2f, kr, p)
    }
}

class MenuItem(val glyph: G, val label: String, val danger: Boolean = false, val run: () -> Unit)

/** Menu tekan-lama berbahan kaca, muncul di dekat [anchor]. */
fun showGlassMenu(anchor: View, items: List<MenuItem>, atX: Int = -1, atY: Int = -1) {
    val ctx = anchor.context
    val width = ctx.dp(236)
    val box = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(0, ctx.dp(6), 0, ctx.dp(6))
        background = ctx.glass(22, true)
    }
    val pw = PopupWindow(box, width, WRAP, true)
    pw.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    pw.isOutsideTouchable = true
    items.forEachIndexed { i, item ->
        val color = if (item.danger) Color.parseColor("#FF453A") else Color.WHITE
        val row = LinearLayout(ctx).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ctx.dp(18), ctx.dp(13), ctx.dp(16), ctx.dp(13))
            setOnClickListener { pw.dismiss(); item.run() }
        }
        row.addView(TextView(ctx).apply { text = item.label; textSize = 16f; setTextColor(color) },
            LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(GlyphView(ctx, item.glyph, color, 0.9f), LinearLayout.LayoutParams(ctx.dp(22), ctx.dp(22)))
        box.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        if (i < items.size - 1) {
            box.addView(View(ctx).apply { setBackgroundColor(Color.parseColor("#26FFFFFF")) },
                LinearLayout.LayoutParams(MATCH, 1).apply { marginStart = ctx.dp(18); marginEnd = ctx.dp(18) })
        }
    }
    box.measure(
        View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
        View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
    )
    val dm = ctx.resources.displayMetrics
    val loc = IntArray(2)
    anchor.getLocationOnScreen(loc)
    val h = box.measuredHeight
    val centerX = if (atX >= 0) atX else loc[0] + anchor.width / 2
    val x = (centerX - width / 2).coerceIn(ctx.dp(12), dm.widthPixels - width - ctx.dp(12))
    var y = if (atY >= 0) atY else loc[1] + anchor.height + ctx.dp(6)
    if (y + h > dm.heightPixels - ctx.dp(24)) y = (if (atY >= 0) atY else loc[1]) - h - ctx.dp(6)
    pw.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y.coerceAtLeast(ctx.dp(24)))
}

/**
 * Adapter daftar aplikasi. Baris di-recycle oleh ListView, jadi ratusan aplikasi tetap ringan.
 * Isi daftar boleh campuran: String = judul huruf, AppEntry = baris aplikasi.
 */
class AppListAdapter(
    private val ctx: Context,
    private val icon: (AppEntry, Int) -> Bitmap,
    private val onClick: (AppEntry, View) -> Unit,
    private val onLongClick: ((AppEntry, View) -> Unit)? = null,
    private val rightPadDp: Int = 0
) : BaseAdapter() {

    var items: List<Any> = emptyList()
        set(v) { field = v; notifyDataSetChanged() }

    private val iconPx = ctx.dp(46)

    override fun getCount() = items.size
    override fun getItem(i: Int): Any = items[i]
    override fun getItemId(i: Int) = i.toLong()
    override fun getViewTypeCount() = 2
    override fun getItemViewType(i: Int) = if (items[i] is String) 0 else 1
    override fun isEnabled(position: Int) = false

    override fun getView(i: Int, convert: View?, parent: ViewGroup): View {
        val item = items[i]
        if (item is String) {
            val tv = (convert as? TextView) ?: TextView(ctx).apply {
                textSize = 13f
                setTextColor(Color.parseColor("#AEAEB2"))
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                setPadding(ctx.dp(4), ctx.dp(16), 0, ctx.dp(4))
            }
            tv.text = item
            return tv
        }
        val app = item as AppEntry
        val row = (convert as? LinearLayout) ?: LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ctx.dp(4), ctx.dp(6), ctx.dp(rightPadDp), ctx.dp(6))
            addView(ImageView(ctx), LinearLayout.LayoutParams(iconPx, iconPx))
            addView(TextView(ctx).apply {
                textSize = 16f; setTextColor(Color.WHITE); maxLines = 1
                ellipsize = TextUtils.TruncateAt.END; softShadow()
            }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = ctx.dp(14) })
        }
        val iv = row.getChildAt(0) as ImageView
        iv.setImageBitmap(icon(app, iconPx))
        (row.getChildAt(1) as TextView).text = app.label
        row.setOnClickListener { onClick(app, iv) }
        row.setOnLongClickListener { onLongClick?.invoke(app, iv); onLongClick != null }
        return row
    }
}

/** Layar pencarian penuh, atau daftar isi satu kategori jika [fixed] diisi. */
class SearchOverlay(
    private val activity: Activity,
    private val root: FrameLayout,
    private val icon: (AppEntry, Int) -> Bitmap,
    private val launch: (AppEntry, View) -> Unit
) {
    private var view: FrameLayout? = null
    val isShowing: Boolean get() = view != null

    fun show(allApps: List<AppEntry>, title: String?, fixed: List<AppEntry>?) {
        close()
        val ctx = activity
        val scrim = FrameLayout(ctx).apply {
            setBackgroundColor(Color.parseColor("#D008080E"))
            isClickable = true
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.dp(18), ctx.statusBarHeight() + ctx.dp(56), ctx.dp(18), ctx.dp(12))
        }
        val adapter = AppListAdapter(ctx, icon, { app, v -> launch(app, v); close() })
        val list = ctx.plainList().also { it.adapter = adapter }

        if (fixed != null) {
            col.addView(TextView(ctx).apply {
                text = title
                textSize = 28f
                setTextColor(Color.WHITE)
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            }, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = ctx.dp(12) })
            adapter.items = fixed
        } else {
            val bar = LinearLayout(ctx).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = ctx.glass(22, true)
                setPadding(ctx.dp(14), 0, ctx.dp(14), 0)
            }
            bar.addView(GlyphView(ctx, G.SEARCH, Color.parseColor("#AEAEB2"), 0.9f),
                LinearLayout.LayoutParams(ctx.dp(20), ctx.dp(20)))
            val input = EditText(ctx).apply {
                hint = "Search"
                setHintTextColor(Color.parseColor("#8E8E93"))
                setTextColor(Color.WHITE)
                textSize = 17f
                isSingleLine = true
                background = null
                setPadding(ctx.dp(10), ctx.dp(12), ctx.dp(4), ctx.dp(12))
            }
            bar.addView(input, LinearLayout.LayoutParams(0, WRAP, 1f))
            fun filtered(q: String) =
                if (q.isBlank()) allApps else allApps.filter { it.label.contains(q.trim(), ignoreCase = true) }
            input.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { adapter.items = filtered(s?.toString().orEmpty()) }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            input.setOnEditorActionListener { _, _, _ ->
                filtered(input.text.toString()).firstOrNull()?.let { launch(it, input); close() }
                true
            }
            col.addView(bar, LinearLayout.LayoutParams(MATCH, ctx.dp(46)).apply { bottomMargin = ctx.dp(12) })
            adapter.items = allApps
            input.postDelayed({
                input.requestFocus()
                (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            }, 150)
        }
        col.addView(list, LinearLayout.LayoutParams(MATCH, 0, 1f))
        scrim.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        scrim.alpha = 0f
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))
        scrim.animate().alpha(1f).setDuration(160).start()
        view = scrim
    }

    fun close() {
        val v = view ?: return
        view = null
        (activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(v.windowToken, 0)
        v.animate().alpha(0f).setDuration(120).withEndAction { root.removeView(v) }.start()
    }
}
