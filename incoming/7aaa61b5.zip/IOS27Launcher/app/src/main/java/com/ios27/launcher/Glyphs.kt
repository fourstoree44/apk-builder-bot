package com.ios27.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

/** Ikon vektor yang digambar lewat Canvas, supaya semua ikon panel seragam (bukan emoji). */
enum class G {
    AIRPLANE, CELL, WIFI, BT, TORCH, HOTSPOT, CAMERA, CALC, ROTATE, MOON, SUN, VOLUME,
    PREV, NEXT, PLAY, PAUSE, GEAR, SEARCH, BELL, NOTE, BOLT, GRID, DROP, ISLAND, IMAGE,
    PHONE, CLOSE, CHEVRON, BATTERY, SLIDERS, INFO, TRASH
}

object Glyphs {
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    private val rf = RectF()

    /** Gambar ikon [g] berpusat di (cx, cy) dalam kotak berukuran [u] piksel. */
    fun draw(c: Canvas, g: G, cx: Float, cy: Float, u: Float, color: Int) {
        stroke.color = color
        fill.color = color
        stroke.strokeWidth = 0.09f
        c.save()
        c.translate(cx, cy)
        c.scale(u, u)
        when (g) {
            G.WIFI -> {
                val y0 = 0.3f
                for (r in floatArrayOf(0.2f, 0.37f, 0.54f)) {
                    rf.set(-r, y0 - r, r, y0 + r)
                    c.drawArc(rf, -135f, 90f, false, stroke)
                }
                c.drawCircle(0f, y0, 0.06f, fill)
            }
            G.CELL -> {
                val hs = floatArrayOf(0.25f, 0.45f, 0.65f, 0.85f)
                for (i in 0 until 4) {
                    val x = -0.4f + i * 0.21f
                    rf.set(x, 0.42f - hs[i], x + 0.14f, 0.42f)
                    c.drawRoundRect(rf, 0.035f, 0.035f, fill)
                }
            }
            G.AIRPLANE -> {
                path.reset()
                path.moveTo(0f, -0.5f); path.lineTo(0.07f, -0.38f); path.lineTo(0.08f, -0.1f)
                path.lineTo(0.5f, 0.14f); path.lineTo(0.5f, 0.24f); path.lineTo(0.08f, 0.1f)
                path.lineTo(0.06f, 0.32f); path.lineTo(0.2f, 0.43f); path.lineTo(0.2f, 0.5f)
                path.lineTo(0f, 0.44f); path.lineTo(-0.2f, 0.5f); path.lineTo(-0.2f, 0.43f)
                path.lineTo(-0.06f, 0.32f); path.lineTo(-0.08f, 0.1f); path.lineTo(-0.5f, 0.24f)
                path.lineTo(-0.5f, 0.14f); path.lineTo(-0.08f, -0.1f); path.lineTo(-0.07f, -0.38f)
                path.close()
                c.drawPath(path, fill)
            }
            G.BT -> {
                path.reset()
                path.moveTo(-0.24f, -0.2f); path.lineTo(0.22f, 0.2f); path.lineTo(0f, 0.42f)
                path.lineTo(0f, -0.42f); path.lineTo(0.22f, -0.2f); path.lineTo(-0.24f, 0.2f)
                c.drawPath(path, stroke)
            }
            G.TORCH -> {
                path.reset()
                path.moveTo(-0.22f, -0.46f); path.lineTo(0.22f, -0.46f)
                path.lineTo(0.15f, -0.2f); path.lineTo(-0.15f, -0.2f); path.close()
                c.drawPath(path, stroke)
                rf.set(-0.15f, -0.2f, 0.15f, 0.46f)
                c.drawRoundRect(rf, 0.06f, 0.06f, stroke)
                c.drawLine(0f, -0.02f, 0f, 0.1f, stroke)
            }
            G.HOTSPOT -> {
                c.drawCircle(0f, 0f, 0.1f, fill)
                for (r in floatArrayOf(0.27f, 0.45f)) {
                    rf.set(-r, -r, r, r)
                    c.drawArc(rf, -45f, 90f, false, stroke)
                    c.drawArc(rf, 135f, 90f, false, stroke)
                }
            }
            G.CAMERA -> {
                rf.set(-0.46f, -0.26f, 0.46f, 0.36f)
                c.drawRoundRect(rf, 0.1f, 0.1f, stroke)
                c.drawCircle(0f, 0.05f, 0.16f, stroke)
                rf.set(-0.14f, -0.4f, 0.1f, -0.26f)
                c.drawRoundRect(rf, 0.04f, 0.04f, fill)
            }
            G.CALC -> {
                rf.set(-0.34f, -0.46f, 0.34f, 0.46f)
                c.drawRoundRect(rf, 0.08f, 0.08f, stroke)
                rf.set(-0.22f, -0.34f, 0.22f, -0.14f)
                c.drawRoundRect(rf, 0.03f, 0.03f, stroke)
                for (row in 0 until 3) for (col in 0 until 3) {
                    c.drawCircle(-0.16f + col * 0.16f, 0.04f + row * 0.15f, 0.04f, fill)
                }
            }
            G.ROTATE -> {
                val r = 0.34f
                rf.set(-r, -r, r, r)
                c.drawArc(rf, -50f, 270f, false, stroke)
                val a = Math.toRadians(220.0)
                val ex = (r * cos(a)).toFloat(); val ey = (r * sin(a)).toFloat()
                val tx = (-sin(a)).toFloat(); val ty = cos(a).toFloat()
                val nx = cos(a).toFloat(); val ny = sin(a).toFloat()
                path.reset()
                path.moveTo(ex + tx * 0.14f, ey + ty * 0.14f)
                path.lineTo(ex + nx * 0.12f, ey + ny * 0.12f)
                path.lineTo(ex - nx * 0.12f, ey - ny * 0.12f)
                path.close()
                c.drawPath(path, fill)
                rf.set(-0.1f, -0.02f, 0.1f, 0.14f)
                c.drawRoundRect(rf, 0.03f, 0.03f, fill)
                rf.set(-0.065f, -0.12f, 0.065f, 0.06f)
                c.drawArc(rf, 180f, 180f, false, stroke)
            }
            G.MOON -> {
                val a = Path(); a.addCircle(0f, 0f, 0.4f, Path.Direction.CW)
                val b = Path(); b.addCircle(0.2f, -0.14f, 0.34f, Path.Direction.CW)
                a.op(b, Path.Op.DIFFERENCE)
                c.drawPath(a, fill)
            }
            G.SUN -> {
                c.drawCircle(0f, 0f, 0.2f, fill)
                for (i in 0 until 8) {
                    val a = i * Math.PI / 4
                    c.drawLine((0.32 * cos(a)).toFloat(), (0.32 * sin(a)).toFloat(),
                        (0.46 * cos(a)).toFloat(), (0.46 * sin(a)).toFloat(), stroke)
                }
            }
            G.VOLUME -> {
                path.reset()
                path.moveTo(-0.46f, -0.14f); path.lineTo(-0.26f, -0.14f); path.lineTo(0f, -0.36f)
                path.lineTo(0f, 0.36f); path.lineTo(-0.26f, 0.14f); path.lineTo(-0.46f, 0.14f)
                path.close()
                c.drawPath(path, fill)
                for (r in floatArrayOf(0.2f, 0.38f)) {
                    rf.set(0.02f - r, -r, 0.02f + r, r)
                    c.drawArc(rf, -40f, 80f, false, stroke)
                }
            }
            G.PREV -> {
                path.reset()
                path.moveTo(0f, -0.3f); path.lineTo(0f, 0.3f); path.lineTo(-0.45f, 0f); path.close()
                path.moveTo(0.45f, -0.3f); path.lineTo(0.45f, 0.3f); path.lineTo(0f, 0f); path.close()
                c.drawPath(path, fill)
            }
            G.NEXT -> {
                path.reset()
                path.moveTo(0f, -0.3f); path.lineTo(0f, 0.3f); path.lineTo(0.45f, 0f); path.close()
                path.moveTo(-0.45f, -0.3f); path.lineTo(-0.45f, 0.3f); path.lineTo(0f, 0f); path.close()
                c.drawPath(path, fill)
            }
            G.PLAY -> {
                path.reset()
                path.moveTo(-0.28f, -0.4f); path.lineTo(-0.28f, 0.4f); path.lineTo(0.4f, 0f); path.close()
                c.drawPath(path, fill)
            }
            G.PAUSE -> {
                rf.set(-0.3f, -0.4f, -0.06f, 0.4f); c.drawRoundRect(rf, 0.05f, 0.05f, fill)
                rf.set(0.06f, -0.4f, 0.3f, 0.4f); c.drawRoundRect(rf, 0.05f, 0.05f, fill)
            }
            G.GEAR -> {
                rf.set(-0.26f, -0.26f, 0.26f, 0.26f)
                c.drawOval(rf, stroke)
                for (i in 0 until 8) {
                    c.save(); c.rotate(i * 45f)
                    rf.set(-0.06f, -0.47f, 0.06f, -0.31f)
                    c.drawRoundRect(rf, 0.03f, 0.03f, fill)
                    c.restore()
                }
            }
            G.SEARCH -> {
                c.drawCircle(-0.08f, -0.08f, 0.28f, stroke)
                c.drawLine(0.13f, 0.13f, 0.42f, 0.42f, stroke)
            }
            G.BELL -> {
                path.reset()
                path.moveTo(-0.3f, 0.2f); path.lineTo(-0.3f, -0.05f)
                rf.set(-0.3f, -0.35f, 0.3f, 0.25f)
                path.arcTo(rf, 180f, 180f)
                path.lineTo(0.3f, 0.2f); path.close()
                c.drawPath(path, fill)
                rf.set(-0.42f, 0.16f, 0.42f, 0.25f)
                c.drawRoundRect(rf, 0.045f, 0.045f, fill)
                c.drawCircle(0f, 0.37f, 0.07f, fill)
            }
            G.NOTE -> {
                c.drawCircle(-0.16f, 0.28f, 0.15f, fill)
                c.drawLine(-0.02f, 0.28f, -0.02f, -0.4f, stroke)
                c.drawLine(-0.02f, -0.4f, 0.34f, -0.26f, stroke)
            }
            G.BOLT -> {
                path.reset()
                path.moveTo(0.12f, -0.5f); path.lineTo(-0.26f, 0.08f); path.lineTo(-0.02f, 0.08f)
                path.lineTo(-0.12f, 0.5f); path.lineTo(0.26f, -0.1f); path.lineTo(0.02f, -0.1f)
                path.close()
                c.drawPath(path, fill)
            }
            G.GRID -> {
                for (sx in floatArrayOf(-0.42f, 0.06f)) for (sy in floatArrayOf(-0.42f, 0.06f)) {
                    rf.set(sx, sy, sx + 0.36f, sy + 0.36f)
                    c.drawRoundRect(rf, 0.08f, 0.08f, fill)
                }
            }
            G.DROP -> {
                path.reset()
                path.moveTo(0f, -0.5f); path.lineTo(0.27f, 0.02f); path.lineTo(-0.27f, 0.02f); path.close()
                c.drawPath(path, fill)
                c.drawCircle(0f, 0.14f, 0.3f, fill)
            }
            G.ISLAND -> {
                rf.set(-0.46f, -0.16f, 0.46f, 0.16f)
                c.drawRoundRect(rf, 0.16f, 0.16f, fill)
            }
            G.IMAGE -> {
                rf.set(-0.44f, -0.36f, 0.44f, 0.36f)
                c.drawRoundRect(rf, 0.08f, 0.08f, stroke)
                c.drawCircle(-0.2f, -0.12f, 0.07f, fill)
                path.reset()
                path.moveTo(-0.44f, 0.24f); path.lineTo(-0.1f, -0.04f); path.lineTo(0.12f, 0.16f)
                path.lineTo(0.24f, 0.06f); path.lineTo(0.44f, 0.26f)
                c.drawPath(path, stroke)
            }
            G.PHONE -> {
                rf.set(-0.26f, -0.46f, 0.26f, 0.46f)
                c.drawRoundRect(rf, 0.08f, 0.08f, stroke)
                c.drawLine(-0.08f, 0.34f, 0.08f, 0.34f, stroke)
            }
            G.CLOSE -> {
                c.drawLine(-0.3f, -0.3f, 0.3f, 0.3f, stroke)
                c.drawLine(0.3f, -0.3f, -0.3f, 0.3f, stroke)
            }
            G.CHEVRON -> {
                path.reset()
                path.moveTo(-0.12f, -0.3f); path.lineTo(0.14f, 0f); path.lineTo(-0.12f, 0.3f)
                c.drawPath(path, stroke)
            }
            G.BATTERY -> {
                rf.set(-0.46f, -0.24f, 0.36f, 0.24f)
                c.drawRoundRect(rf, 0.09f, 0.09f, stroke)
                rf.set(0.4f, -0.08f, 0.48f, 0.08f)
                c.drawRoundRect(rf, 0.03f, 0.03f, fill)
                rf.set(-0.37f, -0.15f, 0.1f, 0.15f)
                c.drawRoundRect(rf, 0.04f, 0.04f, fill)
            }
            G.SLIDERS -> {
                for (i in -1..1) {
                    val y = i * 0.3f
                    c.drawLine(-0.42f, y, 0.42f, y, stroke)
                    c.drawCircle(i * 0.2f, y, 0.09f, fill)
                }
            }
            G.INFO -> {
                c.drawCircle(0f, 0f, 0.4f, stroke)
                c.drawLine(0f, -0.02f, 0f, 0.2f, stroke)
                c.drawCircle(0f, -0.17f, 0.04f, fill)
            }
            G.TRASH -> {
                c.drawLine(-0.4f, -0.3f, 0.4f, -0.3f, stroke)
                c.drawLine(-0.1f, -0.3f, -0.1f, -0.42f, stroke)
                c.drawLine(0.1f, -0.3f, 0.1f, -0.42f, stroke)
                path.reset()
                path.moveTo(-0.3f, -0.2f); path.lineTo(-0.24f, 0.44f); path.lineTo(0.24f, 0.44f); path.lineTo(0.3f, -0.2f)
                c.drawPath(path, stroke)
            }
        }
        c.restore()
    }
}

/** View kecil yang menggambar satu ikon di tengahnya. */
class GlyphView(ctx: Context, g: G, color: Int = Color.WHITE, private val scale: Float = 0.62f) : View(ctx) {
    var glyph: G = g
        set(v) { field = v; invalidate() }
    var tint: Int = color
        set(v) { field = v; invalidate() }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height) * scale
        Glyphs.draw(c, glyph, width / 2f, height / 2f, s, tint)
    }
}
