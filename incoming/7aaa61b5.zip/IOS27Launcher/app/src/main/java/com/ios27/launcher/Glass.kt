package com.ios27.launcher

import android.content.Context
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.View
import java.lang.ref.WeakReference
import kotlin.math.max
import kotlin.math.min

/** Daftar semua panel kaca, supaya bisa digambar ulang serentak (slider berubah, halaman digeser). */
object GlassRegistry {
    private val list = ArrayList<WeakReference<GlassDrawable>>()

    @Synchronized fun add(d: GlassDrawable) {
        if (list.size > 300) list.removeAll { it.get() == null }
        list.add(WeakReference(d))
    }

    @Synchronized fun refresh() {
        list.removeAll { it.get() == null }
        list.forEach { it.get()?.invalidateSelf() }
    }
}

/**
 * Panel "Liquid Glass".
 *
 * Kalau wallpaper launcher tersedia ([Backdrop]), panel menggambar potongan wallpaper blur yang persis
 * ada di belakangnya, dengan tepi yang membelokkan isi di belakangnya seperti lensa (refraksi),
 * lalu menambah warna kaca tipis, kilau di atas, dan garis tepi cahaya (specular rim).
 * Kalau tidak ada (misalnya panel di atas aplikasi lain), dipakai kaca buram gelap dengan kilau yang sama.
 */
class GlassDrawable(
    private val ctx: Context,
    private val radiusPx: Float,
    private val strong: Boolean = false,
    private val useBackdrop: Boolean = true
) : Drawable() {

    private val gx = 12
    private val gy = 12
    private val verts = FloatArray((gx + 1) * (gy + 1) * 2)
    private val texs = FloatArray((gx + 1) * (gy + 1) * 2)
    private val idx = ShortArray(gx * gy * 6)

    private val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { isFilterBitmap = true }
    private val flat = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shade = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rimSoft = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }

    private val rect = RectF()
    private val clip = Path()
    private val loc = IntArray(2)
    private var shaderBmp: android.graphics.Bitmap? = null
    private var key = ""

    private val boost = ColorMatrixColorFilter(ColorMatrix().apply {
        setSaturation(1.55f)
        postConcat(ColorMatrix(floatArrayOf(
            1.06f, 0f, 0f, 0f, 12f,
            0f, 1.06f, 0f, 0f, 12f,
            0f, 0f, 1.06f, 0f, 12f,
            0f, 0f, 0f, 1f, 0f
        )))
    })

    init {
        GlassRegistry.add(this)
        var k = 0
        for (j in 0 until gy) for (i in 0 until gx) {
            val a = j * (gx + 1) + i
            val b = a + 1
            val c = a + gx + 1
            val d = c + 1
            idx[k++] = a.toShort(); idx[k++] = b.toShort(); idx[k++] = c.toShort()
            idx[k++] = b.toShort(); idx[k++] = d.toShort(); idx[k++] = c.toShort()
        }
    }

    private fun sq(v: Float) = v * v

    private fun rebuild(w: Float, h: Float, refract: Float, edgeOn: Boolean) {
        sheen.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(
                Color.argb((90 * refract + 16).toInt(), 255, 255, 255),
                Color.argb(10, 255, 255, 255),
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, 0.42f, 1f), Shader.TileMode.CLAMP
        )
        shade.shader = LinearGradient(
            0f, h * 0.55f, 0f, h,
            Color.TRANSPARENT, Color.argb(46, 0, 0, 0), Shader.TileMode.CLAMP
        )
        if (edgeOn) {
            rim.shader = LinearGradient(
                0f, 0f, w, h,
                intArrayOf(
                    Color.argb(if (strong) 250 else 225, 255, 255, 255),
                    Color.argb(34, 255, 255, 255),
                    Color.argb(18, 255, 255, 255),
                    Color.argb(if (strong) 190 else 150, 255, 255, 255)
                ),
                floatArrayOf(0f, 0.38f, 0.62f, 1f), Shader.TileMode.CLAMP
            )
        } else {
            rim.shader = null
            rim.color = Color.argb(46, 255, 255, 255)
        }
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        val bright = Prefs.int(ctx, Prefs.GLASS_BRIGHT) / 100f
        val refract = Prefs.int(ctx, Prefs.REFRACT) / 100f
        val edgeOn = Prefs.bool(ctx, Prefs.EDGE)
        val rw = ctx.dp(1) * 1.25f

        val k = "${b.width()}x${b.height()}|$refract|$edgeOn|$strong"
        if (k != key) { key = k; rebuild(w, h, refract, edgeOn) }

        val r = min(radiusPx, min(w, h) / 2f)
        canvas.save()
        canvas.translate(b.left.toFloat(), b.top.toFloat())
        rect.set(0f, 0f, w, h)
        clip.reset()
        clip.addRoundRect(rect, r, r, Path.Direction.CW)

        canvas.save()
        canvas.clipPath(clip)

        val bmp = if (useBackdrop) Backdrop.blurred else null
        val host = callback as? View
        if (bmp != null && host != null) {
            host.getLocationOnScreen(loc)
            val sx = (loc[0] + b.left).toFloat()
            val sy = (loc[1] + b.top).toFloat()
            val scale = bmp.width.toFloat() / Backdrop.screenW
            if (shaderBmp !== bmp) {
                shaderBmp = bmp
                body.shader = BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            }
            body.colorFilter = boost

            val bend = ctx.dp(15) * refract
            val rimW = min(ctx.dp(24).toFloat(), min(w, h) / 2.2f)
            for (j in 0..gy) {
                val y = j / gy.toFloat() * h
                for (i in 0..gx) {
                    val x = i / gx.toFloat() * w
                    val p = (j * (gx + 1) + i) * 2
                    verts[p] = x; verts[p + 1] = y
                    var dx = 0f
                    var dy = 0f
                    dx += bend * sq(max(0f, 1f - x / rimW))
                    dx -= bend * sq(max(0f, 1f - (w - x) / rimW))
                    dy += bend * sq(max(0f, 1f - y / rimW))
                    dy -= bend * sq(max(0f, 1f - (h - y) / rimW))
                    texs[p] = (sx + x + dx) * scale
                    texs[p + 1] = (sy + y + dy) * scale
                }
            }
            canvas.drawVertices(
                Canvas.VertexMode.TRIANGLES, verts.size, verts, 0, texs, 0, null, 0, idx, 0, idx.size, body
            )
            // sedikit gelap lalu tint kaca putih, makin tinggi "Glass brightness" makin tebal
            flat.color = Color.argb(34, 0, 0, 0)
            canvas.drawRect(rect, flat)
            flat.color = Color.argb(((0.07f + 0.26f * bright + if (strong) 0.04f else 0f) * 255).toInt(), 255, 255, 255)
            canvas.drawRect(rect, flat)
        } else {
            // tanpa backdrop: kaca buram gelap (dipakai di atas aplikasi lain)
            flat.color = Color.argb((120 + 110 * bright).toInt().coerceAtMost(235), 30, 32, 42)
            canvas.drawRect(rect, flat)
            flat.color = Color.argb(20, 255, 255, 255)
            canvas.drawRect(rect, flat)
        }
        canvas.drawRect(rect, shade)
        canvas.drawRect(rect, sheen)

        // cahaya lembut di dalam tepi
        rimSoft.strokeWidth = ctx.dp(5).toFloat()
        rimSoft.color = Color.argb(if (edgeOn) 26 else 12, 255, 255, 255)
        canvas.drawPath(clip, rimSoft)
        canvas.restore()

        // garis tepi cahaya (specular rim)
        rim.strokeWidth = rw
        val inset = rw / 2f
        val rr = RectF(inset, inset, w - inset, h - inset)
        canvas.drawRoundRect(rr, max(0f, r - inset), max(0f, r - inset), rim)
        canvas.restore()
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
