# rzkylauncher v1.4 – Control Center & Island Touch Update

Project Android Native Kotlin untuk Android 11+.

## Update v1.4
- Control Center in-app dengan pintasan Wi-Fi, Bluetooth, Hotspot, layar, pengaturan volume media, dan tombol senter (meminta izin kamera saat diperlukan).
- Menu izin launcher menyediakan pintasan untuk menjadikan rzkylauncher sebagai launcher default dan membuka izin overlay/notifikasi.
- Lock Screen preview di dalam aplikasi. Ini bukan pengganti lock screen keamanan Android.
- Dynamic Island diperbesar dengan target sentuh minimum lebih nyaman dan ukuran responsif terhadap lebar layar.
- Dynamic Island berjalan sebagai foreground service dengan notifikasi persisten agar lebih andal ketika aplikasi lain dibuka.

## Build
Jalankan `./gradlew assembleDebug` dengan JDK 17 dan koneksi untuk mengunduh Gradle 8.7 serta dependensi.

## Batasan Android
- Tombol Home/Back/Recent Apps sistem tidak dapat dikunci atau diambil alih launcher biasa. Pilih rzkylauncher sebagai Home default agar tombol Home kembali ke launcher. Recent Apps tetap dikendalikan Android.
- Launcher tidak dapat mengganti popup volume/quick settings global atau mengubah UI internal semua aplikasi.
- Status media real-time memerlukan Notification Access (NotificationListenerService) dan status hotspot bergantung pada API/izin yang dibatasi oleh versi Android serta vendor.
- Preview Lock Screen hanya tampilan dalam aplikasi; layar kunci aman tetap milik Android.
- Beberapa vendor (termasuk Tecno) menerapkan manajemen baterai agresif. Izinkan background/auto-start secara manual jika sistem mematikannya.

## Konfigurasi yang dipertahankan
Gradle 8.7, AGP 8.5.2, Kotlin 1.9.24, JDK 17, compileSdk/targetSdk 34, namespace dan applicationId tetap.

## Dynamic Glass compatibility

- Dynamic Glass appearance controls are available only on Android 13 (API 33) and newer.
- Android 11 and 12 keep the standard translucent panel style; the Dynamic Glass controls show an availability message.
- Glass opacity and enable/disable preferences are stored locally in the `island` preferences.


## rzkylauncher v1.6 — Settings access update

- Added a persistent gear button on the Home screen to open launcher settings.
- Added a settings dashboard for Home/icon display, wallpaper/photo, Android widgets, App Library, Dynamic Glass (Android 13+), Control Center, Dynamic Island, Lock Screen preview, permissions, and Android settings.
- Added a Navigation & Gestures page explaining in-launcher horizontal paging and linking to Android display/navigation settings.
- Android system Back/Home/Recents buttons remain controlled by Android/OEM for device safety.
