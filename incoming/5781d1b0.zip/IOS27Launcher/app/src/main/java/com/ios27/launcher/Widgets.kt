package com.ios27.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import java.text.DateFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Widget kalender satu bulan, tanggal hari ini ditandai lingkaran merah. */
class CalendarWidgetView(ctx: Context) : View(ctx) {

    private val title = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val head = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#AEAEB2")
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val num = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
    }
    private val today = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E5453C") }

    override fun onDraw(c: Canvas) {
        val cal = Calendar.getInstance()
        val todayDay = cal.get(Calendar.DAY_OF_MONTH)
        val first = (cal.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1) }
        val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val firstDow = cal.firstDayOfWeek
        val offset = (first.get(Calendar.DAY_OF_WEEK) - firstDow + 7) % 7

        val pad = context.dp(12).toFloat()
        val w = width - pad * 2
        val colW = w / 7f
        val rowH = (height - pad * 2) / 8f // judul + nama hari + 6 baris tanggal
        val ts = rowH * 0.62f
        title.textSize = ts
        head.textSize = ts
        num.textSize = ts

        val month = SimpleDateFormat("MMMM", Locale.getDefault()).format(Date()).uppercase()
        c.drawText(month, pad, pad + rowH * 0.78f, title)

        val names = DateFormatSymbols.getInstance(Locale.getDefault()).shortWeekdays
        for (i in 0 until 7) {
            val dow = (firstDow - 1 + i) % 7 + 1
            val letter = names[dow].take(1).uppercase()
            c.drawText(letter, pad + colW * (i + 0.5f), pad + rowH * 1.78f, head)
        }
        for (d in 1..daysInMonth) {
            val idx = offset + d - 1
            val col = idx % 7
            val row = idx / 7
            val cx = pad + colW * (col + 0.5f)
            val cy = pad + rowH * (2.78f + row)
            if (d == todayDay) c.drawCircle(cx, cy - ts * 0.34f, rowH * 0.46f, today)
            c.drawText(d.toString(), cx, cy, num)
        }
    }
}

/** Widget baterai: cincin hijau, ikon HP di tengah, persen besar di bawah. */
class BatteryWidgetView(ctx: Context) : View(ctx) {

    private var level = 100
    private var charging = false

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.parseColor("#6E6E73")
    }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val glyph = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = Color.parseColor("#D1D1D6")
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
    private val bolt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#30D158") }
    private val rect = RectF()

    fun set(level: Int, charging: Boolean) {
        this.level = level.coerceIn(0, 100)
        this.charging = charging
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val pad = context.dp(14).toFloat()
        val size = minOf(width, height) * 0.46f
        val stroke = size * 0.14f
        track.strokeWidth = stroke
        arc.strokeWidth = stroke
        rect.set(pad + stroke / 2, pad + stroke / 2, pad + size - stroke / 2, pad + size - stroke / 2)
        c.drawArc(rect, 0f, 360f, false, track)

        arc.color = when {
            charging -> Color.parseColor("#30D158")
            level <= 20 -> Color.parseColor("#FF453A")
            else -> Color.parseColor("#30D158")
        }
        c.drawArc(rect, -90f, 360f * level / 100f, false, arc)

        // ikon HP
        val cx = pad + size / 2
        val cy = pad + size / 2
        glyph.strokeWidth = size * 0.045f
        val pw = size * 0.17f
        val ph = size * 0.3f
        c.drawRoundRect(cx - pw, cy - ph, cx + pw, cy + ph, pw * 0.4f, pw * 0.4f, glyph)

        if (charging) {
            val bx = pad + size * 0.78f
            val by = pad + size * 0.02f
            val s = size * 0.2f
            val path = android.graphics.Path().apply {
                moveTo(bx + s * 0.6f, by)
                lineTo(bx, by + s * 0.62f)
                lineTo(bx + s * 0.42f, by + s * 0.62f)
                lineTo(bx + s * 0.25f, by + s * 1.25f)
                lineTo(bx + s * 0.9f, by + s * 0.5f)
                lineTo(bx + s * 0.46f, by + s * 0.5f)
                close()
            }
            c.drawPath(path, bolt)
        }

        text.textSize = height * 0.2f
        c.drawText("$level%", pad, height - pad - text.descent(), text)
    }
}
