package com.ios27.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import java.lang.ref.WeakReference

/** Arah cahaya tepi kaca. Berubah mengikuti kemiringan HP bila "Highlight follows tilt" aktif. */
object GlassRegistry {
    @Volatile var tx = -0.6f
    @Volatile var ty = -0.8f
    private val list = ArrayList<WeakReference<GlassDrawable>>()

    @Synchronized fun add(d: GlassDrawable) { list.add(WeakReference(d)) }

    @Synchronized fun refresh() {
        list.removeAll { it.get() == null }
        list.forEach { it.get()?.invalidateSelf() }
    }
}

/**
 * Panel "Liquid Glass": isi kaca gelap tembus pandang, kilau lembut di atas,
 * dan garis tepi bercahaya. Semua nilainya dibaca dari Prefs saat digambar,
 * jadi slider di Pengaturan langsung terlihat.
 */
class GlassDrawable(
    private val ctx: Context,
    private val radiusPx: Float,
    private val strong: Boolean = false
) : Drawable() {

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = ctx.dp(1) * 1.4f
    }
    private val rect = RectF()

    init { GlassRegistry.add(this) }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val inset = edge.strokeWidth / 2f
        rect.set(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset)
        val r = minOf(radiusPx, rect.height() / 2f, rect.width() / 2f)

        val bright = Prefs.int(ctx, Prefs.GLASS_BRIGHT) / 100f
        val refract = Prefs.int(ctx, Prefs.REFRACT) / 100f
        val baseAlpha = (0.30f + 0.42f * bright + if (strong) 0.08f else 0f).coerceAtMost(0.95f)
        fill.color = Color.argb((255 * baseAlpha).toInt(), 24, 24, 30)
        canvas.drawRoundRect(rect, r, r, fill)

        // kilau lembut dari atas, kekuatannya mengikuti Refraction
        sheen.shader = LinearGradient(
            0f, rect.top, 0f, rect.bottom,
            intArrayOf(
                Color.argb((70 * refract).toInt(), 255, 255, 255),
                Color.argb((10 * refract).toInt(), 255, 255, 255),
                Color.argb((28 * refract).toInt(), 120, 160, 255)
            ),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(rect, r, r, sheen)

        if (Prefs.bool(ctx, Prefs.EDGE)) {
            val follow = Prefs.bool(ctx, Prefs.TILT)
            val dx = if (follow) GlassRegistry.tx else -0.6f
            val dy = if (follow) GlassRegistry.ty else -0.8f
            val cx = rect.centerX()
            val cy = rect.centerY()
            val hw = rect.width() / 2f
            val hh = rect.height() / 2f
            edge.shader = LinearGradient(
                cx + dx * hw, cy + dy * hh, cx - dx * hw, cy - dy * hh,
                intArrayOf(
                    Color.argb(if (strong) 230 else 190, 255, 255, 255),
                    Color.argb(34, 255, 255, 255),
                    Color.argb(if (strong) 150 else 110, 190, 215, 255)
                ),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        } else {
            edge.shader = null
            edge.color = Color.argb(46, 255, 255, 255)
        }
        canvas.drawRoundRect(rect, r, r, edge)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
