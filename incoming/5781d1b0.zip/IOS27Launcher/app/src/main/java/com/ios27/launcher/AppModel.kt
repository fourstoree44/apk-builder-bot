package com.ios27.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.AdaptiveIconDrawable
import android.provider.MediaStore

data class AppEntry(
    val label: String,
    val pkg: String,
    val component: ComponentName,
    val category: Int
)

/** Semua aplikasi berikon launcher. Launcher ini sendiri ikut tampil dan membuka Pengaturan. */
fun loadApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(query, 0)
        .map { ri ->
            val ai = ri.activityInfo
            val self = ai.packageName == ctx.packageName
            AppEntry(
                label = if (self) "Launcher" else ri.loadLabel(pm).toString(),
                pkg = ai.packageName,
                component = ComponentName(ai.packageName, ai.name),
                category = if (self) ApplicationInfo.CATEGORY_PRODUCTIVITY else ai.applicationInfo.category
            )
        }
        .sortedBy { it.label.lowercase() }
}

/** Dock: Telepon, Pesan, Browser, Kamera. Kalau tidak ketemu, diisi aplikasi lain. */
fun resolveDock(ctx: Context, apps: List<AppEntry>): List<AppEntry> {
    val pm = ctx.packageManager
    val wanted = listOf(
        Intent(Intent.ACTION_DIAL),
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER),
        Intent(MediaStore.ACTION_IMAGE_CAPTURE)
    )
    val result = mutableListOf<AppEntry>()
    for (intent in wanted) {
        val pkg = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName
        val hit = apps.firstOrNull {
            it.pkg == pkg && it.pkg != ctx.packageName && result.none { r -> r.pkg == it.pkg }
        }
        if (hit != null) result += hit
    }
    for (a in apps) {
        if (result.size >= 4) break
        if (a.pkg != ctx.packageName && result.none { it.pkg == a.pkg }) result += a
    }
    return result.take(4)
}

fun categoryName(a: AppEntry): String = when (a.category) {
    ApplicationInfo.CATEGORY_SOCIAL -> "Sosial"
    ApplicationInfo.CATEGORY_AUDIO,
    ApplicationInfo.CATEGORY_VIDEO,
    ApplicationInfo.CATEGORY_IMAGE -> "Hiburan"
    ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Produktivitas"
    ApplicationInfo.CATEGORY_GAME -> "Game"
    ApplicationInfo.CATEGORY_NEWS -> "Berita"
    ApplicationInfo.CATEGORY_MAPS -> "Perjalanan"
    else -> "Utilitas"
}

val CATEGORY_ORDER = listOf(
    "Sosial", "Hiburan", "Produktivitas", "Game", "Berita", "Perjalanan", "Utilitas"
)

/**
 * Ikon dipotong sesuai "Corner rounding". Gaya Glass menaruh ikon di atas ubin kaca gelap
 * dengan tepi bercahaya (tema Liquid Glass). Gaya Original memakai latar ikon aslinya.
 */
fun makeIcon(ctx: Context, app: AppEntry, sizePx: Int): Bitmap {
    val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val s = sizePx.toFloat()
    val radius = s / 2f * (Prefs.int(ctx, Prefs.ICON_ROUND) / 100f)
    val glass = Prefs.bool(ctx, Prefs.ICON_GLASS)
    val clip = Path().apply { addRoundRect(RectF(0f, 0f, s, s), radius, radius, Path.Direction.CW) }

    c.save()
    c.clipPath(clip)
    if (glass) {
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 0f, 0f, s,
                Color.parseColor("#34343C"), Color.parseColor("#121216"), Shader.TileMode.CLAMP
            )
        }
        c.drawRect(0f, 0f, s, s, fill)
        val sheen = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 0f, 0f, s * 0.6f,
                Color.argb(46, 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP
            )
        }
        c.drawRect(0f, 0f, s, s * 0.6f, sheen)
    }
    try {
        val raw = ctx.packageManager.getActivityIcon(app.component)
        val dr = raw.constantState?.newDrawable()?.mutate() ?: raw
        if (dr is AdaptiveIconDrawable) {
            // layer adaptif 108dp dengan area aman 72dp: perbesar supaya area aman memenuhi ubin
            val ext = (s * if (glass) 0.10f else 0.25f).toInt()
            if (!glass) dr.background?.let {
                it.setBounds(-ext, -ext, sizePx + ext, sizePx + ext); it.draw(c)
            }
            dr.foreground?.let {
                it.setBounds(-ext, -ext, sizePx + ext, sizePx + ext); it.draw(c)
            }
        } else {
            if (!glass) c.drawColor(Color.WHITE)
            val inset = (s * if (glass) 0.16f else 0.12f).toInt()
            dr.setBounds(inset, inset, sizePx - inset, sizePx - inset)
            dr.draw(c)
        }
    } catch (_: Exception) {
        c.drawColor(Color.parseColor("#48484A"))
    }
    c.restore()

    if (glass) {
        val sw = (s * 0.018f).coerceAtLeast(1.5f)
        val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = sw
            shader = LinearGradient(
                0f, 0f, s, s,
                intArrayOf(Color.argb(200, 255, 255, 255), Color.argb(30, 255, 255, 255), Color.argb(110, 190, 215, 255)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        }
        val r = RectF(sw / 2, sw / 2, s - sw / 2, s - sw / 2)
        c.drawRoundRect(r, radius, radius, edge)
    }
    return bmp
}
