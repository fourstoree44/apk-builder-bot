package com.ios27.launcher

import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity(), SensorEventListener {

    private lateinit var root: FrameLayout
    private lateinit var scroller: PagerScroller
    private lateinit var pagesRow: LinearLayout
    private lateinit var dotsRow: LinearLayout
    private lateinit var bottomBox: LinearLayout
    private lateinit var dockBox: LinearLayout
    private lateinit var island: DynamicIslandView
    private lateinit var search: SearchOverlay

    private var apps: List<AppEntry> = emptyList()
    private var dockApps: List<AppEntry> = emptyList()
    private var batteryWidget: BatteryWidgetView? = null
    private val iconCache = ConcurrentHashMap<String, Bitmap>()

    private val screenW by lazy { resources.displayMetrics.widthPixels }
    private val screenH by lazy { resources.displayMetrics.heightPixels }

    private var navInset = 0
    private var statusInset = 0
    private var pageCount = 1
    private var libraryIndex = 0
    private var batteryLevel = 100
    private var charging = false
    private var batteryKnown = false
    private var downX = 0f
    private var downY = 0f

    // ---------------------------------------------------------------- pager

    inner class PagerScroller(ctx: Context) : HorizontalScrollView(ctx) {
        private var flung = false

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) flung = false
            val r = super.onTouchEvent(ev)
            if ((ev.actionMasked == MotionEvent.ACTION_UP ||
                    ev.actionMasked == MotionEvent.ACTION_CANCEL) && !flung) snapNearest()
            return r
        }

        override fun fling(velocityX: Int) {
            flung = true
            val p = scrollX.toFloat() / screenW
            val target = when {
                velocityX > 600 -> Math.floor(p.toDouble()).toInt() + 1
                velocityX < -600 -> Math.ceil(p.toDouble()).toInt() - 1
                else -> Math.round(p)
            }
            smoothScrollTo(target.coerceIn(0, pageCount - 1) * screenW, 0)
        }

        fun snapNearest() {
            val i = Math.round(scrollX.toFloat() / screenW).coerceIn(0, pageCount - 1)
            smoothScrollTo(i * screenW, 0)
        }
    }

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.isNavigationBarContrastEnforced = false

        root = FrameLayout(this)
        setContentView(root)

        scroller = PagerScroller(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setOnScrollChangeListener { _, x, _, _, _ ->
                val page = (x + screenW / 2) / screenW
                updateDots(page)
                applyBlur(page == libraryIndex)
            }
        }
        pagesRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        scroller.addView(pagesRow, FrameLayout.LayoutParams(WRAP, MATCH))
        root.addView(scroller, FrameLayout.LayoutParams(MATCH, MATCH))

        bottomBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        dotsRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        bottomBox.addView(dotsRow, LinearLayout.LayoutParams(WRAP, dp(16)))

        val searchPill = TextView(this).apply {
            text = "Search"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = glass(18, true)
            setPadding(dp(34), 0, dp(34), 0)
            setOnClickListener { search.show(apps, null, null) }
        }
        bottomBox.addView(searchPill, LinearLayout.LayoutParams(WRAP, dp(36)).apply {
            topMargin = dp(4); bottomMargin = dp(10)
        })

        dockBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = glass(32, true)
            setPadding(dp(10), 0, dp(10), 0)
        }
        bottomBox.addView(dockBox, LinearLayout.LayoutParams(MATCH, dp(92)).apply {
            marginStart = dp(16); marginEnd = dp(16)
        })
        root.addView(bottomBox, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))

        island = DynamicIslandView(this)
        root.addView(island, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL))

        search = SearchOverlay(this, root, { app, px -> iconFor(app, px) }, { app, v -> launch(app, v) })

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val nav = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            if (nav != navInset || top != statusInset) {
                navInset = nav; statusInset = top
                rebuild()
            }
            insets
        }

        registerReceiver(pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        })
        reloadApps()
        askOverlayPermissionOnce()
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        applyIslandMode()
        applyNavigation()
        iconCache.clear()        // pengaturan ikon mungkin berubah di Settings
        if (apps.isNotEmpty()) rebuild()
        if (Prefs.bool(this, Prefs.TILT)) {
            val sm = getSystemService(SENSOR_SERVICE) as SensorManager
            sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
                sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
            }
        }
    }

    override fun onPause() {
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        (getSystemService(SENSOR_SERVICE) as SensorManager).unregisterListener(this)
        super.onPause()
    }

    override fun onDestroy() {
        try { unregisterReceiver(pkgReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) {
            search.close()
            island.setState(DynamicIslandView.State.COLLAPSED)
            scroller.smoothScrollTo(0, 0)
        }
    }

    @Deprecated("Launcher tidak keluar dengan tombol back")
    override fun onBackPressed() {
        if (search.isShowing) search.close() else scroller.smoothScrollTo(0, 0)
    }

    // ----------------------------------------------------- tilt & gestures

    override fun onSensorChanged(e: SensorEvent) {
        // kemiringan HP menggeser arah cahaya di tepi kaca
        GlassRegistry.tx = (-e.values[0] / 6f).coerceIn(-1f, 1f)
        GlassRegistry.ty = (e.values[1] / 6f - 1f).coerceIn(-1f, 1f)
        GlassRegistry.refresh()
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    /** Geser ke bawah di layar utama membuka pencarian. */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = ev.x; downY = ev.y }
            MotionEvent.ACTION_UP -> {
                val dx = ev.x - downX
                val dy = ev.y - downY
                val onLibrary = (scroller.scrollX + screenW / 2) / screenW == libraryIndex
                if (Prefs.bool(this, Prefs.SWIPE_SEARCH) && !search.isShowing && !onLibrary &&
                    dy > dp(140) && Math.abs(dx) < dp(70) && downY < screenH * 0.7f) {
                    tick(root)
                    search.show(apps, null, null)
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun tick(v: View) {
        if (Prefs.bool(this, Prefs.HAPTIC)) v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    }

    private fun applyBlur(on: Boolean) {
        if (Build.VERSION.SDK_INT < 31) return
        val radius = if (on && Prefs.bool(this, Prefs.BLUR)) dp(24) else 0
        try {
            window.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
            val lp = window.attributes
            if (lp.blurBehindRadius != radius) { lp.blurBehindRadius = radius; window.attributes = lp }
        } catch (_: Exception) {}
    }

    private fun applyNavigation() {
        val ctl = window.insetsController ?: return
        if (Prefs.bool(this, Prefs.HIDE_NAV)) {
            ctl.hide(WindowInsets.Type.navigationBars())
            ctl.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else ctl.show(WindowInsets.Type.navigationBars())
    }

    // ---------------------------------------------------------------- data

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { reloadApps() }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val nowCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            val changed = batteryKnown && nowCharging != charging
            batteryLevel = if (scale > 0) level * 100 / scale else level
            charging = nowCharging
            batteryKnown = true
            island.batteryLevel = batteryLevel
            island.charging = charging
            if (changed) island.pulse()
            batteryWidget?.set(batteryLevel, charging)
        }
    }

    private fun reloadApps() {
        Thread {
            val list = loadApps(this)
            val dock = resolveDock(this, list)
            runOnUiThread { apps = list; dockApps = dock; iconCache.clear(); rebuild() }
        }.start()
    }

    private fun iconPx(inDock: Boolean): Int {
        val pct = Prefs.int(this, if (inDock) Prefs.DOCK_ICON_SIZE else Prefs.ICON_SIZE)
        return dp(64) * pct / 100
    }

    private fun iconFor(app: AppEntry, px: Int): Bitmap =
        iconCache.getOrPut("${app.component.flattenToString()}:$px") { makeIcon(this, app, px) }

    private fun launch(app: AppEntry, from: View) {
        val i = if (app.pkg == packageName) Intent(this, SettingsActivity::class.java)
        else Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = app.component
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
        }
        try {
            val opts = ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height)
            startActivity(i, opts.toBundle())
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak bisa membuka ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------------ UI

    private fun rebuild() {
        if (apps.isEmpty()) return
        (bottomBox.layoutParams as FrameLayout.LayoutParams).bottomMargin = navInset + dp(8)
        bottomBox.requestLayout()
        (island.layoutParams as FrameLayout.LayoutParams).topMargin = dp(Prefs.int(this, Prefs.ISLAND_Y))
        island.requestLayout()
        buildDock()
        buildPages()
    }

    private fun buildDock() {
        dockBox.removeAllViews()
        dockApps.forEach {
            dockBox.addView(appCell(it, iconPx(true), false), LinearLayout.LayoutParams(0, MATCH, 1f))
        }
    }

    private fun buildPages() {
        pagesRow.removeAllViews()
        val cols = Prefs.int(this, Prefs.COLS)
        val cfgRows = Prefs.int(this, Prefs.ROWS)
        val sides = dp(Prefs.int(this, Prefs.M_SIDES))
        val topPad = statusInset + dp(Prefs.int(this, Prefs.M_TOP))
        val bottomPad = dp(176) + navInset + dp(Prefs.int(this, Prefs.M_BOTTOM))
        val area = screenH - topPad - bottomPad
        val rowH = (area / cfgRows).coerceAtLeast(dp(72))
        val rows = (area / rowH).coerceAtLeast(3)

        val dockPkgs = dockApps.map { it.pkg }.toSet()
        val grid = apps.filter { it.pkg !in dockPkgs }
        val widgetRows = if (rows >= 5) 2 else 0

        var idx = 0
        var n = 0
        while (idx < grid.size || n == 0) {
            val capacity = ((rows - if (n == 0) widgetRows else 0) * cols).coerceAtLeast(cols)
            val slice = grid.subList(idx, minOf(idx + capacity, grid.size))
            pagesRow.addView(
                gridPage(slice, n == 0 && widgetRows > 0, cols, rowH, rows, sides, topPad, bottomPad),
                LinearLayout.LayoutParams(screenW, MATCH)
            )
            idx += capacity
            n++
        }
        libraryIndex = n
        pagesRow.addView(libraryPage(grid, sides, topPad, bottomPad), LinearLayout.LayoutParams(screenW, MATCH))
        pageCount = n + 1
        buildDots(pageCount)
    }

    private fun gridPage(
        list: List<AppEntry>, withWidgets: Boolean, cols: Int, rowH: Int, rows: Int,
        sides: Int, topPad: Int, bottomPad: Int
    ): View {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(sides, topPad, sides, bottomPad)
            isLongClickable = true
            setOnLongClickListener { tick(it); showHomeMenu(); true }
        }
        val vPos = Prefs.int(this, Prefs.V_POS)
        val used = (list.size + cols - 1) / cols + if (withWidgets) 2 else 0
        val spare = ((rows - used) * rowH).coerceAtLeast(0)
        page.gravity = when (vPos) { 1 -> Gravity.CENTER_VERTICAL; 2 -> Gravity.BOTTOM; else -> Gravity.TOP }
        if (vPos == 1 || vPos == 2) page.setPadding(sides, topPad, sides, bottomPad)
        else page.setPadding(sides, topPad, sides, bottomPad + spare)

        if (withWidgets) page.addView(widgetRow(rowH), LinearLayout.LayoutParams(MATCH, rowH * 2))
        list.chunked(cols).forEach { rowApps ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowApps.forEach { row.addView(appCell(it, iconPx(false), true), LinearLayout.LayoutParams(0, MATCH, 1f)) }
            repeat(cols - rowApps.size) { row.addView(View(this), LinearLayout.LayoutParams(0, MATCH, 1f)) }
            page.addView(row, LinearLayout.LayoutParams(MATCH, rowH))
        }
        return page
    }

    /** Dua widget kaca berdampingan: Calendar dan Batteries, masing-masing dengan label di bawahnya. */
    private fun widgetRow(rowH: Int): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun slot(name: String, content: View): View {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            content.background = glass(24)
            box.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
            box.addView(TextView(this).apply {
                text = name; textSize = 12f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; softShadow()
            }, LinearLayout.LayoutParams(MATCH, dp(24)))
            return box
        }
        row.addView(slot("Calendar", CalendarWidgetView(this)),
            LinearLayout.LayoutParams(0, MATCH, 1f).apply { setMargins(dp(4), dp(4), dp(6), dp(2)) })
        val battery = BatteryWidgetView(this).also { batteryWidget = it; it.set(batteryLevel, charging) }
        row.addView(slot("Batteries", battery),
            LinearLayout.LayoutParams(0, MATCH, 1f).apply { setMargins(dp(6), dp(4), dp(4), dp(2)) })
        return row
    }

    // ------------------------------------------------------------- library

    private fun libraryPage(grid: List<AppEntry>, sides: Int, topPad: Int, bottomPad: Int): View {
        val page = FrameLayout(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(sides, topPad, sides, bottomPad)
        }
        col.addView(TextView(this).apply {
            text = getString(R.string.app_library)
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER_VERTICAL
            background = glass(22, true)
            setPadding(dp(16), 0, dp(16), 0)
            setOnClickListener { search.show(apps, null, null) }
        }, LinearLayout.LayoutParams(MATCH, dp(44)).apply { bottomMargin = dp(12) })

        if (Prefs.bool(this, Prefs.LIB_LIST)) {
            val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val scroll = ScrollView(this).apply {
                isVerticalScrollBarEnabled = false
                addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
            }
            val headers = LinkedHashMap<String, View>()
            val all = (grid + dockApps).sortedBy { it.label.lowercase() }
            all.groupBy { sectionOf(it.label) }.toSortedMap().forEach { (letter, items) ->
                val h = TextView(this).apply {
                    text = letter; textSize = 14f; setTextColor(Color.parseColor("#AEAEB2"))
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                }
                headers[letter] = h
                body.addView(h, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10); bottomMargin = dp(4) })
                items.forEach { app -> body.addView(libraryRow(app), LinearLayout.LayoutParams(MATCH, WRAP)) }
            }
            col.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
            page.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
            page.addView(alphaIndex(headers, scroll, topPad, bottomPad),
                FrameLayout.LayoutParams(dp(24), MATCH, Gravity.END))
        } else {
            col.addView(categoryGrid(grid), LinearLayout.LayoutParams(MATCH, 0, 1f))
            page.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        return page
    }

    private fun sectionOf(label: String): String {
        val c = label.firstOrNull()?.uppercaseChar() ?: '#'
        return if (c in 'A'..'Z') c.toString() else "#"
    }

    private fun libraryRow(app: AppEntry): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(6), dp(24), dp(6))
        }
        val iv = ImageView(this).apply { setImageBitmap(iconFor(app, dp(44))) }
        row.addView(iv, LinearLayout.LayoutParams(dp(44), dp(44)))
        row.addView(TextView(this).apply {
            text = app.label; textSize = 16f; setTextColor(Color.WHITE); maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END; softShadow()
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(14) })
        row.setOnClickListener { launch(app, iv) }
        row.setOnLongClickListener { tick(it); showAppMenu(iv, app); true }
        return row
    }

    /** Indeks huruf di sisi kanan, sentuh atau geser untuk loncat ke huruf. */
    private fun alphaIndex(headers: Map<String, View>, scroll: ScrollView, topPad: Int, bottomPad: Int): View {
        val letters = ('A'..'Z').map { it.toString() } + "#"
        val idx = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(0, topPad + dp(60), 0, bottomPad)
        }
        letters.forEach { l ->
            idx.addView(TextView(this).apply {
                text = l; textSize = 9f; gravity = Gravity.CENTER
                setTextColor(if (l in headers) Prefs.accent(this@MainActivity) else Color.parseColor("#48484A"))
            }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        }
        idx.setOnTouchListener { v, e ->
            val inner = v.height - v.paddingTop - v.paddingBottom
            val i = (((e.y - v.paddingTop) / inner) * letters.size).toInt().coerceIn(0, letters.size - 1)
            // pilih huruf terdekat yang punya aplikasi
            val target = letters.drop(i).firstOrNull { it in headers } ?: letters.take(i).lastOrNull { it in headers }
            target?.let { t -> headers[t]?.let { h -> scroll.scrollTo(0, h.top) } }
            if (e.actionMasked == MotionEvent.ACTION_DOWN) v.parent.requestDisallowInterceptTouchEvent(true)
            true
        }
        return idx
    }

    private fun categoryGrid(grid: List<AppEntry>): View {
        val groups = grid.groupBy { categoryName(it) }
        val names = CATEGORY_ORDER.filter { it in groups }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        names.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { name ->
                row.addView(libraryCard(name, groups.getValue(name)),
                    LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(6), 0, dp(6), dp(14)) })
            }
            if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            body.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        return ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
        }
    }

    private fun libraryCard(name: String, list: List<AppEntry>): View {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(24)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { search.show(apps, name, list) }
        }
        list.take(4).chunked(2).forEach { two ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_HORIZONTAL }
            two.forEach { app -> r.addView(appCell(app, dp(52), false), LinearLayout.LayoutParams(0, dp(66), 1f)) }
            if (two.size == 1) r.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            panel.addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        card.addView(panel, LinearLayout.LayoutParams(MATCH, WRAP))
        card.addView(TextView(this).apply {
            text = name; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE); softShadow()
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        return card
    }

    // ---------------------------------------------------------- app cells

    /** [iconPxSize] dalam piksel. Label mengikuti "App names" dan "Custom text size". */
    private fun appCell(app: AppEntry, iconPxSize: Int, label: Boolean): View {
        val showName = label && Prefs.bool(this, Prefs.SHOW_NAMES)
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (label) Gravity.TOP or Gravity.CENTER_HORIZONTAL else Gravity.CENTER
            setPadding(0, if (label) dp(6) else 0, 0, 0)
        }
        val iv = ImageView(this).apply { setImageBitmap(iconFor(app, iconPxSize)) }
        cell.addView(iv, LinearLayout.LayoutParams(iconPxSize, iconPxSize))
        if (showName) {
            val custom = Prefs.bool(this, Prefs.CUSTOM_TEXT)
            val size = 11f * (if (custom) Prefs.int(this, Prefs.TEXT_SIZE) else 100) / 100f
            val gap = if (custom) Prefs.int(this, Prefs.LABEL_SPACING) else 6
            cell.addView(TextView(this).apply {
                text = app.label; textSize = size; maxLines = 1; gravity = Gravity.CENTER
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(Color.WHITE); softShadow()
            }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(gap); marginStart = dp(2); marginEnd = dp(2) })
        }
        cell.setOnClickListener { tick(it); launch(app, iv) }
        cell.setOnLongClickListener { tick(it); showAppMenu(iv, app); true }
        return cell
    }

    private fun buildDots(n: Int) {
        dotsRow.removeAllViews()
        repeat(n) {
            val dot = View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
                alpha = 0.4f
            }
            dotsRow.addView(dot, LinearLayout.LayoutParams(dp(7), dp(7)).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        updateDots((scroller.scrollX + screenW / 2) / screenW)
    }

    private fun updateDots(sel: Int) {
        for (i in 0 until dotsRow.childCount) dotsRow.getChildAt(i).alpha = if (i == sel) 1f else 0.4f
    }

    // ---------------------------------------------------------------- menus

    private fun showAppMenu(anchor: View, app: AppEntry) {
        PopupMenu(this, anchor).apply {
            menu.add(0, 1, 0, "Info aplikasi")
            if (app.pkg != packageName) menu.add(0, 2, 1, "Copot pemasangan")
            setOnMenuItemClickListener {
                val uri = Uri.parse("package:${app.pkg}")
                when (it.itemId) {
                    1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                    2 -> startActivity(Intent(Intent.ACTION_DELETE, uri))
                }
                true
            }
            show()
        }
    }

    private fun showHomeMenu() {
        val items = arrayOf("Pengaturan launcher", "Ganti wallpaper", "Pilih launcher default")
        AlertDialog.Builder(this).setItems(items) { _, which ->
            when (which) {
                0 -> startActivity(Intent(this, SettingsActivity::class.java))
                1 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
                2 -> startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            }
        }.show()
    }

    // --------------------------------------------------------------- island

    private fun overlayEnabled() = Settings.canDrawOverlays(this) && Prefs.bool(this, Prefs.OVERLAY)

    /** Island sistem dipakai kalau izin overlay ada, kalau tidak island tampil di dalam launcher saja. */
    private fun applyIslandMode() {
        if (overlayEnabled()) {
            IslandOverlayService.refresh(this)
            island.visibility = View.GONE
        } else {
            stopService(Intent(this, IslandOverlayService::class.java))
            island.visibility = View.VISIBLE
        }
    }

    private fun askOverlayPermissionOnce() {
        if (Settings.canDrawOverlays(this) || Prefs.bool(this, Prefs.ASKED)) return
        Prefs.setBool(this, Prefs.ASKED, true)
        AlertDialog.Builder(this)
            .setTitle("Dynamic Island")
            .setMessage(R.string.island_overlay_perm)
            .setPositiveButton("Aktifkan") { _, _ ->
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            .setNegativeButton("Nanti", null)
            .show()
    }
}
