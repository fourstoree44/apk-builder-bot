package com.ios27.launcher

import android.content.Context
import android.graphics.Color
import android.os.Build

/** Semua pengaturan launcher, disimpan di satu SharedPreferences. */
object Prefs {
    const val ICON_SIZE = "icon_size"          // % dari 64dp
    const val DOCK_ICON_SIZE = "dock_icon_size"
    const val ICON_ROUND = "icon_round"        // 0 = kotak, 100 = bulat
    const val ICON_GLASS = "icon_glass"
    const val SHOW_NAMES = "show_names"
    const val COLS = "cols"
    const val ROWS = "rows"
    const val M_SIDES = "m_sides"
    const val M_TOP = "m_top"
    const val M_BOTTOM = "m_bottom"
    const val V_POS = "v_pos"                  // 0 atas, 1 tengah, 2 bawah
    const val BLUR = "blur"
    const val GLASS_BRIGHT = "glass_bright"
    const val EDGE = "edge"
    const val REFRACT = "refract"
    const val TILT = "tilt"
    const val HIDE_NAV = "hide_nav"
    const val CUSTOM_TEXT = "custom_text"
    const val TEXT_SIZE = "text_size"          // %
    const val LABEL_SPACING = "label_spacing"  // dp
    const val DYN_COLOR = "dyn_color"
    const val ISLAND_Y = "island_y"
    const val ISLAND_SCALE = "island_scale"    // %
    const val OVERLAY = "overlay_enabled"
    const val SWIPE_SEARCH = "swipe_search"
    const val HAPTIC = "haptic"
    const val LIB_LIST = "lib_list"
    const val ASKED = "asked"

    private val DEFAULTS: Map<String, Any> = mapOf(
        ICON_SIZE to 92, DOCK_ICON_SIZE to 92, ICON_ROUND to 45, ICON_GLASS to true,
        SHOW_NAMES to true, COLS to 4, ROWS to 7, M_SIDES to 22, M_TOP to 28, M_BOTTOM to 0,
        V_POS to 0, BLUR to true, GLASS_BRIGHT to 48, EDGE to true, REFRACT to 100, TILT to true,
        HIDE_NAV to false, CUSTOM_TEXT to false, TEXT_SIZE to 100, LABEL_SPACING to 6,
        DYN_COLOR to false, ISLAND_Y to 12, ISLAND_SCALE to 100, OVERLAY to true,
        SWIPE_SEARCH to true, HAPTIC to true, LIB_LIST to true, ASKED to false
    )

    private fun sp(c: Context) = c.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    fun int(c: Context, key: String): Int = sp(c).getInt(key, DEFAULTS[key] as Int)
    fun bool(c: Context, key: String): Boolean = sp(c).getBoolean(key, DEFAULTS[key] as Boolean)
    fun setInt(c: Context, key: String, v: Int) = sp(c).edit().putInt(key, v).apply()
    fun setBool(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean(key, v).apply()

    fun resetAll(c: Context) {
        val keep = sp(c).getBoolean(ASKED, false)
        sp(c).edit().clear().putBoolean(ASKED, keep).apply()
    }

    /** Warna aksen: warna sistem (Android 12+) jika Dynamic Color aktif, kalau tidak biru iOS. */
    fun accent(c: Context): Int =
        if (bool(c, DYN_COLOR) && Build.VERSION.SDK_INT >= 31)
            c.getColor(android.R.color.system_accent1_400)
        else Color.parseColor("#0A84FF")
}
