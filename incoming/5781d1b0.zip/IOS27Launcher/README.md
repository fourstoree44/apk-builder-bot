# iOS 27 Launcher (Android 11+)

Launcher bergaya iPhone dengan tema Liquid Glass dan Dynamic Island, untuk Android 11 (API 30) ke atas.

## Fitur
- Tema Liquid Glass: panel kaca gelap, tepi bercahaya, ikon ubin kaca, blur wallpaper di App Library (Android 12+)
- Highlight tepi kaca ikut kemiringan HP
- Widget Calendar dan Batteries (cincin persen) di halaman pertama
- Grid bisa diatur: kolom, baris, margin, posisi vertikal
- Dock 4 aplikasi dari aplikasi default HP
- App Library daftar A-Z dengan indeks huruf di kanan, atau tampilan kategori
- Pencarian aplikasi, dibuka lewat tombol Search atau geser ke bawah di layar utama
- Tekan lama ikon: Info aplikasi, Copot pemasangan
- Tekan lama area kosong: Pengaturan launcher, wallpaper, pilih launcher default
- Pengaturan ala iOS: General, Island, Control, Screen Grid, Glass & Blur, Icons (tombol reset di tiap halaman)

## Dynamic Island
- Pill hitam di atas layar, ketuk untuk melebar (jam, tanggal, cincin baterai)
- Muncul sebentar saat charger dicolok atau dicabut
- Tampil di semua aplikasi bila izin "Tampil di atas aplikasi lain" diberikan, kalau tidak hanya di launcher
- Posisi dan ukuran diatur di Pengaturan > Island, supaya pas dengan lubang kamera HP

## Cara build APK
Android Studio (Koala atau lebih baru): File > Open > pilih folder ini > tunggu sync > Build > Build APK(s).

Terminal (JDK 17 + Android SDK platform 34):

    ./gradlew assembleDebug

APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Jadikan launcher default (tampilan awal HP)
1. Install APK, lalu buka sekali. Ikon "Launcher" membuka Pengaturan.
2. Tekan tombol Home, pilih "iOS 27 Launcher", lalu "Selalu".
   Atau: Pengaturan HP > Aplikasi > Aplikasi default > Aplikasi layar utama.
3. Untuk kembali ke launcher lama, pilih lagi di pengaturan yang sama.

## Catatan
- Beberapa HP (Xiaomi, Oppo, Vivo, Samsung) mematikan service di latar belakang. Kunci launcher di Recent Apps dan matikan optimasi baterainya supaya island tetap muncul di aplikasi lain.
- Belum ada: pilihan bahasa, widget cuaca, icon pack pihak ketiga.
- Kode belum pernah dikompilasi di sini. Kalau build gagal, kirim pesan errornya.
