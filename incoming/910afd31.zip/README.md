# rzkylauncher 1.7

Pembaruan dari source v1.6: dashboard pengaturan launcher berbentuk panel penuh dengan kategori Personalisasi, Kontrol & Navigasi, dan Pengaturan Perangkat.

## Pengaturan
- Pengaturan internal rzkylauncher: Home Screen, wallpaper, widget Android, App Library, Dynamic Glass (Android 13+), warna aksen, Control Center, Dynamic Island, Lock Screen preview, navigasi, dan izin.
- Pintasan Settings Android: Settings utama, launcher default, layar, suara, Wi-Fi, Bluetooth, notifikasi, dan info aplikasi.
- Pintasan sistem membuka halaman resmi Android/OEM. Launcher biasa tidak dapat menyisipkan halaman internal ke aplikasi Settings bawaan atau mengambil alih tombol navigasi sistem.

## Build
Jalankan `./gradlew assembleDebug`. Toolchain project dipertahankan: Gradle 8.7, AGP 8.5.2, Kotlin 1.9.24, JDK 17, compileSdk/targetSdk 34.
