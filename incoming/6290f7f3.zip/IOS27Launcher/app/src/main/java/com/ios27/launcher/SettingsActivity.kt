package com.ios27.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

/** Pengaturan bergaya iOS: daftar berkelompok berbahan kaca di atas wallpaper, dengan sub-halaman. */
class SettingsActivity : Activity() {

    private lateinit var host: FrameLayout
    private val stack = ArrayList<String>()
    private var top = 0
    private var bottom = 0

    private val white = Color.WHITE
    private val dim = Color.parseColor("#AEAEB2")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        host = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#0B0B10")) }
        setContentView(host)
        val first = intent.getStringExtra("page") ?: "main"
        ViewCompat.setOnApplyWindowInsetsListener(host) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            top = bars.top; bottom = bars.bottom
            show(stack.lastOrNull() ?: first, push = false)
            insets
        }
        show(first, push = false)
        val b = windowManager.currentWindowMetrics.bounds
        Thread {
            if (Backdrop.ensure(this, b.width(), b.height())) runOnUiThread { show(stack.last(), push = false) }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        // status izin berubah setelah kembali dari layar pengaturan sistem
        if (stack.isNotEmpty() && stack.last() == "perms") show("perms", push = false)
    }

    @Deprecated("Back lokal")
    override fun onBackPressed() {
        if (stack.size > 1) { stack.removeAt(stack.size - 1); show(stack.last(), push = false) }
        else finish()
    }

    private fun show(page: String, push: Boolean = true) {
        if (push) stack.add(page) else if (stack.isEmpty() || stack.last() != page) { stack.clear(); stack.add(page) }
        host.removeAllViews()
        val sharp = Backdrop.sharp
        if (sharp != null && Prefs.int(this, Prefs.WALL_MODE) != 2) {
            host.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(sharp)
            }, FrameLayout.LayoutParams(MATCH, MATCH))
            host.addView(View(this).apply { setBackgroundColor(Color.parseColor("#99000000")) },
                FrameLayout.LayoutParams(MATCH, MATCH))
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), top + dp(8), dp(16), bottom + dp(32))
        }
        header(col, page)
        when (page) {
            "main" -> main(col)
            "general" -> general(col)
            "island" -> island(col)
            "panels" -> panels(col)
            "perms" -> perms(col)
            "wallpaper" -> wallpaper(col)
            "grid" -> grid(col)
            "glass" -> glassPage(col)
            "icons" -> icons(col)
        }
        host.addView(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        }, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    // ------------------------------------------------------------ pieces

    private fun title(page: String) = when (page) {
        "main" -> "Settings"; "general" -> "General"; "island" -> "Dynamic Island"; "panels" -> "Panel & Notifikasi"; "perms" -> "Izin"
        "wallpaper" -> "Wallpaper"; "grid" -> "Screen Grid"; "glass" -> "Liquid Glass"; else -> "Icons"
    }

    private fun header(col: LinearLayout, page: String) {
        if (page == "main") {
            col.addView(TextView(this).apply {
                text = title(page); textSize = 34f; setTextColor(white)
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(24); bottomMargin = dp(16) })
            return
        }
        val bar = FrameLayout(this)
        bar.addView(GlyphView(this, G.CHEVRON, white, 0.5f).apply {
            rotation = 180f
            background = glass(22, true)
            setOnClickListener { onBackPressed() }
        }, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.START))
        bar.addView(TextView(this).apply {
            text = title(page); textSize = 17f; setTextColor(white); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }, FrameLayout.LayoutParams(MATCH, dp(44)))
        col.addView(bar, LinearLayout.LayoutParams(MATCH, dp(44)).apply { bottomMargin = dp(16) })
    }

    private fun card(col: LinearLayout, label: String? = null): LinearLayout {
        if (label != null) col.addView(TextView(this).apply {
            text = label.uppercase(); textSize = 12f; setTextColor(dim)
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14); bottomMargin = dp(6); marginStart = dp(12) })
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(24)
            setPadding(dp(16), dp(2), dp(16), dp(2))
        }
        col.addView(c, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
        return c
    }

    /** Menambah baris ke kartu, dengan garis pemisah tipis di antara baris. */
    private fun addRow(card: LinearLayout, row: View) {
        if (card.childCount > 0) card.addView(View(this).apply { setBackgroundColor(Color.parseColor("#26FFFFFF")) },
            LinearLayout.LayoutParams(MATCH, 1))
        card.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun note(col: LinearLayout, text: String) {
        col.addView(TextView(this).apply { this.text = text; textSize = 12f; setTextColor(dim) },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { marginStart = dp(12); marginEnd = dp(12); bottomMargin = dp(6) })
    }

    private fun tile(glyph: G, color: Int): View = FrameLayout(this).apply {
        background = GradientDrawable().apply { cornerRadius = dp(8).toFloat(); setColor(color) }
        addView(GlyphView(this@SettingsActivity, glyph, Color.WHITE, 0.62f), FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun nav(card: LinearLayout, glyph: G, label: String, value: String?, color: Int, page: String) {
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(11), 0, dp(11))
            setOnClickListener { show(page) }
        }
        row.addView(tile(glyph, color), LinearLayout.LayoutParams(dp(30), dp(30)))
        row.addView(TextView(this).apply { text = label; textSize = 16f; setTextColor(white) },
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(14) })
        if (value != null) row.addView(TextView(this).apply { text = value; textSize = 14f; setTextColor(dim) })
        row.addView(GlyphView(this, G.CHEVRON, dim, 0.7f), LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginStart = dp(6) })
        addRow(card, row)
    }

    private fun toggle(card: LinearLayout, label: String, key: String, onChange: (() -> Unit)? = null) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(10)) }
        row.addView(TextView(this).apply { text = label; textSize = 15f; setTextColor(white) },
            LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginEnd = dp(12) })
        row.addView(IosSwitch(this).apply {
            set(Prefs.bool(this@SettingsActivity, key))
            this.onChange = { on -> Prefs.setBool(this@SettingsActivity, key, on); onChange?.invoke() }
        })
        addRow(card, row)
    }

    private fun slider(card: LinearLayout, label: String, key: String, min: Int, max: Int, unit: String,
                       onChange: (() -> Unit)? = null) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(6)) }
        val head = LinearLayout(this)
        val value = TextView(this).apply {
            textSize = 14f; setTextColor(dim)
            text = "${Prefs.int(this@SettingsActivity, key)}$unit"
        }
        head.addView(TextView(this).apply { text = label; textSize = 15f; setTextColor(white) },
            LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(value)
        box.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
        box.addView(SeekBar(this).apply {
            this.max = max - min
            progress = Prefs.int(this@SettingsActivity, key) - min
            progressTintList = ColorStateList.valueOf(Prefs.accent(this@SettingsActivity))
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    Prefs.setInt(this@SettingsActivity, key, p + min)
                    value.text = "${p + min}$unit"
                    onChange?.invoke()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }, LinearLayout.LayoutParams(MATCH, WRAP))
        addRow(card, box)
    }

    /** Pilihan segmen, misal Rows 4..8 atau Top/Center/Bottom. */
    private fun segmented(card: LinearLayout, label: String, key: String, options: List<String>, base: Int,
                          onChange: (() -> Unit)? = null) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(10)) }
        box.addView(TextView(this).apply { text = label; textSize = 13f; setTextColor(dim) },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(6) })
        val row = LinearLayout(this).apply {
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(Color.parseColor("#40000000")) }
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        val cur = Prefs.int(this, key) - base
        options.forEachIndexed { i, name ->
            row.addView(TextView(this).apply {
                text = name; textSize = 14f; gravity = Gravity.CENTER
                setTextColor(if (i == cur) white else dim)
                if (i == cur) background = GradientDrawable().apply {
                    cornerRadius = dp(10).toFloat(); setColor(Color.parseColor("#66FFFFFF"))
                }
                setOnClickListener {
                    Prefs.setInt(this@SettingsActivity, key, i + base)
                    onChange?.invoke()
                    show(stack.last(), push = false)
                }
            }, LinearLayout.LayoutParams(0, dp(34), 1f))
        }
        box.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        addRow(card, box)
    }

    private fun action(card: LinearLayout, label: String, run: () -> Unit) {
        addRow(card, TextView(this).apply {
            text = label; textSize = 15f; setTextColor(Prefs.accent(this@SettingsActivity))
            setPadding(0, dp(12), 0, dp(12)); setOnClickListener { run() }
        })
    }

    private fun overlayPermission() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun notificationAccess() {
        startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
    }

    // ------------------------------------------------------------- pages

    private fun main(col: LinearLayout) {
        val hero = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = glass(26, true)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        hero.addView(TextView(this).apply {
            text = "27"; textSize = 24f; setTextColor(white); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#BF5AF2"), Color.parseColor("#0A84FF"))).apply { cornerRadius = dp(15).toFloat() }
        }, LinearLayout.LayoutParams(dp(58), dp(58)))
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        t.addView(TextView(this).apply {
            text = "iOS 27 Launcher"; textSize = 19f; setTextColor(white)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        })
        t.addView(TextView(this).apply { text = "Liquid Glass untuk Android"; textSize = 13f; setTextColor(dim) })
        hero.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(14) })
        col.addView(hero, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) })

        val ok = Settings.canDrawOverlays(this)
        val p = card(col)
        nav(p, G.INFO, "Izin", if (ok) "Lengkap" else "Perlu diatur", Color.parseColor("#FF9F0A"), "perms")
        val a = card(col)
        nav(a, G.GEAR, "General", null, Color.parseColor("#8E8E93"), "general")
        nav(a, G.ISLAND, "Dynamic Island", null, Color.parseColor("#BF5AF2"), "island")
        nav(a, G.BELL, "Panel & Notifikasi", null, Color.parseColor("#FF453A"), "panels")
        val b = card(col)
        nav(b, G.IMAGE, "Wallpaper", null, Color.parseColor("#0A84FF"), "wallpaper")
        nav(b, G.DROP, "Liquid Glass", null, Color.parseColor("#64D2FF"), "glass")
        nav(b, G.GRID, "Screen Grid", "${Prefs.int(this, Prefs.COLS)}×${Prefs.int(this, Prefs.ROWS)}", Color.parseColor("#5E5CE6"), "grid")
        nav(b, G.SLIDERS, "Icons", null, Color.parseColor("#30D158"), "icons")
        val c = card(col)
        action(c, "Pilih launcher default") { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
    }

    private fun general(col: LinearLayout) {
        val c = card(col)
        toggle(c, "Sembunyikan tombol navigasi", Prefs.HIDE_NAV)
        toggle(c, "Blur layar App Library (bisa berat)", Prefs.BLUR)
        toggle(c, "Ukuran teks sendiri", Prefs.CUSTOM_TEXT) { show("general", push = false) }
        if (Prefs.bool(this, Prefs.CUSTOM_TEXT)) {
            slider(c, "Ukuran nama ikon", Prefs.TEXT_SIZE, 70, 130, "%")
            slider(c, "Jarak nama ikon", Prefs.LABEL_SPACING, 0, 16, " dp")
        }
        val d = card(col, "Gesture")
        toggle(d, "Geser ke bawah untuk cari", Prefs.SWIPE_SEARCH)
        toggle(d, "Getaran halus", Prefs.HAPTIC)
        toggle(d, "App Library berupa daftar A–Z", Prefs.LIB_LIST)
        val e = card(col)
        action(e, "Reset semua pengaturan") {
            AlertDialog.Builder(this).setMessage("Kembalikan semua pengaturan ke bawaan?")
                .setPositiveButton("Reset") { _, _ ->
                    Prefs.resetAll(this); IslandOverlayService.refresh(this); show("main", push = false)
                }
                .setNegativeButton("Batal", null).show()
        }
    }

    private fun island(col: LinearLayout) {
        val c = card(col)
        toggle(c, "Tampil di atas semua aplikasi", Prefs.OVERLAY) {
            if (Prefs.bool(this, Prefs.OVERLAY) && !Settings.canDrawOverlays(this)) overlayPermission()
            else IslandOverlayService.refresh(this)
        }
        toggle(c, "Posisi otomatis di lubang kamera", Prefs.ISLAND_AUTO) { IslandOverlayService.refresh(this) }
        toggle(c, "Titik kamera (ketuk untuk buka island)", Prefs.ISLAND_IDLE) { IslandOverlayService.refresh(this) }
        slider(c, "Posisi vertikal (kalau tidak otomatis)", Prefs.ISLAND_Y, 0, 60, " dp") { IslandOverlayService.refresh(this) }
        slider(c, "Ukuran", Prefs.ISLAND_SCALE, 70, 130, "%") { IslandOverlayService.refresh(this) }
        val live = card(col, "Live activity")
        toggle(live, "Lagu yang diputar (Spotify, dll)", Prefs.ISLAND_MUSIC) { IslandOverlayService.refresh(this) }
        toggle(live, "Hotspot menyala", Prefs.ISLAND_HOTSPOT) { IslandOverlayService.refresh(this) }
        toggle(live, "Notifikasi baru", Prefs.ISLAND_NOTIF) { IslandOverlayService.refresh(this) }
        val d = card(col)
        nav(d, G.INFO, "Izin", null, Color.parseColor("#FF9F0A"), "perms")
        note(col, "Dynamic Island berjalan sebagai layanan latar depan, jadi di bilah notifikasi ada satu notifikasi kecil \"Dynamic Island aktif\". " +
            "Itu yang menjaga island tetap hidup saat kamu membuka Spotify atau aplikasi lain. Kalau HP kamu mematikannya, kunci launcher di Recent Apps dan matikan optimasi baterainya.")
    }

    private fun panels(col: LinearLayout) {
        val c = card(col)
        toggle(c, "Ganti panel notifikasi & quick settings Android", Prefs.SHADE_REPLACE) {
            IslandOverlayService.refresh(this); ShadeAccessibilityService.instance?.rebuild()
        }
        note(col, "Geser ke bawah dari tepi atas layar: sisi kanan membuka Control Center, sisi kiri dan tengah membuka Notification Center. " +
            "Isinya notifikasi asli HP dan toggle asli. Panel bawaan Android tidak bisa diubah tampilannya oleh aplikasi biasa, jadi launcher menggantinya dengan panel iOS yang tampil di atas semua aplikasi.")
        val lk = card(col, "Lockscreen iOS")
        toggle(lk, "Tampilkan lockscreen iPhone saat layar menyala", Prefs.LOCK_ENABLED) { IslandOverlayService.refresh(this) }
        toggle(lk, "Jam 24 jam", Prefs.LOCK_24H)
        action(lk, if (LockPass.isSet(this)) "Ubah kode sandi lockscreen" else "Atur kode sandi lockscreen (keypad iOS)") { askPasscode() }
        if (LockPass.isSet(this)) action(lk, "Hapus kode sandi lockscreen") {
            LockPass.clear(this); show("panels", push = false)
        }
        action(lk, "Coba lockscreen sekarang") { startActivity(Intent(this, LockScreenActivity::class.java)) }
        note(col, "Android tidak mengizinkan aplikasi mengganti lockscreen atau layar PIN sistem. Lockscreen iOS ini tampil di atas lockscreen HP. " +
            "Keypad kode sandi iOS memakai kode sandi launcher (diatur di sini, terpisah dari PIN HP). " +
            "Setelah lolos, kunci asli HP (PIN / pola / sidik jari) tetap muncul kalau HP memakainya.")
        val d = card(col)
        nav(d, G.INFO, "Izin (wajib supaya panel iOS jalan)", null, Color.parseColor("#FF9F0A"), "perms")
        val e = card(col, "Coba sekarang")
        action(e, "Buka Control Center") {
            if (Settings.canDrawOverlays(this)) { finish(); ShadeTrigger.open(this, true) }
            else Toast.makeText(this, "Izinkan tampil di atas aplikasi lain dulu", Toast.LENGTH_SHORT).show()
        }
        action(e, "Buka Notification Center") {
            if (Settings.canDrawOverlays(this)) { finish(); ShadeTrigger.open(this, false) }
            else Toast.makeText(this, "Izinkan tampil di atas aplikasi lain dulu", Toast.LENGTH_SHORT).show()
        }
    }

    private fun statusRow(card: LinearLayout, label: String, ok: Boolean, run: () -> Unit) {
        action(card, (if (ok) "✓  " else "○  ") + label + (if (ok) "  —  aktif" else "  —  ketuk untuk mengatur"), run)
    }

    private fun appInfo() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private val adbCmd get() = "adb shell appops set $packageName ACCESS_RESTRICTED_SETTINGS allow"

    private fun runtimePerms(): Boolean =
        checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) == android.content.pm.PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED

    private fun perms(col: LinearLayout) {
        val c = card(col, "Wajib (Control Center overlay)")
        statusRow(c, "Tampil di atas aplikasi lain", Settings.canDrawOverlays(this)) { overlayPermission() }

        val t = card(col, "Supaya tombol beneran jalan")
        statusRow(t, "Ubah pengaturan sistem (kecerahan, rotasi)", Settings.System.canWrite(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
        statusRow(t, "Bluetooth + Kamera (senter)", runtimePerms()) {
            requestPermissions(arrayOf(android.Manifest.permission.BLUETOOTH_CONNECT, android.Manifest.permission.CAMERA), 7)
        }
        statusRow(t, "Akses Jangan Ganggu", (getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager).isNotificationPolicyAccessGranted) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        }
        val sh = card(col, "Wi-Fi / Data / Bluetooth / Pesawat langsung (Shizuku)")
        when {
            Shell.shizukuReady() -> action(sh, "✓  Shizuku aktif — toggle jaringan langsung jalan") {}
            Shell.shizukuNeedsPermission() -> action(sh, "○  Shizuku jalan — ketuk untuk beri izin") { Shell.requestShizuku() }
            else -> action(sh, "○  Shizuku belum jalan — ketuk untuk membuka / mengunduh") {
                if (!startSafe(packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api") ?: Intent(),
                        Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")))) {}
            }
        }
        note(col, "Android 10+ melarang aplikasi biasa mematikan Wi-Fi, data, Bluetooth, dan mode pesawat. Dengan Shizuku (atau root) " +
            "tombolnya langsung jalan. Tanpa itu, tombol membuka panel sistem dan statusnya tetap tampil.")

        val o = card(col, "Opsional (kena \"Setelan Terbatas\")")
        statusRow(o, "Akses notifikasi (lagu & notifikasi)", MediaWatcher.isAccessGranted(this)) { notificationAccess() }
        statusRow(o, "Aksesibilitas \"iOS 27 Panel\" (ganti panel bawaan HP)", ShadeAccessibilityService.isEnabled(this)) {
            try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (_: Exception) { appInfo() }
        }

        val e = card(col, "Muncul \"Setelan Terbatas\" / izin abu-abu?")
        action(e, "Buka kunci otomatis lewat Shizuku") {
            if (!Shell.shizukuReady()) {
                Toast.makeText(this, "Shizuku belum aktif / belum diberi izin", Toast.LENGTH_LONG).show()
            } else Thread {
                val ok2 = Sys.allowRestrictedSettings(this)
                runOnUiThread {
                    Toast.makeText(this, if (ok2) "Terbuka! Sekarang nyalakan izinnya" else "Gagal, pakai cara ADB", Toast.LENGTH_LONG).show()
                    show("perms", push = false)
                }
            }.start()
        }
        action(e, "Salin perintah ADB") {
            (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                .setPrimaryClip(android.content.ClipData.newPlainText("adb", adbCmd))
            Toast.makeText(this, "Disalin", Toast.LENGTH_SHORT).show()
        }
        action(e, "Buka Info Aplikasi → ⋮ → Izinkan setelan terbatas") { appInfo() }
        note(col, "Kunci ini dipasang Android 13+ untuk semua aplikasi yang di-install dari luar Play Store. Aplikasi tidak bisa melepasnya sendiri " +
            "(sengaja, supaya malware tidak bisa). Ada 4 cara membukanya, dari yang paling gampang:\n\n" +
            "1. Info Aplikasi: ketuk tombol di atas → titik tiga ⋮ kanan atas → \"Izinkan setelan terbatas\". " +
            "Titik tiga baru muncul setelah sekali kena dialog \"Setelan Terbatas\".\n\n" +
            "2. Shizuku: nyalakan Shizuku, beri izin ke aplikasi ini, lalu ketuk \"Buka kunci otomatis\".\n\n" +
            "3. ADB dari PC (USB debugging nyala):\n$adbCmd\n\n" +
            "4. Install ulang lewat installer berbasis sesi (mis. SAI / Shizuku installer / Package Installer bawaan lewat \"Install\" dari file manager yang mendukung) " +
            "— aplikasi yang dipasang dengan cara ini tidak dikunci sejak awal.\n\n" +
            "Control Center overlay TIDAK butuh izin yang terkunci. Hanya lagu, notifikasi asli, dan penggantian panel bawaan yang butuh.")
    }

    private fun wallpaper(col: LinearLayout) {
        val c = card(col)
        segmented(c, "Sumber wallpaper", Prefs.WALL_MODE, listOf("Bawaan", "Foto", "Sistem"), 0) { applyWallpaperChange() }
        val mode = Prefs.int(this, Prefs.WALL_MODE)
        if (mode == 0) {
            val box = LinearLayout(this).apply { setPadding(0, dp(10), 0, dp(12)) }
            val cur = Prefs.int(this, Prefs.WALL_STYLE)
            Backdrop.STYLE_NAMES.forEachIndexed { i, name ->
                val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
                item.addView(ImageView(this).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setImageBitmap(Backdrop.preview(i, 90, 180))
                    clipToOutline = true
                    background = GradientDrawable().apply {
                        cornerRadius = dp(12).toFloat()
                        setStroke(if (i == cur) dp(3) else 0, Color.WHITE)
                        setColor(Color.BLACK)
                    }
                    setOnClickListener {
                        Prefs.setInt(this@SettingsActivity, Prefs.WALL_STYLE, i)
                        applyWallpaperChange()
                    }
                }, LinearLayout.LayoutParams(dp(66), dp(132)))
                item.addView(TextView(this).apply { text = name; textSize = 12f; setTextColor(if (i == cur) white else dim) },
                    LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(4) })
                box.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
            }
            addRow(c, box)
        } else if (mode == 1) {
            action(c, "Pilih foto dari galeri…") {
                startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), PICK_PHOTO
                )
            }
        }
        note(col, when (mode) {
            0 -> "Wallpaper bawaan dipakai juga sebagai bahan blur untuk panel Liquid Glass."
            1 -> "Foto yang dipilih disalin ke launcher dan dipakai sebagai wallpaper, sekaligus bahan blur untuk panel kaca."
            else -> "Memakai wallpaper sistem. Panel kaca jadi kaca buram biasa karena Android tidak mengizinkan launcher membaca wallpaper sistem."
        })
    }

    private fun applyWallpaperChange() {
        val b = windowManager.currentWindowMetrics.bounds
        Thread {
            Backdrop.ensure(this, b.width(), b.height())
            runOnUiThread { GlassRegistry.refresh(); show(stack.last(), push = false) }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == PICK_PHOTO && resultCode == RESULT_OK && uri != null) {
            val b = windowManager.currentWindowMetrics.bounds
            Thread {
                val ok = Backdrop.savePhoto(this, uri, b.width(), b.height())
                runOnUiThread {
                    if (ok) {
                        Prefs.setInt(this, Prefs.WALL_STAMP, Prefs.int(this, Prefs.WALL_STAMP) + 1)
                        applyWallpaperChange()
                    } else Toast.makeText(this, "Foto tidak bisa dibaca", Toast.LENGTH_SHORT).show()
                }
            }.start()
        }
    }

    private fun grid(col: LinearLayout) {
        val c = card(col, "Layout")
        segmented(c, "Columns", Prefs.COLS, listOf("3", "4", "5", "6"), 3)
        segmented(c, "Rows", Prefs.ROWS, listOf("4", "5", "6", "7", "8"), 4)
        val m = card(col, "Margins")
        slider(m, "Sides", Prefs.M_SIDES, 0, 48, " dp")
        slider(m, "Top", Prefs.M_TOP, 0, 80, " dp")
        slider(m, "Bottom", Prefs.M_BOTTOM, 0, 80, " dp")
        val v = card(col)
        segmented(v, "Vertical position", Prefs.V_POS, listOf("Top", "Center", "Bottom"), 0)
    }

    private fun glassPage(col: LinearLayout) {
        val preview = LinearLayout(this).apply {
            gravity = Gravity.CENTER; background = glass(30, true)
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        preview.addView(TextView(this).apply {
            text = "Liquid Glass"; textSize = 18f; setTextColor(white); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, dp(60), 1f))
        col.addView(preview, LinearLayout.LayoutParams(MATCH, dp(110)).apply { bottomMargin = dp(12) })
        val c = card(col, "Dock, widget, dan menu")
        slider(c, "Ketebalan kaca", Prefs.GLASS_BRIGHT, 0, 100, "%") { GlassRegistry.refresh() }
        slider(c, "Refraksi tepi", Prefs.REFRACT, 0, 100, "%") { GlassRegistry.refresh() }
        toggle(c, "Garis tepi bercahaya", Prefs.EDGE) { GlassRegistry.refresh() }
        note(col, "Refraksi membelokkan isi wallpaper di tepi panel seperti lensa kaca. Turunkan kalau terasa berat.")
    }

    private fun icons(col: LinearLayout) {
        val c = card(col)
        slider(c, "Ukuran ikon", Prefs.ICON_SIZE, 60, 110, "%")
        slider(c, "Ukuran ikon dock", Prefs.DOCK_ICON_SIZE, 60, 110, "%")
        slider(c, "Kebulatan sudut", Prefs.ICON_ROUND, 0, 100, "%")
        toggle(c, "Ikon & nama ala iOS (Play Store jadi App Store, Chrome jadi Safari, dll)", Prefs.IOS_ICONS)
        toggle(c, "Ubin kaca di belakang ikon", Prefs.ICON_GLASS)
        toggle(c, "Nama aplikasi", Prefs.SHOW_NAMES)
        note(col, "0% hampir persegi, 70% mirip iOS, 100% lingkaran.")
    }

    /** Dialog untuk mengatur kode sandi lockscreen launcher (4–6 angka). */
    private fun askPasscode() {
        val input = android.widget.EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "4 sampai 6 angka"
            filters = arrayOf(android.text.InputFilter.LengthFilter(6))
            setPadding(dp(24), dp(16), dp(24), dp(16))
        }
        AlertDialog.Builder(this)
            .setTitle("Kode sandi lockscreen")
            .setMessage("Dipakai oleh keypad iOS di lockscreen launcher. Ini bukan PIN HP kamu.")
            .setView(input)
            .setPositiveButton("Simpan") { _, _ ->
                val pin = input.text.toString()
                if (pin.length in 4..6) {
                    LockPass.set(this, pin)
                    Toast.makeText(this, "Kode sandi disimpan", Toast.LENGTH_SHORT).show()
                    show("panels", push = false)
                } else Toast.makeText(this, "Harus 4 sampai 6 angka", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    companion object {
        private const val PICK_PHOTO = 71
    }
}

/** Membuka panel iOS dari Pengaturan untuk mencoba (lewat layanan overlay). */
object ShadeTrigger {
    fun open(ctx: android.content.Context, control: Boolean) {
        ctx.startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        IslandOverlayService.openPanel(ctx, control)
    }
}
