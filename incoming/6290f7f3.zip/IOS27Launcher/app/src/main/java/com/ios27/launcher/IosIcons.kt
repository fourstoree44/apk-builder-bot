package com.ios27.launcher

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

/** Aplikasi bawaan Android/Google yang punya padanan di iPhone. Ikon dan namanya diganti jadi versi iOS. */
enum class IosKind(val title: String) {
    APPSTORE("App Store"), SAFARI("Safari"), PHONE("Telepon"), MESSAGES("Pesan"), CAMERA("Kamera"),
    PHOTOS("Foto"), SETTINGS("Pengaturan"), CLOCK("Jam"), CALCULATOR("Kalkulator"), CALENDAR("Kalender"),
    MAPS("Peta"), CONTACTS("Kontak"), FILES("File"), WEATHER("Cuaca"), MAIL("Mail"), NOTES("Catatan"),
    MUSIC("Musik"), COMPASS("Kompas"), VOICE("Memo Suara")
}

object IosIcons {

    private val byPkg: Map<String, IosKind> = mapOf(
        "com.android.vending" to IosKind.APPSTORE,
        "com.android.chrome" to IosKind.SAFARI,
        "com.android.browser" to IosKind.SAFARI,
        "com.google.android.dialer" to IosKind.PHONE,
        "com.android.dialer" to IosKind.PHONE,
        "com.samsung.android.dialer" to IosKind.PHONE,
        "com.google.android.apps.messaging" to IosKind.MESSAGES,
        "com.android.mms" to IosKind.MESSAGES,
        "com.samsung.android.messaging" to IosKind.MESSAGES,
        "com.android.camera" to IosKind.CAMERA,
        "com.android.camera2" to IosKind.CAMERA,
        "com.mediatek.camera" to IosKind.CAMERA,
        "com.google.android.apps.photos" to IosKind.PHOTOS,
        "com.android.gallery3d" to IosKind.PHOTOS,
        "com.google.android.gallery3d" to IosKind.PHOTOS,
        "com.android.settings" to IosKind.SETTINGS,
        "com.google.android.deskclock" to IosKind.CLOCK,
        "com.android.deskclock" to IosKind.CLOCK,
        "com.google.android.calculator" to IosKind.CALCULATOR,
        "com.android.calculator2" to IosKind.CALCULATOR,
        "com.google.android.calendar" to IosKind.CALENDAR,
        "com.android.calendar" to IosKind.CALENDAR,
        "com.google.android.apps.maps" to IosKind.MAPS,
        "com.google.android.contacts" to IosKind.CONTACTS,
        "com.android.contacts" to IosKind.CONTACTS,
        "com.google.android.apps.nbu.files" to IosKind.FILES,
        "com.google.android.documentsui" to IosKind.FILES,
        "com.android.documentsui" to IosKind.FILES,
        "com.google.android.gm" to IosKind.MAIL,
        "com.google.android.keep" to IosKind.NOTES,
        "com.google.android.apps.youtube.music" to IosKind.MUSIC
    )

    // HP merek lain (Tecno/Infinix/Xiaomi/dll) memakai nama paket berbeda untuk aplikasi bawaannya, jadi dicocokkan juga lewat nama
    private val byLabel: Map<String, IosKind> = mapOf(
        "play store" to IosKind.APPSTORE, "google play store" to IosKind.APPSTORE,
        "chrome" to IosKind.SAFARI, "browser" to IosKind.SAFARI, "peramban" to IosKind.SAFARI,
        "phone" to IosKind.PHONE, "telepon" to IosKind.PHONE, "dialer" to IosKind.PHONE,
        "messages" to IosKind.MESSAGES, "message" to IosKind.MESSAGES, "pesan" to IosKind.MESSAGES, "sms" to IosKind.MESSAGES,
        "camera" to IosKind.CAMERA, "kamera" to IosKind.CAMERA,
        "photos" to IosKind.PHOTOS, "foto" to IosKind.PHOTOS, "gallery" to IosKind.PHOTOS, "galeri" to IosKind.PHOTOS,
        "settings" to IosKind.SETTINGS, "setelan" to IosKind.SETTINGS, "pengaturan" to IosKind.SETTINGS,
        "clock" to IosKind.CLOCK, "jam" to IosKind.CLOCK,
        "calculator" to IosKind.CALCULATOR, "kalkulator" to IosKind.CALCULATOR,
        "calendar" to IosKind.CALENDAR, "kalender" to IosKind.CALENDAR,
        "maps" to IosKind.MAPS, "peta" to IosKind.MAPS,
        "contacts" to IosKind.CONTACTS, "kontak" to IosKind.CONTACTS,
        "files" to IosKind.FILES, "file manager" to IosKind.FILES, "berkas" to IosKind.FILES, "file saya" to IosKind.FILES,
        "weather" to IosKind.WEATHER, "cuaca" to IosKind.WEATHER,
        "gmail" to IosKind.MAIL, "email" to IosKind.MAIL,
        "notes" to IosKind.NOTES, "catatan" to IosKind.NOTES,
        "yt music" to IosKind.MUSIC, "youtube music" to IosKind.MUSIC, "music" to IosKind.MUSIC, "musik" to IosKind.MUSIC,
        "compass" to IosKind.COMPASS, "kompas" to IosKind.COMPASS,
        "voice recorder" to IosKind.VOICE, "sound recorder" to IosKind.VOICE, "recorder" to IosKind.VOICE,
        "perekam suara" to IosKind.VOICE, "perekam" to IosKind.VOICE
    )

    fun match(pkg: String, label: String): IosKind? =
        byPkg[pkg] ?: byLabel[label.trim().lowercase()]

    // ------------------------------------------------------------ gambar

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rf = RectF()
    private val white = Color.WHITE

    private fun col(hex: String) = Color.parseColor(hex)

    private fun bg(c: Canvas, s: Float, top: String, bottom: String) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, 0f, s, col(top), col(bottom), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, s, s, p)
        p.shader = null
    }

    private fun solid(c: Canvas, s: Float, color: String) {
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = col(color)
        c.drawRect(0f, 0f, s, s, p)
    }

    private fun fillRound(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, color: Int) {
        p.style = Paint.Style.FILL; p.shader = null; p.color = color
        rf.set(l, t, r, b)
        c.drawRoundRect(rf, rad, rad, p)
    }

    private fun circle(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        p.style = Paint.Style.FILL; p.shader = null; p.color = color
        c.drawCircle(x, y, r, p)
    }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, w: Float, color: Int) {
        p.style = Paint.Style.STROKE; p.shader = null; p.color = color
        p.strokeWidth = w; p.strokeCap = Paint.Cap.ROUND
        c.drawLine(x1, y1, x2, y2, p)
        p.style = Paint.Style.FILL
    }

    private fun needle(c: Canvas, s: Float, len: Float, wid: Float, top: Int, bottom: Int, rot: Float) {
        c.save()
        c.translate(s * 0.5f, s * 0.5f)
        c.rotate(rot)
        p.style = Paint.Style.FILL; p.shader = null
        path.reset(); path.moveTo(0f, -len); path.lineTo(wid, 0f); path.lineTo(-wid, 0f); path.close()
        p.color = top; c.drawPath(path, p)
        path.reset(); path.moveTo(0f, len); path.lineTo(wid, 0f); path.lineTo(-wid, 0f); path.close()
        p.color = bottom; c.drawPath(path, p)
        c.restore()
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, face: Typeface) {
        p.style = Paint.Style.FILL; p.shader = null
        p.color = color; p.textSize = size; p.textAlign = Paint.Align.CENTER; p.typeface = face
        c.drawText(s, x, y, p)
    }

    /** Menggambar ikon penuh (latar + gambar) pada kotak s x s. Pemanggil yang memotongnya jadi squircle. */
    @Synchronized
    fun draw(c: Canvas, kind: IosKind, s: Float) {
        when (kind) {
            IosKind.APPSTORE -> {
                bg(c, s, "#2EC5FF", "#1273F6")
                val w = s * 0.075f
                line(c, s * 0.5f, s * 0.24f, s * 0.29f, s * 0.74f, w, white)
                line(c, s * 0.5f, s * 0.24f, s * 0.71f, s * 0.74f, w, white)
                line(c, s * 0.34f, s * 0.60f, s * 0.66f, s * 0.60f, w, white)
                line(c, s * 0.22f, s * 0.74f, s * 0.38f, s * 0.74f, w, white)
            }
            IosKind.SAFARI -> {
                bg(c, s, "#4FC3FF", "#0A6CF5")
                p.style = Paint.Style.STROKE; p.shader = null; p.color = white
                p.strokeWidth = s * 0.03f
                c.drawCircle(s * 0.5f, s * 0.5f, s * 0.37f, p)
                for (i in 0 until 24) {
                    val a = Math.toRadians(i * 15.0)
                    val r1 = s * if (i % 6 == 0) 0.30f else 0.33f
                    val r2 = s * 0.355f
                    line(c, s * 0.5f + (cos(a) * r1).toFloat(), s * 0.5f + (sin(a) * r1).toFloat(),
                        s * 0.5f + (cos(a) * r2).toFloat(), s * 0.5f + (sin(a) * r2).toFloat(),
                        s * 0.012f, white)
                }
                needle(c, s, s * 0.27f, s * 0.065f, col("#FF3B30"), white, 45f)
            }
            IosKind.PHONE -> {
                bg(c, s, "#67E67B", "#1FB540")
                Glyphs.draw(c, G.PHONE, s * 0.5f, s * 0.5f, s * 0.6f, white)
            }
            IosKind.MESSAGES -> {
                bg(c, s, "#67E67B", "#1FB540")
                p.style = Paint.Style.FILL; p.shader = null; p.color = white
                rf.set(s * 0.16f, s * 0.20f, s * 0.84f, s * 0.68f)
                c.drawOval(rf, p)
                path.reset()
                path.moveTo(s * 0.27f, s * 0.60f); path.lineTo(s * 0.17f, s * 0.78f); path.lineTo(s * 0.43f, s * 0.67f)
                path.close()
                c.drawPath(path, p)
            }
            IosKind.CAMERA -> {
                bg(c, s, "#B8B8BE", "#6A6A72")
                Glyphs.draw(c, G.CAMERA, s * 0.5f, s * 0.5f, s * 0.58f, col("#1C1C1E"))
            }
            IosKind.PHOTOS -> {
                bg(c, s, "#FFFFFF", "#EDEDF2")
                val colors = listOf("#FF9F0A", "#FFD60A", "#30D158", "#64D2FF", "#0A84FF", "#BF5AF2", "#FF375F", "#FF453A")
                for (i in colors.indices) {
                    val a = Math.toRadians(i * 45.0)
                    val x = s * 0.5f + (cos(a) * s * 0.15f).toFloat()
                    val y = s * 0.5f + (sin(a) * s * 0.15f).toFloat()
                    circle(c, x, y, s * 0.17f, (col(colors[i]) and 0x00FFFFFF) or (0xB4 shl 24))
                }
            }
            IosKind.SETTINGS -> {
                bg(c, s, "#B4B4BA", "#76767E")
                Glyphs.draw(c, G.GEAR, s * 0.5f, s * 0.5f, s * 0.66f, col("#3A3A3C"))
            }
            IosKind.CLOCK -> {
                solid(c, s, "#000000")
                circle(c, s * 0.5f, s * 0.5f, s * 0.43f, white)
                for (i in 0 until 12) {
                    val a = Math.toRadians(i * 30.0)
                    val r1 = s * 0.35f
                    val r2 = s * 0.40f
                    line(c, s * 0.5f + (cos(a) * r1).toFloat(), s * 0.5f + (sin(a) * r1).toFloat(),
                        s * 0.5f + (cos(a) * r2).toFloat(), s * 0.5f + (sin(a) * r2).toFloat(),
                        s * 0.022f, Color.BLACK)
                }
                val cal = Calendar.getInstance()
                val min = cal.get(Calendar.MINUTE)
                val hr = (cal.get(Calendar.HOUR) % 12) + min / 60f
                val aH = Math.toRadians(hr * 30.0 - 90.0)
                val aM = Math.toRadians(min * 6.0 - 90.0)
                line(c, s * 0.5f, s * 0.5f, s * 0.5f + (cos(aH) * s * 0.20f).toFloat(), s * 0.5f + (sin(aH) * s * 0.20f).toFloat(), s * 0.045f, Color.BLACK)
                line(c, s * 0.5f, s * 0.5f, s * 0.5f + (cos(aM) * s * 0.30f).toFloat(), s * 0.5f + (sin(aM) * s * 0.30f).toFloat(), s * 0.035f, Color.BLACK)
                circle(c, s * 0.5f, s * 0.5f, s * 0.03f, col("#FF9F0A"))
            }
            IosKind.CALCULATOR -> {
                solid(c, s, "#1C1C1E")
                val bw = s * 0.18f
                val gap = s * 0.04f
                val m = s * 0.08f
                for (r in 0 until 4) {
                    for (k in 0 until 4) {
                        val color = when {
                            k == 3 -> "#FF9F0A"
                            r == 0 -> "#A5A5A5"
                            else -> "#3A3A3C"
                        }
                        val l = m + k * (bw + gap)
                        val t = m + r * (bw + gap)
                        fillRound(c, l, t, l + bw, t + bw, bw / 2f, col(color))
                    }
                }
            }
            IosKind.CALENDAR -> {
                solid(c, s, "#FFFFFF")
                val now = Date()
                val day = SimpleDateFormat("d", Locale.US).format(now)
                val dow = SimpleDateFormat("EEEE", Locale("id")).format(now)
                text(c, dow, s * 0.5f, s * 0.29f, s * 0.15f, col("#FF3B30"), Typeface.create("sans-serif-medium", Typeface.NORMAL))
                text(c, day, s * 0.5f, s * 0.80f, s * 0.52f, Color.BLACK, Typeface.create("sans-serif-light", Typeface.NORMAL))
            }
            IosKind.MAPS -> {
                solid(c, s, "#ECECEF")
                fillRound(c, -s * 0.1f, s * 0.58f, s * 0.46f, s * 1.1f, s * 0.08f, col("#A5D87F"))
                fillRound(c, s * 0.62f, -s * 0.1f, s * 1.1f, s * 0.30f, s * 0.08f, col("#BFE3A0"))
                line(c, s * 0.08f, s * 0.92f, s * 0.92f, s * 0.08f, s * 0.14f, white)
                line(c, s * 0.08f, s * 0.92f, s * 0.92f, s * 0.08f, s * 0.04f, col("#FFD60A"))
                circle(c, s * 0.56f, s * 0.44f, s * 0.10f, white)
                circle(c, s * 0.56f, s * 0.44f, s * 0.07f, col("#0A84FF"))
            }
            IosKind.CONTACTS -> {
                bg(c, s, "#E8E8ED", "#C2C2C8")
                circle(c, s * 0.5f, s * 0.36f, s * 0.13f, col("#7C7C84"))
                p.style = Paint.Style.FILL; p.shader = null; p.color = col("#7C7C84")
                rf.set(s * 0.25f, s * 0.54f, s * 0.75f, s * 1.05f)
                c.drawOval(rf, p)
            }
            IosKind.FILES -> {
                bg(c, s, "#4FB5FF", "#1F7AF0")
                fillRound(c, s * 0.20f, s * 0.27f, s * 0.46f, s * 0.40f, s * 0.04f, white)
                fillRound(c, s * 0.20f, s * 0.33f, s * 0.80f, s * 0.73f, s * 0.05f, white)
            }
            IosKind.WEATHER -> {
                bg(c, s, "#3AA0FF", "#1B6FE0")
                circle(c, s * 0.62f, s * 0.36f, s * 0.17f, col("#FFD60A"))
                circle(c, s * 0.36f, s * 0.62f, s * 0.14f, white)
                circle(c, s * 0.51f, s * 0.55f, s * 0.17f, white)
                circle(c, s * 0.67f, s * 0.62f, s * 0.13f, white)
                fillRound(c, s * 0.24f, s * 0.62f, s * 0.80f, s * 0.75f, s * 0.06f, white)
            }
            IosKind.MAIL -> {
                bg(c, s, "#4FB5FF", "#1473F5")
                fillRound(c, s * 0.19f, s * 0.29f, s * 0.81f, s * 0.71f, s * 0.05f, white)
                p.style = Paint.Style.STROKE; p.shader = null; p.color = col("#1473F5")
                p.strokeWidth = s * 0.028f; p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
                path.reset(); path.moveTo(s * 0.23f, s * 0.34f); path.lineTo(s * 0.5f, s * 0.56f); path.lineTo(s * 0.77f, s * 0.34f)
                c.drawPath(path, p)
                p.style = Paint.Style.FILL
            }
            IosKind.NOTES -> {
                solid(c, s, "#FFFFFF")
                p.style = Paint.Style.FILL; p.shader = null; p.color = col("#FFD60A")
                c.drawRect(0f, 0f, s, s * 0.27f, p)
                for (i in 0 until 3) {
                    val y = s * (0.46f + i * 0.14f)
                    line(c, s * 0.16f, y, s * 0.84f, y, s * 0.018f, col("#D1D1D6"))
                }
            }
            IosKind.MUSIC -> {
                bg(c, s, "#FF5E7A", "#FA233B")
                Glyphs.draw(c, G.NOTE, s * 0.5f, s * 0.5f, s * 0.6f, white)
            }
            IosKind.COMPASS -> {
                solid(c, s, "#1C1C1E")
                p.style = Paint.Style.STROKE; p.shader = null; p.color = col("#8E8E93")
                p.strokeWidth = s * 0.03f
                c.drawCircle(s * 0.5f, s * 0.5f, s * 0.36f, p)
                needle(c, s, s * 0.28f, s * 0.07f, col("#FF3B30"), white, 30f)
                circle(c, s * 0.5f, s * 0.5f, s * 0.03f, col("#1C1C1E"))
            }
            IosKind.VOICE -> {
                bg(c, s, "#2C2C2E", "#000000")
                val hs = floatArrayOf(0.10f, 0.22f, 0.36f, 0.18f, 0.44f, 0.26f, 0.38f, 0.14f, 0.24f)
                for (i in hs.indices) {
                    val x = s * (0.16f + i * 0.085f)
                    val barColor = if (i == 4) col("#FF453A") else white
                    line(c, x, s * 0.5f - s * hs[i], x, s * 0.5f + s * hs[i], s * 0.04f, barColor)
                }
            }
        }
    }
}
