package com.ios27.launcher

import android.content.Context
import android.content.pm.PackageManager

/**
 * Menjalankan perintah shell dengan hak "shell" lewat Shizuku, atau lewat root kalau ada.
 * Dipakai untuk toggle yang Android larang untuk aplikasi biasa (Wi-Fi, data, Bluetooth, mode pesawat)
 * dan untuk membuka kunci "Setelan Terbatas".
 *
 * SEMUA fungsi di sini memblokir: panggil dari thread latar, bukan thread UI.
 */
object Shell {

    /** true kalau Shizuku jalan dan aplikasi ini sudah diberi izin. */
    fun shizukuReady(): Boolean = try {
        rikka.shizuku.Shizuku.pingBinder() &&
            rikka.shizuku.Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    /** true kalau Shizuku jalan tapi aplikasi ini belum diberi izin. */
    fun shizukuNeedsPermission(): Boolean = try {
        rikka.shizuku.Shizuku.pingBinder() &&
            rikka.shizuku.Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun shizukuRunning(): Boolean = try { rikka.shizuku.Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun requestShizuku() {
        try { rikka.shizuku.Shizuku.requestPermission(1001) } catch (_: Throwable) {}
    }

    /** Menjalankan [cmd]. true kalau berhasil (exit code 0). */
    fun exec(cmd: String): Boolean = viaShizuku(cmd) ?: viaRoot(cmd) ?: false

    /** true kalau ada jalur berhak (Shizuku atau root). Root hanya dicek kalau Shizuku tidak ada. */
    fun privileged(): Boolean = shizukuReady() || viaRoot("id") == true

    private fun viaShizuku(cmd: String): Boolean? {
        if (!shizukuReady()) return null
        return try {
            // newProcess private di Shizuku API 13+, jadi dipanggil lewat refleksi
            val m = rikka.shizuku.Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            p.waitFor() == 0
        } catch (_: Throwable) { null }
    }

    private fun viaRoot(cmd: String): Boolean? = try {
        Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)).waitFor() == 0
    } catch (_: Throwable) { null }
}

/** Toggle sistem. Kalau jalur berhak tidak ada, hasilnya false dan pemanggil membuka panel sistem. */
object Sys {
    fun wifi(on: Boolean): Boolean = Shell.exec("svc wifi " + if (on) "enable" else "disable")

    fun bluetooth(on: Boolean): Boolean {
        if (Shell.exec("svc bluetooth " + if (on) "enable" else "disable")) return true
        return try {
            @Suppress("DEPRECATION", "MissingPermission")
            val a = android.bluetooth.BluetoothAdapter.getDefaultAdapter() ?: return false
            @Suppress("DEPRECATION", "MissingPermission")
            if (on) a.enable() else a.disable()
        } catch (_: Throwable) { false }
    }

    fun mobileData(on: Boolean): Boolean = Shell.exec("svc data " + if (on) "enable" else "disable")

    fun airplane(on: Boolean): Boolean {
        val v = if (on) "enable" else "disable"
        if (Shell.exec("cmd connectivity airplane-mode $v")) return true
        val n = if (on) 1 else 0
        return Shell.exec("settings put global airplane_mode_on $n && am broadcast -a android.intent.action.AIRPLANE_MODE --ez state ${on}")
    }

    /** Membuka kunci "Setelan Terbatas" untuk aplikasi ini (Akses Notifikasi + Aksesibilitas). */
    fun allowRestrictedSettings(ctx: Context): Boolean =
        Shell.exec("appops set ${ctx.packageName} ACCESS_RESTRICTED_SETTINGS allow")
}
