package com.ios27.launcher

import android.animation.ValueAnimator
import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sin

/**
 * Kode sandi lockscreen launcher. Disimpan sebagai hash SHA-256 (bukan teks asli) di pengaturan launcher.
 * Ini terpisah dari PIN HP: Android tidak mengizinkan aplikasi biasa membaca atau mengganti PIN sistem.
 */
object LockPass {
    private fun hash(pin: String): String =
        MessageDigest.getInstance("SHA-256").digest(("ios27:$pin").toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun isSet(ctx: Context) = Prefs.str(ctx, Prefs.LOCK_PASS).contains(':')
    fun length(ctx: Context) = Prefs.str(ctx, Prefs.LOCK_PASS).substringBefore(':').toIntOrNull() ?: 6
    fun set(ctx: Context, pin: String) = Prefs.setStr(ctx, Prefs.LOCK_PASS, "${pin.length}:${hash(pin)}")
    fun clear(ctx: Context) = Prefs.setStr(ctx, Prefs.LOCK_PASS, "")
    fun check(ctx: Context, pin: String) = Prefs.str(ctx, Prefs.LOCK_PASS).substringAfter(':') == hash(pin)
}

/**
 * Lockscreen bergaya iPhone (iOS 27): tanggal, jam besar, notifikasi, senter + kamera, geser ke atas untuk buka.
 * Kalau kode sandi launcher diatur, geser ke atas menampilkan keypad kode sandi ala iPhone.
 *
 * Android TIDAK mengizinkan aplikasi biasa mengganti lockscreen / layar PIN sistem. Layar ini tampil DI ATAS
 * lockscreen sistem (setShowWhenLocked). Setelah lolos, lockscreen asli HP (PIN/pola/sidik jari) tetap
 * muncul kalau HP memang memakai kunci layar. Jadi ini lapisan tampilan, bukan pengganti keamanan.
 */
class LockScreenActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var notifBox: LinearLayout
    private var torchId: String? = null
    private var torchOn = false
    private var torchBtn: FrameLayout? = null

    // keypad kode sandi
    private var padLayer: FrameLayout? = null
    private var dotsRow: LinearLayout? = null
    private var padTitle: TextView? = null
    private var padCancel: TextView? = null
    private var entered = StringBuilder()

    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            val h24 = Prefs.bool(this@LockScreenActivity, Prefs.LOCK_24H)
            clock.text = SimpleDateFormat(if (h24) "HH:mm" else "h:mm", Locale("id")).format(now)
            date.text = SimpleDateFormat("EEEE, d MMMM", Locale("id")).format(now)
            fillNotifications()
            handler.postDelayed(this, 5_000)
        }
    }

    private fun circleBg(color: Int, pressed: Int): StateListDrawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(pressed) })
        addState(intArrayOf(), GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) })
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        root = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#3A3F8F"), Color.parseColor("#7B3FA6"), Color.parseColor("#1B82C9"))
            )
        }
        // wallpaper yang sama dengan Home
        val wall = Backdrop.sharp
        if (wall != null && Prefs.int(this, Prefs.WALL_MODE) != 2) {
            root.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(wall)
            }, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        root.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#40000000"), Color.parseColor("#10000000"), Color.parseColor("#55000000"))
            )
        }, FrameLayout.LayoutParams(MATCH, MATCH))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), statusBarHeight() + dp(48), dp(20), dp(24))
        }
        date = TextView(this).apply {
            textSize = 19f; setTextColor(Color.parseColor("#D9FFFFFF")); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        clock = TextView(this).apply {
            textSize = 96f; setTextColor(Color.parseColor("#F2FFFFFF")); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            includeFontPadding = false
            setShadowLayer(dp(14).toFloat(), 0f, dp(2).toFloat(), Color.parseColor("#44000000"))
        }
        notifBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(date)
        col.addView(clock, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(2) })
        col.addView(notifBox, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(28) })
        root.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))

        // senter (kiri bawah) dan kamera (kanan bawah): lingkaran kaca 52dp
        fun round(glyph: G, click: () -> Unit) = FrameLayout(this).apply {
            background = circleBg(Color.parseColor("#59404048"), Color.parseColor("#99808088"))
            isClickable = true
            setOnClickListener { performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK); click() }
            addView(GlyphView(this@LockScreenActivity, glyph, Color.WHITE, 0.5f), FrameLayout.LayoutParams(MATCH, MATCH))
        }
        torchBtn = round(G.TORCH) { toggleTorch() }
        val cam = round(G.CAMERA) {
            startSafe(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE), Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
        }
        root.addView(torchBtn, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.BOTTOM or Gravity.START).apply {
            leftMargin = dp(40); bottomMargin = dp(64)
        })
        root.addView(cam, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.BOTTOM or Gravity.END).apply {
            rightMargin = dp(40); bottomMargin = dp(64)
        })
        val hint = TextView(this).apply {
            text = "Geser ke atas untuk membuka"; textSize = 13f
            setTextColor(Color.parseColor("#B3FFFFFF")); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        root.addView(hint, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(28) })
        val bar = View(this).apply {
            background = GradientDrawable().apply { cornerRadius = dp(3).toFloat(); setColor(Color.parseColor("#E6FFFFFF")) }
        }
        root.addView(bar, FrameLayout.LayoutParams(dp(134), dp(5), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(10) })

        var downY = 0f
        var dragging = false
        root.setOnTouchListener { _, e ->
            if (padLayer != null) return@setOnTouchListener false
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downY = e.rawY; dragging = true }
                MotionEvent.ACTION_MOVE -> if (dragging) col.translationY = (e.rawY - downY).coerceAtMost(0f) * 0.5f
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                    col.animate().translationY(0f).setDuration(180).start()
                    if (downY - e.rawY > dp(120)) requestOpen()
                }
            }
            true
        }
        setContentView(root)

        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            torchId = cm.cameraIdList.firstOrNull {
                val ch = cm.getCameraCharacteristics(it)
                ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------- notifikasi

    private fun fillNotifications() {
        notifBox.removeAllViews()
        val list = try { NotifHub.active(this).take(3) } catch (_: Exception) { emptyList() }
        for (sbn in list) {
            val title = NotifHub.titleOf(sbn)
            val text = NotifHub.textOf(sbn)
            if (title.isBlank() && text.isBlank()) continue
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(Color.parseColor("#66404048")) }
                setPadding(dp(16), dp(12), dp(16), dp(12))
            }
            card.addView(TextView(this).apply {
                this.text = NotifHub.appName(this@LockScreenActivity, sbn.packageName).uppercase()
                textSize = 11f; setTextColor(Color.parseColor("#B3FFFFFF")); maxLines = 1
            })
            card.addView(TextView(this).apply {
                this.text = title.ifBlank { text }; textSize = 15f; setTextColor(Color.WHITE); maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            })
            if (title.isNotBlank() && text.isNotBlank()) card.addView(TextView(this).apply {
                this.text = text; textSize = 14f; setTextColor(Color.parseColor("#E6FFFFFF")); maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
            notifBox.addView(card, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
        }
    }

    // ------------------------------------------------------------ senter

    private fun toggleTorch() {
        val id = torchId ?: return
        try {
            (getSystemService(Context.CAMERA_SERVICE) as CameraManager).setTorchMode(id, !torchOn)
            torchOn = !torchOn
            torchBtn?.background = if (torchOn) circleBg(Color.WHITE, Color.parseColor("#E6E6E6"))
            else circleBg(Color.parseColor("#59404048"), Color.parseColor("#99808088"))
            (torchBtn?.getChildAt(0) as? GlyphView)?.tint = if (torchOn) Color.BLACK else Color.WHITE
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------ buka kunci

    private fun requestOpen() {
        if (LockPass.isSet(this)) showPad() else unlock()
    }

    private fun unlock() {
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isKeyguardLocked) { finish(); return }
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { finish() }
            override fun onDismissCancelled() { root.animate().translationY(0f).start() }
        })
    }

    // ------------------------------------------------- keypad kode sandi

    private fun showPad() {
        if (padLayer != null) return
        entered = StringBuilder()
        val layer = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#B3000000"))
            isClickable = true
            alpha = 0f
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), statusBarHeight() + dp(56), dp(24), dp(24))
        }
        padTitle = TextView(this).apply {
            text = "Masukkan Kode Sandi"; textSize = 19f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        col.addView(padTitle)
        dotsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        col.addView(dotsRow, LinearLayout.LayoutParams(WRAP, dp(14)).apply { topMargin = dp(28); bottomMargin = dp(44) })
        drawDots()

        val letters = mapOf('2' to "ABC", '3' to "DEF", '4' to "GHI", '5' to "JKL", '6' to "MNO", '7' to "PQRS", '8' to "TUV", '9' to "WXYZ")
        val rows = listOf("123", "456", "789", " 0 ")
        for (r in rows) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            for (ch in r) {
                if (ch == ' ') {
                    row.addView(View(this), LinearLayout.LayoutParams(dp(78), dp(78)).apply { setMargins(dp(14), dp(7), dp(14), dp(7)) })
                    continue
                }
                val key = FrameLayout(this).apply {
                    background = circleBg(Color.parseColor("#40FFFFFF"), Color.parseColor("#99FFFFFF"))
                    isClickable = true
                    setOnClickListener { performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); press(ch) }
                }
                val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
                inner.addView(TextView(this).apply {
                    text = ch.toString(); textSize = 32f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                    typeface = Typeface.create("sans-serif-light", Typeface.NORMAL); includeFontPadding = false
                })
                val sub = letters[ch]
                if (sub != null) inner.addView(TextView(this).apply {
                    text = sub; textSize = 9f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
                    letterSpacing = 0.15f; includeFontPadding = false
                })
                key.addView(inner, FrameLayout.LayoutParams(MATCH, MATCH))
                row.addView(key, LinearLayout.LayoutParams(dp(78), dp(78)).apply { setMargins(dp(14), dp(7), dp(14), dp(7)) })
            }
            col.addView(row)
        }

        val bottom = FrameLayout(this)
        bottom.addView(TextView(this).apply {
            text = "Darurat"; textSize = 15f; setTextColor(Color.WHITE)
            setOnClickListener { startSafe(Intent(Intent.ACTION_DIAL)) }
        }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.START or Gravity.CENTER_VERTICAL).apply { leftMargin = dp(40) })
        padCancel = TextView(this).apply {
            text = "Batal"; textSize = 15f; setTextColor(Color.WHITE)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setOnClickListener { if (entered.isEmpty()) hidePad() else { entered.deleteCharAt(entered.length - 1); drawDots() } }
        }
        bottom.addView(padCancel, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(28) })
        col.addView(bottom, LinearLayout.LayoutParams(MATCH, dp(48)).apply { topMargin = dp(14) })

        layer.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(layer, FrameLayout.LayoutParams(MATCH, MATCH))
        padLayer = layer
        layer.animate().alpha(1f).setDuration(180).start()
    }

    private fun hidePad() {
        val layer = padLayer ?: return
        padLayer = null
        layer.animate().alpha(0f).setDuration(150).withEndAction { root.removeView(layer) }.start()
    }

    private fun drawDots() {
        val row = dotsRow ?: return
        row.removeAllViews()
        val n = LockPass.length(this)
        for (i in 0 until n) {
            val filled = i < entered.length
            row.addView(View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    if (filled) setColor(Color.WHITE) else { setColor(Color.TRANSPARENT); setStroke(dp(1), Color.WHITE) }
                }
            }, LinearLayout.LayoutParams(dp(13), dp(13)).apply { setMargins(dp(8), 0, dp(8), 0) })
        }
        padCancel?.text = if (entered.isEmpty()) "Batal" else "Hapus"
    }

    private fun press(d: Char) {
        val n = LockPass.length(this)
        if (entered.length >= n) return
        entered.append(d)
        drawDots()
        if (entered.length == n) {
            if (LockPass.check(this, entered.toString())) {
                hidePad(); unlock()
            } else {
                wrong()
            }
        }
    }

    private fun wrong() {
        dotsRow?.performHapticFeedback(HapticFeedbackConstants.REJECT)
        padTitle?.text = "Kode sandi salah, coba lagi"
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 420
            addUpdateListener {
                val t = it.animatedValue as Float
                dotsRow?.translationX = (sin(t * 6f * Math.PI) * (1f - t) * dp(16)).toFloat()
            }
            start()
        }
        handler.postDelayed({
            entered = StringBuilder()
            drawDots()
            padTitle?.text = "Masukkan Kode Sandi"
        }, 450)
    }

    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { handler.removeCallbacks(tick); super.onPause() }

    @Deprecated("Back hanya menutup keypad")
    override fun onBackPressed() { if (padLayer != null) hidePad() }

    companion object {
        /** Menampilkan lockscreen iOS (dipanggil receiver layar mati/menyala). */
        fun show(ctx: Context) {
            if (!Prefs.bool(ctx, Prefs.LOCK_ENABLED)) return
            ctx.startActivity(
                Intent(ctx, LockScreenActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
        }
    }
}
