package com.ios27.launcher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.view.Display
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import kotlin.math.abs

/**
 * Layanan latar depan yang menampilkan, di atas semua aplikasi:
 *  - Dynamic Island (lagu, hotspot, charger, notifikasi)
 *  - Strip tipis di tepi atas layar yang menangkap geseran ke bawah, lalu membuka Notification Center
 *    (geser dari kiri/tengah) atau Control Center (geser dari kanan) bergaya iOS
 *
 * Butuh izin "Tampil di atas aplikasi lain" (SYSTEM_ALERT_WINDOW).
 * Dijalankan sebagai layanan latar depan supaya tidak dimatikan Android saat aplikasi lain dibuka.
 */
class IslandOverlayService : Service() {

    private var wm: WindowManager? = null
    private var island: DynamicIslandView? = null
    private var feeds: IslandFeeds? = null
    private var shade: ShadeController? = null
    private var screenReceiver: android.content.BroadcastReceiver? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (!Settings.canDrawOverlays(this) || !Prefs.bool(this, Prefs.OVERLAY)) {
            removeAll()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_REFRESH) removeAll()
        if (island == null) addAll() else feeds?.refreshMedia()
        rebindListener()
        if (intent?.action == ACTION_PANEL) shade?.openPanel(intent.getBooleanExtra(EXTRA_CONTROL, false))
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Dynamic Island", NotificationManager.IMPORTANCE_MIN).apply {
                    setShowBadge(false)
                }
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, SettingsActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Dynamic Island aktif")
            .setContentText("Ketuk untuk membuka pengaturan")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    /** Kalau akses notifikasi sudah diberi tapi listener-nya terputus (sering di HP yang agresif), sambungkan lagi. */
    private fun rebindListener() {
        if (MediaWatcher.isAccessGranted(this) && NotifHub.service == null) {
            try {
                NotificationListenerService.requestRebind(ComponentName(this, MediaListenerService::class.java))
            } catch (_: Exception) {}
        }
    }

    private fun addAll() {
        val d = resources.displayMetrics.density
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        shade = ShadeController(this).also {
            // kalau Accessibility Service aktif, strip miliknya (lebih tinggi dari status bar) yang dipakai
            if (ShadeAccessibilityService.instance == null) it.start()
        }

        if (screenReceiver == null) {
            screenReceiver = object : android.content.BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    try { LockScreenActivity.show(c) } catch (_: Exception) {}
                }
            }
            registerReceiver(screenReceiver, android.content.IntentFilter(Intent.ACTION_SCREEN_OFF))
        }

        val view = DynamicIslandView(this)
        var x = 0
        var y = (Prefs.int(this, Prefs.ISLAND_Y) * d).toInt()
        if (Prefs.bool(this, Prefs.ISLAND_AUTO)) {
            val hole = cameraHole()
            if (hole != null) {
                val s = Prefs.int(this, Prefs.ISLAND_SCALE) / 100f
                x = hole.first - resources.displayMetrics.widthPixels / 2
                y = (hole.second - 18 * d * s).toInt().coerceAtLeast(0)
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            this.x = x
            this.y = y
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm?.addView(view, lp)
        island = view
        DynamicIslandView.overlay = view
        feeds = IslandFeeds(this, view).also { it.start() }
    }

    /** Titik tengah lubang kamera (x, y) dalam piksel, atau null kalau HP tidak punya cutout di atas. */
    private fun cameraHole(): Pair<Int, Int>? {
        return try {
            val display = (getSystemService(DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
            val rects = display.cutout?.boundingRects ?: return null
            val w = resources.displayMetrics.widthPixels
            val r = rects.firstOrNull { it.top <= 8 && it.width() < w / 2 } ?: return null
            r.centerX() to r.centerY()
        } catch (_: Throwable) { null }
    }

    private fun removeAll() {
        screenReceiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        screenReceiver = null
        feeds?.stop(); feeds = null
        island?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        if (DynamicIslandView.overlay === island) DynamicIslandView.overlay = null
        island = null
        shade?.stop(); shade = null
    }

    override fun onDestroy() {
        removeAll()
        super.onDestroy()
    }

    companion object {
        const val ACTION_REFRESH = "com.ios27.launcher.REFRESH_ISLAND"
        const val ACTION_PANEL = "com.ios27.launcher.OPEN_PANEL"
        const val EXTRA_CONTROL = "control"
        private const val CHANNEL = "island"
        private const val NOTIF_ID = 27

        /** Menyalakan layanan kalau belum jalan. Aman dipanggil berulang. */
        fun start(ctx: Context) {
            if (Settings.canDrawOverlays(ctx) && Prefs.bool(ctx, Prefs.OVERLAY)) {
                ContextCompat.startForegroundService(ctx, Intent(ctx, IslandOverlayService::class.java))
            }
        }

        /** Dipanggil setelah posisi, ukuran, atau pengaturan panel diubah: layanan membangun ulang island dan strip. */
        fun refresh(ctx: Context) {
            if (Settings.canDrawOverlays(ctx) && Prefs.bool(ctx, Prefs.OVERLAY)) {
                ContextCompat.startForegroundService(
                    ctx, Intent(ctx, IslandOverlayService::class.java).setAction(ACTION_REFRESH)
                )
            }
        }

        /** Membuka Control Center ([control] = true) atau Notification Center di atas aplikasi yang sedang tampil. */
        fun openPanel(ctx: Context, control: Boolean) {
            val a11y = ShadeAccessibilityService.instance
            if (a11y != null) { a11y.openPanel(control); return }
            if (Settings.canDrawOverlays(ctx)) {
                ContextCompat.startForegroundService(
                    ctx, Intent(ctx, IslandOverlayService::class.java)
                        .setAction(ACTION_PANEL).putExtra(EXTRA_CONTROL, control)
                )
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, IslandOverlayService::class.java))
        }
    }
}

/**
 * Mengganti tampilan panel notifikasi dan quick settings Android dengan Notification Center dan
 * Control Center bergaya iOS. Isinya tetap notifikasi asli dan toggle asli HP.
 *
 * Caranya: strip transparan setinggi status bar di tepi atas layar. Geseran ke bawah dari strip
 * itu membuka panel iOS (jendela overlay layar penuh) menggantikan panel Android.
 */
class ShadeController(
    private val ctx: Context,
    private val windowType: Int = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
) {

    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var strip: View? = null
    private var panel: FrameLayout? = null
    private var cc: ControlCenter? = null
    private var nc: NotificationCenter? = null

    private class PanelRoot(c: Context, val onBack: () -> Unit) : FrameLayout(c) {
        init {
            isFocusable = true
            isFocusableInTouchMode = true
        }

        override fun dispatchKeyEvent(e: KeyEvent): Boolean {
            if (e.keyCode == KeyEvent.KEYCODE_BACK) {
                if (e.action == KeyEvent.ACTION_UP) onBack()
                return true
            }
            return super.dispatchKeyEvent(e)
        }
    }

    private inner class Strip(c: Context) : View(c) {
        private var downX = 0f
        private var downY = 0f
        private var fired = false
        private var toIsland = false

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; fired = false
                    // strip ini menutupi island, jadi ketukan di area island diteruskan ke island
                    toIsland = DynamicIslandView.overlay?.hitScreen(e.rawX, e.rawY) == true
                }
                MotionEvent.ACTION_MOVE -> if (!fired) {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (dy > ctx.dp(16) && dy > abs(dx)) {
                        fired = true
                        toIsland = false
                        if (Prefs.bool(ctx, Prefs.HAPTIC)) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                        val screenW = ctx.resources.displayMetrics.widthPixels
                        openPanel(control = downX > screenW * 0.65f)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (toIsland && !fired &&
                        abs(e.rawX - downX) < ctx.dp(24) && abs(e.rawY - downY) < ctx.dp(24)
                    ) DynamicIslandView.overlay?.tapScreen(e.rawX, e.rawY)
                    toIsland = false
                }
                MotionEvent.ACTION_CANCEL -> toIsland = false
            }
            return true
        }
    }

    fun start() {
        if (Prefs.bool(ctx, Prefs.SHADE_REPLACE)) addStrip()
    }

    fun stop() {
        removeStrip()
        removePanel()
    }

    private fun addStrip() {
        if (strip != null) return
        val v = Strip(ctx)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            ctx.statusBarHeight(),
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            wm.addView(v, lp)
            strip = v
        } catch (_: Exception) {}
    }

    private fun removeStrip() {
        strip?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        strip = null
    }

    /** [control] = true membuka Control Center, false membuka Notification Center. */
    fun openPanel(control: Boolean) {
        removePanel()
        val root = PanelRoot(ctx) { closeCurrent() }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            windowType,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            dimAmount = 0f
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            // Liquid Glass: blur ~40% di belakang panel (Android 12+ kalau blur jendela diizinkan HP)
            if (Build.VERSION.SDK_INT >= 31 && wm.isCrossWindowBlurEnabled) {
                flags = flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
                blurBehindRadius = 80
            }
        }
        try { wm.addView(root, lp) } catch (_: Exception) { return }
        panel = root
        root.requestFocus()

        val inset = ctx.statusBarHeight()
        if (control) {
            cc = ControlCenter(ctx, root, { inset }, false,
                { ctx.startSafe(Intent(ctx, MainActivity::class.java)) },
                { removePanel() }).also { it.show() }
        } else {
            nc = NotificationCenter(ctx, root, { inset }, false) { removePanel() }.also { it.show() }
        }
    }

    private fun closeCurrent() {
        if (cc?.isShowing == true) cc?.close()
        else if (nc?.isShowing == true) nc?.close()
        else removePanel()
    }

    val isPanelShowing: Boolean get() = panel != null

    private fun removePanel() {
        cc = null
        nc = null
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
    }
}
