package com.ios27.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.drawable.AdaptiveIconDrawable
import android.provider.MediaStore
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin

data class AppEntry(
    val label: String,
    val pkg: String,
    val component: ComponentName,
    val category: Int,
    /** Padanan iOS (App Store, Safari, dll) kalau ada; dipakai untuk ikon dan nama. */
    val ios: IosKind? = null
)

/** Semua aplikasi berikon launcher. Launcher ini sendiri ikut tampil dan membuka Pengaturan. */
fun loadApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(query, 0)
        .map { ri ->
            val ai = ri.activityInfo
            val self = ai.packageName == ctx.packageName
            val rawLabel = ri.loadLabel(pm).toString()
            val kind = if (!self && Prefs.bool(ctx, Prefs.IOS_ICONS)) IosIcons.match(ai.packageName, rawLabel) else null
            AppEntry(
                label = if (self) "Launcher" else kind?.title ?: rawLabel,
                pkg = ai.packageName,
                component = ComponentName(ai.packageName, ai.name),
                category = if (self) ApplicationInfo.CATEGORY_PRODUCTIVITY else ai.applicationInfo.category,
                ios = kind
            )
        }
        .sortedBy { it.label.lowercase() }
}

/** Dock: Telepon, Pesan, Browser, Kamera. Kalau tidak ketemu, diisi aplikasi lain. */
fun resolveDock(ctx: Context, apps: List<AppEntry>): List<AppEntry> {
    val pm = ctx.packageManager
    val wanted = listOf(
        Intent(Intent.ACTION_DIAL),
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER),
        Intent(MediaStore.ACTION_IMAGE_CAPTURE)
    )
    val result = mutableListOf<AppEntry>()
    for (intent in wanted) {
        val pkg = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName
        val hit = apps.firstOrNull {
            it.pkg == pkg && it.pkg != ctx.packageName && result.none { r -> r.pkg == it.pkg }
        }
        if (hit != null) result += hit
    }
    for (a in apps) {
        if (result.size >= 4) break
        if (a.pkg != ctx.packageName && result.none { it.pkg == a.pkg }) result += a
    }
    return result.take(4)
}

fun categoryName(a: AppEntry): String = when (a.category) {
    ApplicationInfo.CATEGORY_SOCIAL -> "Sosial"
    ApplicationInfo.CATEGORY_AUDIO,
    ApplicationInfo.CATEGORY_VIDEO,
    ApplicationInfo.CATEGORY_IMAGE -> "Hiburan"
    ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Produktivitas"
    ApplicationInfo.CATEGORY_GAME -> "Game"
    ApplicationInfo.CATEGORY_NEWS -> "Berita"
    ApplicationInfo.CATEGORY_MAPS -> "Perjalanan"
    else -> "Utilitas"
}

val CATEGORY_ORDER = listOf(
    "Sosial", "Hiburan", "Produktivitas", "Game", "Berita", "Perjalanan", "Utilitas"
)

/** Bentuk squircle (kotak membulat halus ala iOS). 0 = hampir persegi, 100 = lingkaran. */
fun squirclePath(size: Float, roundness: Int): Path {
    val n = 2.0 + (1.0 - roundness / 100.0) * 10.0
    val a = size / 2f
    val path = Path()
    val steps = 160
    for (i in 0..steps) {
        val t = 2 * Math.PI * i / steps
        val ct = cos(t)
        val st = sin(t)
        val x = a + a * sign(ct) * abs(ct).pow(2.0 / n)
        val y = a + a * sign(st) * abs(st).pow(2.0 / n)
        if (i == 0) path.moveTo(x.toFloat(), y.toFloat()) else path.lineTo(x.toFloat(), y.toFloat())
    }
    path.close()
    return path
}

/**
 * Ikon dipotong menjadi squircle sesuai "Corner rounding", diberi kilau kaca dan garis tepi cahaya.
 * Gaya Glass menaruh ikon di atas ubin kaca tembus pandang. Gaya Original memakai latar ikon aslinya.
 */
fun makeIcon(ctx: Context, app: AppEntry, sizePx: Int): Bitmap {
    val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val s = sizePx.toFloat()
    val glass = Prefs.bool(ctx, Prefs.ICON_GLASS)
    val clip = squirclePath(s, Prefs.int(ctx, Prefs.ICON_ROUND))

    c.save()
    c.clipPath(clip)
    if (app.ios != null) {
        IosIcons.draw(c, app.ios, s)
    } else {
        if (glass) {
            val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(
                    0f, 0f, s, s,
                    Color.parseColor("#5C6A86"), Color.parseColor("#232A3B"), Shader.TileMode.CLAMP
                )
            }
            c.drawRect(0f, 0f, s, s, fill)
        }
        try {
            val raw = ctx.packageManager.getActivityIcon(app.component)
            val dr = raw.constantState?.newDrawable()?.mutate() ?: raw
            if (dr is AdaptiveIconDrawable) {
                // layer adaptif 108dp dengan area aman 72dp: perbesar supaya area aman memenuhi ubin
                val ext = (s * if (glass) 0.10f else 0.25f).toInt()
                if (!glass) dr.background?.let {
                    it.setBounds(-ext, -ext, sizePx + ext, sizePx + ext); it.draw(c)
                }
                dr.foreground?.let {
                    it.setBounds(-ext, -ext, sizePx + ext, sizePx + ext); it.draw(c)
                }
            } else {
                if (!glass) c.drawColor(Color.WHITE)
                val inset = (s * if (glass) 0.16f else 0.12f).toInt()
                dr.setBounds(inset, inset, sizePx - inset, sizePx - inset)
                dr.draw(c)
            }
        } catch (_: Exception) {
            c.drawColor(Color.parseColor("#48484A"))
        }

    }

    // kilau kaca di bagian atas
    val sheen = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = LinearGradient(
            0f, 0f, 0f, s * 0.6f,
            Color.argb(if (glass) 70 else 40, 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
    }
    c.drawRect(0f, 0f, s, s * 0.6f, sheen)
    c.restore()

    // garis tepi cahaya
    val sw = (s * 0.028f).coerceAtLeast(1.5f)
    val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = sw
        shader = LinearGradient(
            0f, 0f, s, s,
            intArrayOf(Color.argb(210, 255, 255, 255), Color.argb(24, 255, 255, 255), Color.argb(120, 255, 255, 255)),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
    }
    c.save()
    c.clipPath(clip)
    c.drawPath(clip, edge)
    c.restore()
    return bmp
}
