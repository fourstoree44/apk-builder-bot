# iOS 27 Launcher (Android 11+)

Launcher bergaya iPhone: Liquid Glass, Dynamic Island, Control Center, dan Notification Center.

## Yang baru di versi ini
- **Liquid Glass sungguhan**: panel menggambar wallpaper blur yang persis ada di belakangnya, tepinya membelokkan isi di belakangnya seperti lensa (refraksi), ditambah kilau dan garis tepi cahaya.
  Wallpaper dikelola launcher sendiri (4 gaya bawaan, foto sendiri, atau wallpaper sistem). Kalau memakai wallpaper sistem, kaca jadi kaca buram biasa.
- **Dynamic Island hidup** (animasi per/spring, isi berganti dengan halus):
  - Lagu (Spotify, YouTube Music, dll): cover, equalizer berwarna dari cover, ketuk untuk kontrol penuh, progress yang bisa digeser, ketuk cover membuka aplikasinya
  - Hotspot menyala/mati dengan penghitung waktu, ketuk "Buka" masuk ke pengaturan hotspot
  - Charger dicolok/dicabut, notifikasi baru, jam dan baterai
  - Island **tidak muncul terus**: saat diam cuma titik hitam kecil seukuran lubang kamera. Island melebar sendiri saat ngecas, ada notifikasi, musik diputar, atau hotspot nyala. Pencet titik kamera kapan saja untuk membukanya (opsi di Pengaturan > Dynamic Island)
  - Posisi otomatis di lubang kamera
- **Panel iOS menggantikan panel notifikasi dan quick settings Android**: geser ke bawah dari tepi atas layar di aplikasi apa pun.
  Sisi kanan = Control Center, sisi kiri dan tengah = Notification Center. Isinya notifikasi asli dan toggle asli HP.
- Ikon squircle dengan kilau kaca, status bar iOS, menu tekan-lama berbahan kaca, Settings bergaya iOS.

## Kenapa Dynamic Island versi lama tidak muncul di Spotify
Layanan island dulu hanya "layanan biasa" yang dimatikan Android begitu launcher tidak di depan. Sekarang berjalan sebagai
layanan latar depan (ada satu notifikasi kecil "Dynamic Island aktif" yang bisa kamu sembunyikan), dan listener notifikasi
disambungkan ulang otomatis kalau terputus.

## Izin yang diminta
- Tampil di atas aplikasi lain: Dynamic Island dan panel iOS di semua aplikasi
- Akses notifikasi: membaca lagu yang diputar dan daftar notifikasi
- Ubah pengaturan sistem: kecerahan dan kunci rotasi di Control Center
- Notifikasi: untuk notifikasi layanan latar depan (Android 13+)

## Catatan jujur
- Panel notifikasi dan quick settings bawaan Android tidak bisa diubah tampilannya oleh aplikasi biasa. Yang dilakukan launcher:
  strip tak terlihat setinggi status bar di tepi atas layar menangkap geseran ke bawah, lalu menampilkan panel iOS. Kalau di HP kamu
  panel Android masih ikut terbuka, matikan "Ganti panel notifikasi" di Settings > Panel & Notifikasi dan pakai geser di Home atau ketuk status bar.
- Wi-Fi, data, Bluetooth, dan pesawat tidak boleh dinyalakan langsung oleh aplikasi biasa di Android 10+, jadi tombolnya membuka panel sistem.
  Senter, kecerahan, volume, dan kunci rotasi bisa langsung.
- Deteksi hotspot memakai antarmuka jaringan (ap0, swlan0, wlan1, dst) dan dicek tiap 2,5 detik. Di sebagian HP nama antarmukanya bisa berbeda.
- Kode ini belum pernah dikompilasi di lingkungan pembuatnya (tidak ada Android SDK). Sintaks sudah dicek, tapi kalau build gagal, kirim pesan errornya.

## Cara build APK
Android Studio: File > Open > pilih folder ini > Build > Build APK(s). Terminal (JDK 17 + Android SDK 34): `./gradlew assembleDebug`.
APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Jadikan launcher default
1. Install APK, buka sekali (ikon "Launcher" membuka Pengaturan), beri izin overlay dan akses notifikasi.
2. Tekan Home, pilih "iOS 27 Launcher", lalu "Selalu".


## Baru di v4
- **Control Center bergaya video referensi**: pil Wi-Fi dan Seluler (putih saat aktif), kartu lagu + slider kecerahan dan volume tinggi, lalu 12 tombol bulat kaca (putih saat hidup).
- **Notification Center** dengan jam raksasa bergradasi kaca.
- **Accessibility Service "iOS 27 Panel"**: cara paling kuat untuk menggantikan panel bawaan HP. Jendela aksesibilitas berada di atas status bar,
  jadi geseran dari tepi atas ditangkap launcher. Kalau panel bawaan sempat terbuka, langsung ditutup dan diganti panel iOS.
- **Halaman Settings > Izin**: status semua izin + panduan "Setelan Terbatas".

## Izin terkunci ("Setelan Terbatas")
Android 13+ mengunci Akses Notifikasi dan Aksesibilitas untuk aplikasi yang dipasang dari luar Play Store.
Buka: Info Aplikasi iOS 27 Launcher > titik tiga di pojok kanan atas > "Izinkan setelan terbatas" > kembali dan nyalakan izinnya.
(Titik tiga baru muncul setelah sekali kena dialog "Setelan Terbatas".)


## Baru di v5
- **Control Center overlay iOS 27** (bukan Quick Settings bawaan): geser ke bawah dari **pojok kanan atas** di aplikasi apa pun. Hanya butuh izin
  "Tampil di atas aplikasi lain" (tidak kena "Setelan Terbatas"). Latar hitam transparan ~40% + blur jendela (Android 12+), sudut 28dp, biru #0A84FF saat aktif.
  Layout: jam/tanggal/baterai; kotak Wi-Fi/Data/Bluetooth/Pesawat + slider Brightness & Volume; grid 4x2; tombol **+** untuk Edit.
  Tutup: geser ke atas, ketuk di luar, atau Back.
- **Edit mode (+)**: ketuk tombol = ganti ukuran (1x / lebar), lencana − = hapus, tekan-tahan lalu geser = pindah, baris "Tambah tombol" untuk menambah. Tahan tombol (di luar edit) = buka pengaturan detail.
- **Toggle beneran** Wi-Fi / Data / Bluetooth / Pesawat lewat **Shizuku** atau root. Tanpa keduanya, tombol membuka panel sistem (batasan Android 10+).
- **Lockscreen iPhone** (Settings > Panel & Notifikasi > Lockscreen iOS): tampil di atas lockscreen sistem; kunci asli HP tetap muncul setelah geser ke atas.
- **Buka kunci "Setelan Terbatas"**: tombol otomatis via Shizuku, perintah ADB, dan tutorial lengkap di Settings > Izin.

## Tutorial: "Setelan Terbatas" (4 cara)
1. Info Aplikasi > ⋮ > Izinkan setelan terbatas (⋮ muncul setelah sekali kena dialog).
2. Shizuku aktif > Settings > Izin > "Buka kunci otomatis lewat Shizuku".
3. PC: `adb shell appops set com.ios27.launcher ACCESS_RESTRICTED_SETTINGS allow`
4. Install ulang lewat installer berbasis sesi (SAI / Shizuku installer) — tidak dikunci sejak awal.


## Baru di v6 (perbaikan dari uji coba di Tecno Spark 10)
- **Dynamic Island gampang dipencet**: penyebab utamanya jendela strip aksesibilitas menutupi island dan menelan ketukan. Sekarang strip meneruskan ketukan ke island.
  Area sentuh titik kamera minimal 56x48dp (kotak jendela 64x48dp) supaya enak di layar mana pun.
- **Kontrol musik**: baris tombol dibagi tiga bagian lebar (sebelumnya | putar-jeda | berikutnya). Lompat lagu pakai transportControls; kalau pemutar tidak
  merespons dalam 0,7 detik otomatis dicoba lewat tombol media (headset). Data lagu dibaca ulang setelah lompat sehingga island ikut berganti.
- **Status bar ganda dihapus**: jam, sinyal, dan baterai buatan launcher di Home dibuang. Status bar bawaan HP dipakai apa adanya.
- **Nama ikon tidak kepotong**: tinggi baris grid dihitung dari ukuran ikon + jarak + tinggi teks, jadi jumlah baris menyesuaikan.
- **Ikon & nama ala iOS**: Play Store jadi App Store, Chrome jadi Safari, plus Telepon, Pesan, Kamera, Foto, Pengaturan, Jam, Kalkulator, Kalender,
  Peta, Kontak, File, Cuaca, Mail, Catatan, Musik, Kompas, Memo Suara. Digambar lewat kode (tanpa aset). Bisa dimatikan di Settings > Icons.
- **Lockscreen iOS 27**: wallpaper Home, jam besar, notifikasi, senter/kamera, indikator Home. Geser ke atas membuka **keypad kode sandi iOS**
  (kode sandi launcher 4-6 angka, diatur di Settings > Panel & Notifikasi). Android tidak mengizinkan aplikasi mengganti layar PIN sistem,
  jadi PIN asli HP tetap muncul setelahnya kalau HP memakai kunci layar.
- Catatan: kode v6 belum dikompilasi di lingkungan pembuatnya (tidak ada Android SDK). Kalau build gagal, kirim pesan errornya.
