package com.ios27.launcher

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Lockscreen bergaya iPhone (iOS 27): tanggal, jam besar, senter + kamera di bawah, geser ke atas untuk buka.
 *
 * Android TIDAK mengizinkan aplikasi biasa mengganti lockscreen sistem. Layar ini tampil DI ATAS lockscreen
 * (setShowWhenLocked) tiap layar menyala. Saat digeser ke atas, lockscreen asli HP (PIN/pola/sidik jari)
 * muncul untuk keamanan; kalau HP tanpa kunci, langsung masuk. Jadi ini lapisan tampilan, bukan pengganti keamanan.
 */
class LockScreenActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private var torchId: String? = null
    private var torchOn = false
    private var torchBtn: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            val now = Date()
            val h24 = Prefs.bool(this@LockScreenActivity, Prefs.LOCK_24H)
            clock.text = SimpleDateFormat(if (h24) "HH.mm" else "h.mm", Locale("id")).format(now)
            date.text = SimpleDateFormat("EEEE, d MMMM", Locale("id")).format(now)
            handler.postDelayed(this, 5_000)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY

        val sans = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        val root = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.parseColor("#1B2A4A"), Color.parseColor("#0B0B14"), Color.parseColor("#2A1238"))
            )
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), statusBarHeight() + dp(36), dp(24), dp(24))
        }
        date = TextView(this).apply {
            textSize = 20f; setTextColor(Color.parseColor("#E6FFFFFF")); typeface = sans; gravity = Gravity.CENTER
        }
        clock = TextView(this).apply {
            textSize = 104f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL)
            includeFontPadding = false
            setShadowLayer(dp(18).toFloat(), 0f, 0f, Color.parseColor("#55FFFFFF"))
        }
        col.addView(date); col.addView(clock)
        root.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))

        // senter (kiri bawah) dan kamera (kanan bawah), kaca bulat 50dp
        fun round(label: String, click: () -> Unit) = TextView(this).apply {
            text = label; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#55808080")) }
            setOnClickListener { click() }
        }
        torchBtn = round("🔦") { toggleTorch() }
        val cam = round("📷") {
            startSafe(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA_SECURE), Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
        }
        root.addView(torchBtn, FrameLayout.LayoutParams(dp(50), dp(50), Gravity.BOTTOM or Gravity.START).apply {
            leftMargin = dp(44); bottomMargin = dp(70)
        })
        root.addView(cam, FrameLayout.LayoutParams(dp(50), dp(50), Gravity.BOTTOM or Gravity.END).apply {
            rightMargin = dp(44); bottomMargin = dp(70)
        })
        val hint = TextView(this).apply {
            text = "Geser ke atas untuk membuka"; textSize = 13f; setTextColor(Color.parseColor("#99FFFFFF")); gravity = Gravity.CENTER
        }
        root.addView(hint, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(24) })
        val bar = View(this).apply {
            background = GradientDrawable().apply { cornerRadius = dp(3).toFloat(); setColor(Color.parseColor("#CCFFFFFF")) }
        }
        root.addView(bar, FrameLayout.LayoutParams(dp(130), dp(5), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(10) })

        var downY = 0f
        root.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> downY = e.rawY
                MotionEvent.ACTION_MOVE -> root.translationY = (e.rawY - downY).coerceAtMost(0f) * 0.6f
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (downY - e.rawY > dp(140)) unlock()
                    else root.animate().translationY(0f).setDuration(180).start()
                }
            }
            true
        }
        setContentView(root)

        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            torchId = cm.cameraIdList.firstOrNull {
                val ch = cm.getCameraCharacteristics(it)
                ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
        } catch (_: Exception) {}
    }

    private fun toggleTorch() {
        val id = torchId ?: return
        try {
            (getSystemService(Context.CAMERA_SERVICE) as CameraManager).setTorchMode(id, !torchOn)
            torchOn = !torchOn
            (torchBtn?.background as? GradientDrawable)?.setColor(if (torchOn) Color.WHITE else Color.parseColor("#55808080"))
        } catch (_: Exception) {}
    }

    private fun unlock() {
        val km = getSystemService(KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isKeyguardLocked) { finish(); return }
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { finish() }
            override fun onDismissCancelled() { findViewById<View>(android.R.id.content)?.animate()?.translationY(0f)?.start() }
        })
    }

    override fun onResume() { super.onResume(); handler.post(tick) }
    override fun onPause() { handler.removeCallbacks(tick); super.onPause() }

    @Deprecated("Back diabaikan di lockscreen")
    override fun onBackPressed() {}

    companion object {
        /** Menampilkan lockscreen iOS (dipanggil receiver layar mati/menyala). */
        fun show(ctx: Context) {
            if (!Prefs.bool(ctx, Prefs.LOCK_ENABLED)) return
            ctx.startActivity(
                Intent(ctx, LockScreenActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            )
        }
    }
}
