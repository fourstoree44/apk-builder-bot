# rzkylauncher — iOS-inspired Android launcher

Launcher Android native berbasis Kotlin untuk Android 11+.

## Fitur yang tersedia di project ini
- Home screen bergaya iOS dengan grid aplikasi, dock, indikator halaman, dan animasi membuka aplikasi.
- App Library berdasarkan kategori aplikasi dan pencarian aplikasi.
- Widget jam, tanggal, dan status baterai.
- Widget foto: pilih gambar dari Galeri / penyimpanan Android melalui pemilih dokumen sistem.
- Wallpaper home screen dari foto pilihan pengguna, tersimpan setelah aplikasi ditutup.
- Menu personalisasi dengan pilihan ukuran ikon (52/60/68 dp).
- Profil animasi Dynamic Island: Lite, Seimbang, dan Full.
- Dynamic Island menampilkan jam dan status baterai/charging; bisa ditampilkan sebagai overlay di aplikasi lain dengan izin "Tampil di atas aplikasi lain".
- Menu akses cepat ke Pengaturan Android.
- Tekan lama ikon aplikasi untuk membuka info aplikasi atau uninstall.

## Batasan yang perlu diketahui
- Dynamic Island pada versi ini belum membaca metadata musik, timer, panggilan, atau notifikasi. Overlay hanya menampilkan jam dan baterai/charging.
- Control Center, lock screen pengganti sistem, Smart Stack otomatis, Theme Store, dan ekspor/impor paket tema belum diimplementasikan.
- Launcher tidak dapat mengganti lock screen, panel notifikasi, atau Control Center sistem sepenuhnya tanpa hak sistem khusus. Fitur semacam itu harus dibuat sebagai layar/overlay pendamping dan membutuhkan izin Android.
- Profil performa saat ini mengatur durasi animasi Dynamic Island; belum merupakan benchmark otomatis berdasarkan chipset/RAM.
- Widget foto dan wallpaper menggunakan izin akses URI persisten dari pemilih gambar Android; pengguna memilih sendiri foto yang ingin dipakai.

## Build
Gunakan JDK 17, Android SDK platform 34, dan Gradle wrapper yang disediakan.

```bash
./gradlew assembleDebug
```

APK debug akan muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Menjadikan launcher default
1. Install APK lalu buka rzkylauncher.
2. Tekan tombol Home dan pilih rzkylauncher sebagai aplikasi Home default.
3. Untuk kembali ke launcher sebelumnya, ubah aplikasi Home default melalui Pengaturan Android.

## Izin
Dynamic Island overlay membutuhkan izin "Tampil di atas aplikasi lain". Izin ini opsional. Tanpa izin, island tetap dapat tampil di layar launcher.
