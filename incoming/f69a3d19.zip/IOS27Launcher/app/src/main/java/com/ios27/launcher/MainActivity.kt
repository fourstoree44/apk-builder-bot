package com.ios27.launcher

import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity() {

    private lateinit var root: FrameLayout
    private lateinit var scroller: PagerScroller
    private lateinit var pagesRow: LinearLayout
    private lateinit var dotsRow: LinearLayout
    private lateinit var bottomBox: LinearLayout
    private lateinit var dockBox: LinearLayout
    private lateinit var island: DynamicIslandView
    private lateinit var search: SearchOverlay

    private var apps: List<AppEntry> = emptyList()
    private var dockApps: List<AppEntry> = emptyList()
    private var widgetBattery: TextView? = null
    private val iconCache = ConcurrentHashMap<String, Bitmap>()

    private val screenW by lazy { resources.displayMetrics.widthPixels }
    private val screenH by lazy { resources.displayMetrics.heightPixels }
    private val prefs by lazy { getSharedPreferences("island", MODE_PRIVATE) }

    private var navInset = 0
    private var statusInset = 0
    private var pageCount = 1
    private var batteryLevel = 100
    private var charging = false
    private var batteryKnown = false

    // ---------------------------------------------------------------- pager

    inner class PagerScroller(ctx: Context) : HorizontalScrollView(ctx) {
        private var flung = false

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) flung = false
            val r = super.onTouchEvent(ev)
            if ((ev.actionMasked == MotionEvent.ACTION_UP ||
                    ev.actionMasked == MotionEvent.ACTION_CANCEL) && !flung) snapNearest()
            return r
        }

        override fun fling(velocityX: Int) {
            flung = true
            val p = scrollX.toFloat() / screenW
            val target = when {
                velocityX > 600 -> Math.floor(p.toDouble()).toInt() + 1
                velocityX < -600 -> Math.ceil(p.toDouble()).toInt() - 1
                else -> Math.round(p)
            }
            smoothScrollTo(target.coerceIn(0, pageCount - 1) * screenW, 0)
        }

        fun snapNearest() {
            val i = Math.round(scrollX.toFloat() / screenW).coerceIn(0, pageCount - 1)
            smoothScrollTo(i * screenW, 0)
        }
    }

    // ------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.isNavigationBarContrastEnforced = false

        root = FrameLayout(this)
        setContentView(root)
        applySavedWallpaper()

        scroller = PagerScroller(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setOnScrollChangeListener { _, x, _, _, _ -> updateDots((x + screenW / 2) / screenW) }
        }
        pagesRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        scroller.addView(pagesRow, FrameLayout.LayoutParams(WRAP, MATCH))
        root.addView(scroller, FrameLayout.LayoutParams(MATCH, MATCH))

        bottomBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        dotsRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        bottomBox.addView(dotsRow, LinearLayout.LayoutParams(WRAP, dp(16)))

        val searchPill = TextView(this).apply {
            text = "Search"
            textSize = 14f
            setTextColor(Color.parseColor("#E5E5EA"))
            gravity = Gravity.CENTER
            background = glass(18)
            setPadding(dp(34), 0, dp(34), 0)
            softShadow()
            setOnClickListener { search.show(apps, null, null) }
        }
        bottomBox.addView(searchPill, LinearLayout.LayoutParams(WRAP, dp(36)).apply {
            topMargin = dp(4); bottomMargin = dp(10)
        })

        dockBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = glass(32)
            setPadding(dp(10), 0, dp(10), 0)
        }
        bottomBox.addView(dockBox, LinearLayout.LayoutParams(MATCH, dp(92)).apply {
            marginStart = dp(16); marginEnd = dp(16)
        })
        root.addView(bottomBox, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM))

        island = DynamicIslandView(this)
        root.addView(island, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        applyIslandPosition()

        search = SearchOverlay(this, root, { app, px -> iconFor(app, px) }, { app, v -> launch(app, v) })

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val nav = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            val top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            if (nav != navInset || top != statusInset) {
                navInset = nav; statusInset = top
                rebuild()
            }
            insets
        }

        registerReceiver(pkgReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        })
        reloadApps()
        askOverlayPermissionOnce()
    }

    override fun onResume() {
        super.onResume()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        applyIslandMode()
    }

    override fun onPause() {
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        super.onPause()
    }

    override fun onDestroy() {
        try { unregisterReceiver(pkgReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) {
            search.close()
            island.setState(DynamicIslandView.State.COLLAPSED)
            scroller.smoothScrollTo(0, 0)
        }
    }

    @Deprecated("Launcher tidak keluar dengan tombol back")
    override fun onBackPressed() {
        if (search.isShowing) search.close() else scroller.smoothScrollTo(0, 0)
    }

    // ---------------------------------------------------------------- data

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { reloadApps() }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val nowCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            val changed = batteryKnown && nowCharging != charging
            batteryLevel = if (scale > 0) level * 100 / scale else level
            charging = nowCharging
            batteryKnown = true
            island.batteryLevel = batteryLevel
            island.charging = charging
            if (changed) island.pulse()
            widgetBattery?.text =
                if (charging) "⚡ Mengisi daya · $batteryLevel%" else "Baterai $batteryLevel%"
        }
    }

    private fun reloadApps() {
        Thread {
            val list = loadApps(this)
            val dock = resolveDock(this, list)
            (list + dock).forEach { iconFor(it, dp(60)) }
            runOnUiThread { apps = list; dockApps = dock; rebuild() }
        }.start()
    }

    private fun iconFor(app: AppEntry, px: Int): Bitmap =
        iconCache.getOrPut("${app.component.flattenToString()}:$px") { makeIcon(this, app, px) }

    private fun launch(app: AppEntry, from: View) {
        val i = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = app.component
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
        }
        try {
            val opts = ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height)
            startActivity(i, opts.toBundle())
        } catch (e: Exception) {
            Toast.makeText(this, "Tidak bisa membuka ${app.label}", Toast.LENGTH_SHORT).show()
        }
    }

    // ------------------------------------------------------------------ UI

    private fun rebuild() {
        if (apps.isEmpty()) return
        (bottomBox.layoutParams as FrameLayout.LayoutParams).bottomMargin = navInset + dp(8)
        bottomBox.requestLayout()
        buildDock()
        buildPages()
    }

    private fun buildDock() {
        dockBox.removeAllViews()
        dockApps.forEach { dockBox.addView(appCell(it, prefs.getInt("icon_size", 60), false), LinearLayout.LayoutParams(0, MATCH, 1f)) }
    }

    private fun buildPages() {
        pagesRow.removeAllViews()
        val rowH = dp(96)
        val topPad = statusInset + dp(14)
        val bottomPad = dp(176) + navInset
        val rows = ((screenH - topPad - bottomPad) / rowH).coerceIn(4, 7)
        val dockPkgs = dockApps.map { it.pkg }.toSet()
        val grid = apps.filter { it.pkg !in dockPkgs }

        var idx = 0
        var n = 0
        while (idx < grid.size || n == 0) {
            val capacity = (rows - if (n == 0) 2 else 0) * 4
            val slice = grid.subList(idx, minOf(idx + capacity, grid.size))
            pagesRow.addView(gridPage(slice, n == 0, rowH, topPad, bottomPad), LinearLayout.LayoutParams(screenW, MATCH))
            idx += capacity
            n++
        }
        pagesRow.addView(libraryPage(grid, topPad, bottomPad), LinearLayout.LayoutParams(screenW, MATCH))
        pageCount = n + 1
        buildDots(pageCount)
    }

    private fun gridPage(list: List<AppEntry>, withWidget: Boolean, rowH: Int, topPad: Int, bottomPad: Int): View {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), topPad, dp(14), bottomPad)
            isLongClickable = true
            setOnLongClickListener { showHomeMenu(); true }
        }
        if (withWidget) page.addView(widgetCard(rowH), LinearLayout.LayoutParams(MATCH, rowH * 2 - dp(12)).apply {
            marginStart = dp(6); marginEnd = dp(6); bottomMargin = dp(12)
        })
        list.chunked(4).forEach { rowApps ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowApps.forEach { row.addView(appCell(it, prefs.getInt("icon_size", 60), true), LinearLayout.LayoutParams(0, MATCH, 1f)) }
            repeat(4 - rowApps.size) { row.addView(View(this), LinearLayout.LayoutParams(0, MATCH, 1f)) }
            page.addView(row, LinearLayout.LayoutParams(MATCH, rowH))
        }
        return page
    }

    private fun widgetCard(rowH: Int): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            background = glass(26)
            setPadding(dp(22), dp(10), dp(22), dp(10))
        }
        card.addView(TextClock(this).apply {
            format24Hour = "HH:mm"; format12Hour = "HH:mm"
            textSize = 54f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }, LinearLayout.LayoutParams(WRAP, WRAP))
        card.addView(TextClock(this).apply {
            format24Hour = "EEEE, d MMMM"; format12Hour = "EEEE, d MMMM"
            textSize = 16f
            setTextColor(Color.parseColor("#E5E5EA"))
        }, LinearLayout.LayoutParams(WRAP, WRAP))
        widgetBattery = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#AEAEB2"))
            text = if (charging) "⚡ Mengisi daya · $batteryLevel%" else "Baterai $batteryLevel%"
        }
        card.addView(widgetBattery, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(4) })

        val photoUri = prefs.getString("photo_widget_uri", null)
        val photoRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        val photo = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = glass(12)
            clipToOutline = true
            if (photoUri != null) {
                try {
                    contentResolver.openInputStream(Uri.parse(photoUri))?.use { setImageBitmap(BitmapFactory.decodeStream(it)) }
                } catch (_: Exception) {}
            }
            setOnClickListener { openImagePicker(REQUEST_PHOTO_WIDGET) }
        }
        photoRow.addView(photo, LinearLayout.LayoutParams(dp(54), dp(54)))
        photoRow.addView(TextView(this).apply {
            text = if (photoUri == null) "  Tambahkan foto dari Galeri" else "  Foto pilihan kamu"
            textSize = 13f
            setTextColor(Color.parseColor("#E5E5EA"))
            setOnClickListener { openImagePicker(REQUEST_PHOTO_WIDGET) }
        }, LinearLayout.LayoutParams(WRAP, WRAP))
        card.addView(photoRow, LinearLayout.LayoutParams(MATCH, WRAP))
        return card
    }

    private fun libraryPage(grid: List<AppEntry>, topPad: Int, bottomPad: Int): View {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), topPad, dp(14), bottomPad)
        }
        page.addView(TextView(this).apply {
            text = getString(R.string.app_library)
            textSize = 16f
            setTextColor(Color.parseColor("#E5E5EA"))
            gravity = Gravity.CENTER_VERTICAL
            background = glass(14)
            setPadding(dp(16), 0, dp(16), 0)
            softShadow()
            setOnClickListener { search.show(apps, null, null) }
        }, LinearLayout.LayoutParams(MATCH, dp(44)).apply { bottomMargin = dp(14) })

        val groups = grid.groupBy { categoryName(it) }
        val names = CATEGORY_ORDER.filter { it in groups }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        names.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEach { name ->
                row.addView(libraryCard(name, groups.getValue(name)),
                    LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(dp(6), 0, dp(6), dp(14)) })
            }
            if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            body.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        page.addView(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(body, FrameLayout.LayoutParams(MATCH, WRAP))
        }, LinearLayout.LayoutParams(MATCH, 0, 1f))
        return page
    }

    private fun libraryCard(name: String, list: List<AppEntry>): View {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(24)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { search.show(apps, name, list) }
        }
        list.take(4).chunked(2).forEach { two ->
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_HORIZONTAL }
            two.forEach { app ->
                val cell = appCell(app, 52, false)
                r.addView(cell, LinearLayout.LayoutParams(0, dp(66), 1f))
            }
            if (two.size == 1) r.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            panel.addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        card.addView(panel, LinearLayout.LayoutParams(MATCH, WRAP))
        card.addView(TextView(this).apply {
            text = name
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            softShadow()
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6) })
        return card
    }

    private fun appCell(app: AppEntry, iconDp: Int, label: Boolean): View {
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (label) Gravity.TOP or Gravity.CENTER_HORIZONTAL else Gravity.CENTER
            setPadding(0, if (label) dp(6) else 0, 0, 0)
        }
        val iv = ImageView(this).apply { setImageBitmap(iconFor(app, dp(iconDp))) }
        cell.addView(iv, LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)))
        if (label) {
            cell.addView(TextView(this).apply {
                text = app.label
                textSize = 11f
                maxLines = 1
                gravity = Gravity.CENTER
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(Color.WHITE)
                softShadow()
            }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(6); marginStart = dp(2); marginEnd = dp(2) })
        }
        cell.setOnClickListener { launch(app, iv) }
        cell.setOnLongClickListener { showAppMenu(iv, app); true }
        return cell
    }

    private fun buildDots(n: Int) {
        dotsRow.removeAllViews()
        repeat(n) {
            val dot = View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
                alpha = 0.4f
            }
            dotsRow.addView(dot, LinearLayout.LayoutParams(dp(7), dp(7)).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        updateDots((scroller.scrollX + screenW / 2) / screenW)
    }

    private fun updateDots(sel: Int) {
        for (i in 0 until dotsRow.childCount) dotsRow.getChildAt(i).alpha = if (i == sel) 1f else 0.4f
    }

    // ---------------------------------------------------------------- menus

    private fun showAppMenu(anchor: View, app: AppEntry) {
        PopupMenu(this, anchor).apply {
            menu.add(0, 1, 0, "Info aplikasi")
            menu.add(0, 2, 1, "Copot pemasangan")
            setOnMenuItemClickListener {
                val uri = Uri.parse("package:${app.pkg}")
                when (it.itemId) {
                    1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                    2 -> startActivity(Intent(Intent.ACTION_DELETE, uri))
                }
                true
            }
            show()
        }
    }

    private fun overlayEnabled() = Settings.canDrawOverlays(this) && prefs.getBoolean("overlay_enabled", true)

    private fun showHomeMenu() {
        val items = arrayOf(
            "Pilih wallpaper dari Galeri",
            "Hapus wallpaper foto",
            "Pilih foto widget",
            "Pengaturan tampilan",
            if (overlayEnabled()) "Matikan Dynamic Island di semua aplikasi"
            else "Aktifkan Dynamic Island di semua aplikasi",
            "Geser Dynamic Island ke bawah",
            "Geser Dynamic Island ke atas",
            "Pengaturan Android"
        )
        AlertDialog.Builder(this)
            .setTitle("rzkylauncher")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> openImagePicker(REQUEST_WALLPAPER)
                    1 -> {
                        prefs.edit().remove("wallpaper_uri").apply()
                        root.background = null
                    }
                    2 -> openImagePicker(REQUEST_PHOTO_WIDGET)
                    3 -> showDisplaySettings()
                    4 -> toggleOverlay()
                    5 -> moveIsland(4)
                    6 -> moveIsland(-4)
                    7 -> startActivity(Intent(Settings.ACTION_SETTINGS))
                }
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun openImagePicker(request: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, request)
        } catch (_: Exception) {
            Toast.makeText(this, "Galeri tidak tersedia di perangkat ini", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Dipakai untuk kompatibilitas pemilih gambar Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {}
        when (requestCode) {
            REQUEST_WALLPAPER -> {
                prefs.edit().putString("wallpaper_uri", uri.toString()).apply()
                applyWallpaper(uri)
                Toast.makeText(this, "Wallpaper rzkylauncher diperbarui", Toast.LENGTH_SHORT).show()
            }
            REQUEST_PHOTO_WIDGET -> {
                prefs.edit().putString("photo_widget_uri", uri.toString()).apply()
                rebuild()
                Toast.makeText(this, "Foto widget diperbarui", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun applySavedWallpaper() {
        prefs.getString("wallpaper_uri", null)?.let {
            try { applyWallpaper(Uri.parse(it)) } catch (_: Exception) {}
        }
    }

    private fun applyWallpaper(uri: Uri) {
        val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        if (bitmap != null) {
            val targetW = resources.displayMetrics.widthPixels
            val targetH = resources.displayMetrics.heightPixels
            val scale = maxOf(targetW.toFloat() / bitmap.width, targetH.toFloat() / bitmap.height)
            val cropW = (targetW / scale).toInt().coerceAtMost(bitmap.width)
            val cropH = (targetH / scale).toInt().coerceAtMost(bitmap.height)
            val cropped = Bitmap.createBitmap(
                bitmap,
                ((bitmap.width - cropW) / 2).coerceAtLeast(0),
                ((bitmap.height - cropH) / 2).coerceAtLeast(0),
                cropW.coerceAtLeast(1),
                cropH.coerceAtLeast(1)
            )
            root.background = BitmapDrawable(resources, Bitmap.createScaledBitmap(cropped, targetW, targetH, true))
        }
    }

    private fun showDisplaySettings() {
        val modes = arrayOf("Lite · animasi dan efek minimal", "Seimbang · rekomendasi", "Full · efek visual maksimal")
        val current = prefs.getInt("performance_mode", 1).coerceIn(0, 2)
        AlertDialog.Builder(this)
            .setTitle("Mode performa")
            .setSingleChoiceItems(modes, current) { dialog, which ->
                prefs.edit().putInt("performance_mode", which).apply()
                dialog.dismiss()
                Toast.makeText(this, "Mode ${listOf("Lite", "Seimbang", "Full")[which]} dipilih", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Ukuran ikon") { _, _ -> showIconSizeSettings() }
            .setNegativeButton("Selesai", null)
            .show()
    }

    private fun showIconSizeSettings() {
        val sizes = arrayOf("Kecil · 52 dp", "Normal · 60 dp", "Besar · 68 dp")
        val values = intArrayOf(52, 60, 68)
        val current = prefs.getInt("icon_size", 60)
        val selected = values.indexOf(current).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("Ukuran ikon")
            .setSingleChoiceItems(sizes, selected) { dialog, which ->
                prefs.edit().putInt("icon_size", values[which]).apply()
                iconCache.clear()
                rebuild()
                dialog.dismiss()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    companion object {
        private const val REQUEST_WALLPAPER = 7101
        private const val REQUEST_PHOTO_WIDGET = 7102
    }

    // --------------------------------------------------------------- island

    private fun islandY() = prefs.getInt("y", 12)

    private fun applyIslandPosition() {
        (island.layoutParams as FrameLayout.LayoutParams).topMargin = dp(islandY())
        island.requestLayout()
    }

    private fun moveIsland(deltaDp: Int) {
        prefs.edit().putInt("y", (islandY() + deltaDp).coerceIn(0, 60)).apply()
        applyIslandPosition()
        IslandOverlayService.refresh(this)
    }

    private fun applyIslandMode() {
        if (overlayEnabled()) {
            IslandOverlayService.start(this)
            island.visibility = View.GONE
        } else {
            stopService(Intent(this, IslandOverlayService::class.java))
            island.visibility = View.VISIBLE
        }
    }

    private fun toggleOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.island_overlay_perm, Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        prefs.edit().putBoolean("overlay_enabled", !prefs.getBoolean("overlay_enabled", true)).apply()
        applyIslandMode()
    }

    private fun askOverlayPermissionOnce() {
        if (Settings.canDrawOverlays(this) || prefs.getBoolean("asked", false)) return
        prefs.edit().putBoolean("asked", true).apply()
        AlertDialog.Builder(this)
            .setTitle("Dynamic Island")
            .setMessage(R.string.island_overlay_perm)
            .setPositiveButton("Aktifkan") { _, _ ->
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            .setNegativeButton("Nanti", null)
            .show()
    }
}
