# rzkylauncher — iOS-inspired Android launcher

Project Android native berbasis Kotlin. Minimum Android 11, compile/target SDK 34.

## Fitur dalam source ini
- Home screen multi-halaman, dock, pencarian aplikasi, dan App Library berbasis kategori.
- Widget jam/tanggal/baterai dan foto pilihan dari galeri.
- Wallpaper home dari galeri dengan URI permission persisten.
- Ukuran ikon dan mode performa Lite/Seimbang/Full.
- Pilihan warna aksen untuk panel kaca.
- Control Center berupa pintasan ke halaman pengaturan sistem Wi-Fi, Bluetooth, layar, suara, baterai, dan pengaturan perangkat.
- Dynamic Island overlay untuk status baterai/charging; berjalan sebagai service terpisah dari Activity dan memakai `START_STICKY`.

## Menjadikan rzkylauncher sebagai launcher default
1. Install APK.
2. Tekan tombol Home.
3. Pilih `rzkylauncher`, lalu pilih `Selalu` / `Always`.
4. Izinkan `Tampil di atas aplikasi lain` jika ingin Dynamic Island muncul di atas Spotify dan aplikasi lain.

Android memang menampilkan Spotify/aplikasi lain di depan launcher saat dibuka. Itu perilaku normal launcher; tekan Home untuk kembali ke rzkylauncher. Dynamic Island overlay dijalankan oleh service terpisah dan tidak bergantung pada Activity launcher tetap terbuka. Ketahanan service tetap dapat dipengaruhi penghemat baterai/vendor Android.

## Build
Gunakan JDK 17 dan jalankan:

```bash
./gradlew assembleDebug
```

APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

Catatan: Control Center membuka halaman pengaturan resmi Android. Android membatasi aplikasi pihak ketiga untuk mengubah langsung beberapa toggle sistem seperti Wi-Fi/Bluetooth tanpa interaksi/izin sistem.
