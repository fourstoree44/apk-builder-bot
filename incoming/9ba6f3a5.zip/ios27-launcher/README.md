# iOS 27 Launcher (Android)

Project Android native Kotlin, minimum Android 11 (API 30), compile/target SDK 35.

## Fitur yang sudah ada
- Bisa dipilih sebagai aplikasi Home/launcher default Android.
- Home screen bergaya iOS dengan jam, panel widget cuaca demo, grid aplikasi, dan dock.
- App Library dengan pencarian dan daftar aplikasi terpasang.
- Dynamic Island demo yang membuka menu musik/timer/baterai/pengaturan.
- Pengaturan mode Lite/Seimbang/Full (preferensi mode tersimpan), pemilih wallpaper Android, dan shortcut pengaturan Home.
- Membuka aplikasi langsung dari ikon.

## Batasan versi awal
Dynamic Island belum membaca notifikasi/media secara real-time; widget cuaca masih placeholder; Lock Screen, Control Center sistem, AssistiveTouch overlay, backup/import tema, dan efek depth wallpaper belum diimplementasikan. Android membatasi penggantian lock screen, panel notifikasi, dan kontrol sistem oleh launcher biasa. Fitur tersebut memerlukan implementasi serta izin/komponen terpisah.

## Build
Buka project di Android Studio, atau jalankan `gradle assembleDebug` dengan Android SDK 35 terpasang. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.
