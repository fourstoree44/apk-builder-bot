plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.four.ios27launcher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.four.ios27launcher"
        minSdk = 30
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
