package com.four.ios27launcher

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LauncherActivity : Activity() {
    private val bg = Color.rgb(19, 28, 52)
    private val white = Color.WHITE
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var drawerOpen = false
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(17, 25, 46)
        window.navigationBarColor = Color.rgb(17, 25, 46)
        window.decorView.systemUiVisibility = 0
        showHome()
    }

    private fun rounded(color: Int, radius: Float = 24f, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius; if (stroke != 0) setStroke(1, stroke) }

    private fun text(value: String, size: Float, color: Int = white, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setShadowLayer(5f, 0f, 2f, Color.argb(70, 0, 0, 0))
        }

    private fun pad(v: View, l: Int, t: Int, r: Int, b: Int) { v.setPadding(l, t, r, b) }
    private fun lp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h, weight)

    private fun base(): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(30, 48, 91), Color.rgb(72, 76, 139), Color.rgb(21, 34, 65)))
            setPadding(18, 12, 18, 14)
        }
        setContentView(root)
        return root
    }

    private fun showHome() {
        drawerOpen = false
        base()
        val status = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        status.addView(text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), 14f, white, true), lp(0, 28, 1f))
        status.addView(text("●  ▮  Wi-Fi  ▰", 12f), lp(-2, 28))
        root.addView(status)

        val island = TextView(this).apply {
            text = "●     iOS 27     ◖  ◗"
            textSize = 12f; setTextColor(white); gravity = Gravity.CENTER
            background = rounded(Color.BLACK, 40f)
            setPadding(22, 10, 22, 10)
            setOnClickListener { showIslandPanel() }
        }
        root.addView(island, LinearLayout.LayoutParams(-2, 42).apply { gravity = Gravity.CENTER; topMargin = 5 })

        val date = SimpleDateFormat("EEEE, d MMMM", Locale("id", "ID")).format(Date())
        root.addView(text(date.replaceFirstChar { it.uppercase() }, 15f, Color.argb(220,255,255,255)), lp(-1, 30).apply { topMargin = 20 })
        root.addView(text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), 58f, white, false), lp(-1, 72))

        val weather = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            background = rounded(Color.argb(62, 255, 255, 255), 26f, Color.argb(70,255,255,255))
            setPadding(18, 12, 18, 12)
        }
        weather.addView(text("☀️  Cuaca cerah", 17f, white, true))
        weather.addView(text("Widget cuaca • Tambahkan lokasi di pengaturan", 11f, Color.argb(220,255,255,255)))
        root.addView(weather, lp(-1, 78).apply { topMargin = 16 })

        val scroll = ScrollView(this).apply { clipToPadding = false }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 16, 0, 8) }
        scroll.addView(content)
        root.addView(scroll, lp(-1, 0, 1f))
        addAppGrid(content, 8)

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            background = rounded(Color.argb(85, 235, 242, 255), 30f, Color.argb(80,255,255,255))
            setPadding(8, 9, 8, 9)
        }
        val favorites = listOf("Telepon" to "☎️", "Pesan" to "💬", "Chrome" to "🌐", "Kamera" to "📷")
        favorites.forEach { (name, emoji) -> dock.addView(appShortcut(name, emoji, true), LinearLayout.LayoutParams(0, 62, 1f)) }
        root.addView(dock, lp(-1, 78).apply { topMargin = 8 })
        val bottom = text("⌃   Geser ke atas untuk App Library      ◉", 11f, Color.argb(220,255,255,255))
        bottom.setOnClickListener { showDrawer() }
        root.addView(bottom, lp(-1, 28))
        root.setOnTouchListener(object : View.OnTouchListener {
            var y = 0f
            override fun onTouch(v: View?, e: android.view.MotionEvent): Boolean {
                if (e.action == android.view.MotionEvent.ACTION_DOWN) y = e.y
                if (e.action == android.view.MotionEvent.ACTION_UP && y - e.y > 80) { showDrawer(); return true }
                return true
            }
        })
    }

    private fun addAppGrid(parent: LinearLayout, maxRows: Int) {
        val apps = loadApps().take(24)
        val grid = android.widget.GridLayout(this).apply { columnCount = 4; rowCount = maxRows; useDefaultMargins = false }
        apps.forEach { app ->
            val item = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(2, 6, 2, 8) }
            val icon = ImageView(this).apply { setImageDrawable(app.loadIcon(packageManager)); scaleType = ImageView.ScaleType.FIT_CENTER }
            item.addView(icon, LinearLayout.LayoutParams(56, 56))
            item.addView(text(app.loadLabel(packageManager).toString().take(13), 10f, white), lp(-1, 24))
            item.setOnClickListener { launch(app.activityInfo.packageName) }
            grid.addView(item, android.widget.GridLayout.LayoutParams().apply {
                width = 0; height = ViewGroup.LayoutParams.WRAP_CONTENT; columnSpec = android.widget.GridLayout.spec(android.widget.GridLayout.UNDEFINED, 1f)
            })
        }
        parent.addView(grid)
    }

    private fun appShortcut(name: String, emoji: String, dock: Boolean = false): View {
        val v = TextView(this).apply {
            text = emoji; textSize = 28f; gravity = Gravity.CENTER
            setOnClickListener { val found = loadApps().firstOrNull { it.loadLabel(packageManager).toString().contains(name, true) }; if (found != null) launch(found.activityInfo.packageName) else showToast("Aplikasi $name tidak ditemukan") }
        }
        return v
    }

    private fun loadApps(): List<android.content.pm.ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }
    }

    private fun launch(pkg: String) { try { startActivity(packageManager.getLaunchIntentForPackage(pkg)) } catch (_: Exception) { showToast("Tidak bisa membuka aplikasi") } }

    private fun showDrawer() {
        drawerOpen = true
        base()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(text("App Library", 28f, white, true), lp(0, 54, 1f))
        val close = text("✕", 22f); close.setOnClickListener { showHome() }; header.addView(close, lp(42, 48))
        root.addView(header)
        val search = EditText(this).apply {
            hint = "Cari aplikasi"; setSingleLine(); textSize = 15f; setTextColor(white); setHintTextColor(Color.LTGRAY)
            background = rounded(Color.argb(65,255,255,255), 24f); setPadding(16, 4, 16, 4)
        }
        root.addView(search, lp(-1, 48).apply { topMargin = 12 })
        val scroll = ScrollView(this); val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 12) }
        scroll.addView(list); root.addView(scroll, lp(-1, 0, 1f))
        fun populate(q: String) {
            list.removeAllViews()
            loadApps().filter { it.loadLabel(packageManager).toString().contains(q, true) }.forEach { app ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(8, 8, 8, 8) }
                val image = ImageView(this).apply { setImageDrawable(app.loadIcon(packageManager)) }
                row.addView(image, lp(42, 42)); row.addView(text(app.loadLabel(packageManager).toString(), 16f, white), lp(0, 48, 1f))
                row.setOnClickListener { launch(app.activityInfo.packageName) }; list.addView(row)
            }
        }
        populate("")
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { populate(s?.toString() ?: "") }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
    }

    private fun showIslandPanel() {
        val items = arrayOf("Musik", "Timer", "Baterai", "Pengaturan launcher")
        AlertDialog.Builder(this).setTitle("Dynamic Island").setItems(items) { _, which ->
            when (which) {
                0 -> showToast("Kontrol musik akan tampil saat sesi media aktif")
                1 -> startActivity(Intent(android.provider.AlarmClock.ACTION_SET_TIMER))
                2 -> showToast("Baterai: ${getBatteryLevel()}%")
                3 -> showSettings()
            }
        }.show()
    }

    private fun getBatteryLevel(): Int {
        val i = registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra("level", 0) ?: 0; val scale = i?.getIntExtra("scale", 100) ?: 100
        return if (scale > 0) level * 100 / scale else level
    }

    private fun showSettings() {
        val choices = arrayOf("Mode Lite", "Mode Seimbang", "Mode Full", "Pilih wallpaper", "Atur launcher default", "Info & izin")
        AlertDialog.Builder(this).setTitle("Pengaturan Launcher").setItems(choices) { _, which ->
            when (which) {
                0, 1, 2 -> { prefs.edit().putInt("mode", which).apply(); showToast("Mode ${choices[which]} aktif") }
                3 -> chooseWallpaper()
                4 -> startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                5 -> showInfo()
            }
        }.show()
    }

    private fun chooseWallpaper() {
        val intent = Intent(Intent.ACTION_SET_WALLPAPER)
        try { startActivity(Intent.createChooser(intent, "Pilih wallpaper")) } catch (_: Exception) { showToast("Fitur wallpaper tidak tersedia") }
    }

    private fun showInfo() {
        AlertDialog.Builder(this).setTitle("iOS 27 Launcher")
            .setMessage("Launcher Android bergaya iOS. App Library, pencarian aplikasi, Dynamic Island demo, widget jam/cuaca demo, dan mode performa. Beberapa fitur sistem memerlukan izin Android dan belum menggantikan lock screen atau panel notifikasi bawaan.")
            .setPositiveButton("Mengerti", null).show()
    }

    private fun showToast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    override fun onBackPressed() { if (drawerOpen) showHome() else super.onBackPressed() }
}
