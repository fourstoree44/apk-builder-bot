# iOS 27 Launcher (Android 11+)

Launcher bergaya iPhone untuk Android 11 (API 30) ke atas, lengkap dengan Dynamic Island.

## Fitur
- Layar utama ala iOS: grid 4 kolom, label ikon, titik halaman, ikon squircle (semua ikon diseragamkan bentuknya)
- Widget jam, tanggal, dan baterai di halaman pertama
- Dock 4 aplikasi (Telepon, Pesan, Browser, Kamera, otomatis dari aplikasi default HP)
- App Library: aplikasi dikelompokkan per kategori, ketuk kartu untuk lihat isinya
- Pencarian aplikasi (tombol Search di atas dock atau di App Library)
- Tekan lama ikon: Info aplikasi, Copot pemasangan
- Tekan lama area kosong: ganti wallpaper, atur Dynamic Island
- Animasi zoom saat membuka aplikasi

## Dynamic Island
- Pill hitam di atas layar, ketuk untuk membuka jadi lebar (jam, tanggal, cincin baterai), ketuk lagi untuk menutup
- Muncul sebentar dalam mode compact saat charger dicolok atau dicabut
- Mode "semua aplikasi": butuh izin "Tampil di atas aplikasi lain". Launcher akan menawarkannya saat pertama dibuka
- Tanpa izin itu, island hanya tampil di dalam launcher
- Posisi bisa digeser naik/turun (tekan lama area kosong) supaya pas dengan lubang kamera HP kamu

## Cara build APK
Butuh Android Studio (Koala atau lebih baru) atau JDK 17 + Android SDK (platform 34).

Android Studio: File > Open > pilih folder ini > tunggu sync > Build > Build APK(s).

Terminal:

    ./gradlew assembleDebug

APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Pasang dan jadikan launcher default
1. Pindahkan APK ke HP, buka, izinkan install dari sumber ini.
2. Buka aplikasi "iOS 27 Launcher" sekali.
3. Tekan tombol Home, pilih "iOS 27 Launcher" lalu "Selalu".
   Atau: Pengaturan > Aplikasi > Aplikasi default > Aplikasi layar utama.
4. Untuk kembali ke launcher lama, pilih lagi di pengaturan yang sama.

## Catatan
- Beberapa HP (Xiaomi, Oppo, Vivo, Samsung) mematikan service di latar belakang. Kalau island hilang di aplikasi lain, kunci launcher ini di Recent Apps dan matikan optimasi baterai untuknya.
- Island ditampilkan di atas status bar sistem, jadi menutupi bagian tengah status bar saja.
