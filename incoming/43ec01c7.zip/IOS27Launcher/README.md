# iOS 27 Launcher (Android 11+)

Launcher bergaya iPhone dengan tema Liquid Glass, Dynamic Island, dan Control Center, untuk Android 11 (API 30) ke atas.

## Fitur
- Tema Liquid Glass: panel kaca gelap, tepi bercahaya, ikon ubin kaca
- Widget Calendar dan Batteries (cincin persen) di halaman pertama
- Status bar ala iOS di layar utama (jam kiri, baterai kanan, island di tengah)
- Grid bisa diatur: kolom, baris, margin, posisi vertikal, ukuran dan bentuk ikon
- Dock 4 aplikasi dari aplikasi default HP
- App Library daftar A-Z dengan indeks huruf di kanan, atau tampilan kategori
- Pencarian aplikasi, dibuka lewat tombol Search atau geser ke bawah di layar utama
- Tekan lama ikon: Info aplikasi, Copot pemasangan. Tekan lama area kosong: menu launcher
- Pengaturan ala iOS: General, Island, Control, Screen Grid, Glass & Blur, Icons

## Dynamic Island
- Ketuk untuk melebar, ketuk lagi untuk menutup
- Lagu yang diputar (Spotify, YouTube Music, dsb): cover, equalizer, judul, progress, tombol sebelumnya/putar/berikutnya
- Hotspot: titik hijau di kapsul selama hotspot menyala, dan info "Hotspot ON" saat berubah
- Charger dicolok atau dicabut: jam dan baterai muncul sebentar
- Tampil di semua aplikasi bila izin "Tampil di atas aplikasi lain" diberikan, kalau tidak hanya di launcher

## Control Center
Geser ke bawah dari pojok kanan atas layar utama, atau ketuk angka baterai di status bar.
- Senter: nyala dan mati langsung
- Kecerahan dan volume: slider langsung
- Kartu lagu dengan kontrol
- Pesawat, Data, Wi-Fi, Bluetooth, Hotspot: menampilkan status dan membuka panel sistem untuk mengubahnya
- Pintasan Kamera, Kalkulator, Pengaturan, Cari

Android tidak mengizinkan aplikasi biasa menyalakan Wi-Fi, data, atau Bluetooth secara langsung, itu sebabnya tombolnya membuka panel sistem.

## Yang tidak bisa diubah launcher
Status bar sistem, panel notifikasi bawaan HP, dan layar kunci milik sistem Android dan tidak bisa diganti oleh launcher. Yang dilakukan launcher ini: menyembunyikan status bar sistem di layar utama (diganti status bar iOS), dan menyediakan Control Center sendiri. Di dalam aplikasi lain, status bar dan panel bawaan HP tetap tampil. Menggesernya dari tepi atas layar memunculkan status bar sistem sebentar.

## Izin yang diminta
- Tampil di atas aplikasi lain: Dynamic Island di semua aplikasi
- Akses notifikasi: membaca judul dan cover lagu yang sedang diputar, tidak membaca isi notifikasi
- Ubah pengaturan sistem: kecerahan di Control Center berlaku di semua aplikasi

## Cara build APK
Android Studio (Koala atau lebih baru): File > Open > pilih folder ini > tunggu sync > Build > Build APK(s).

Terminal (JDK 17 + Android SDK platform 34):

    ./gradlew assembleDebug

APK ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Jadikan launcher default
1. Install APK, lalu buka sekali. Ikon "Launcher" membuka Pengaturan.
2. Tekan tombol Home, pilih "iOS 27 Launcher", lalu "Selalu".
   Atau: Pengaturan HP > Aplikasi > Aplikasi default > Aplikasi layar utama.

## Kalau terasa berat
- Matikan Blur effect (Pengaturan > Glass & Blur)
- Matikan Highlight follows tilt (sudah mati secara bawaan)
- Kurangi Refraction

## Catatan
- Beberapa HP (Xiaomi, Oppo, Vivo, Samsung) mematikan service di latar belakang. Kunci launcher di Recent Apps dan matikan optimasi baterainya supaya island tetap muncul di aplikasi lain.
- Deteksi hotspot memakai siaran sistem yang tidak resmi, jadi di sebagian HP mungkin tidak terbaca.
- Belum ada: pilihan bahasa, widget cuaca, icon pack pihak ketiga.
- Kode belum pernah dikompilasi di sini. Kalau build gagal, kirim pesan errornya.
