package com.ios27.launcher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import android.view.animation.OvershootInterpolator
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sin

/**
 * Pill hitam ala Dynamic Island.
 * Ukuran view = ukuran pill saat ini, jadi sentuhan di luar pill tidak ditahan
 * (penting buat overlay di atas aplikasi lain).
 *
 * Isi pill, urutan prioritas: info sesaat (charger / hotspot) > lagu yang diputar > jam dan baterai.
 */
class DynamicIslandView(context: Context) : View(context) {

    enum class State { COLLAPSED, COMPACT, EXPANDED }
    enum class Pulse { CHARGE, HOTSPOT }

    private val d = resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())

    private val wCollapsed = 126 * d
    private val hCollapsed = 36 * d
    private val wCompact = 214 * d
    private val hCompact = 36 * d
    private val wExpanded = 352 * d
    private fun hExpanded() = if (media != null) 172 * d else 148 * d

    private var curW = wCollapsed
    private var curH = hCollapsed
    private var contentAlpha = 0f
    var state = State.COLLAPSED
        private set

    var batteryLevel = 100
        set(v) { field = v.coerceIn(0, 100); invalidate() }
    var charging = false
        set(v) { field = v; invalidate() }
    var hotspot = false
        set(v) { field = v; invalidate() }

    private var media: MediaWatcher.Info? = null
    private var pulseKind: Pulse? = null

    private val green = Color.parseColor("#30D158")
    private val grey = Color.parseColor("#8E8E93")

    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val lensPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#14161A") }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val ringBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 6 * d; color = Color.parseColor("#2C2C2E")
        strokeCap = Paint.Cap.ROUND
    }
    private val ringFg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 6 * d; strokeCap = Paint.Cap.ROUND
    }
    private val rect = RectF()
    private val path = Path()
    private val hhmm = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("EEEE, d MMM", Locale.getDefault())

    private var anim: ValueAnimator? = null

    /** Kembali ke keadaan istirahat: kapsul kecil, atau kapsul lagu kalau musik sedang jalan. */
    private fun restState() = if (media?.playing == true) State.COMPACT else State.COLLAPSED

    private val autoCollapse = Runnable {
        pulseKind = null
        setState(restState(), force = true)
    }

    /** Menggambar ulang pelan saat idle (jam), cepat saat lagu jalan (equalizer dan progress). */
    private val loop = object : Runnable {
        override fun run() {
            invalidate()
            val fast = media?.playing == true && state != State.COLLAPSED
            handler.postDelayed(this, if (fast) 110L else 15_000L)
        }
    }

    init {
        // ukuran island mengikuti slider "Size" di Pengaturan
        val s = Prefs.int(context, Prefs.ISLAND_SCALE) / 100f
        scaleX = s
        scaleY = s
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        handler.post(loop)
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(loop)
        handler.removeCallbacks(autoCollapse)
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        pivotX = w / 2f
        pivotY = 0f
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(curW.toInt(), curH.toInt())
    }

    // ----------------------------------------------------------- data masuk

    fun setMedia(info: MediaWatcher.Info?) {
        val hadMedia = media != null
        media = info
        handler.removeCallbacks(loop)
        handler.post(loop)
        when {
            state == State.EXPANDED -> setState(State.EXPANDED, force = hadMedia != (info != null))
            pulseKind != null -> {}
            else -> setState(restState())
        }
        invalidate()
    }

    /** Tampilkan info sesaat (charger dicolok, hotspot menyala), lalu kembali ke keadaan istirahat. */
    fun pulse(kind: Pulse, durationMs: Long = 2800) {
        if (state == State.EXPANDED) return
        pulseKind = kind
        setState(State.COMPACT, force = true)
        handler.removeCallbacks(autoCollapse)
        handler.postDelayed(autoCollapse, durationMs)
    }

    fun setState(target: State, animate: Boolean = true, force: Boolean = false) {
        if (target == state && animate && !force) return
        state = target
        handler.removeCallbacks(autoCollapse)

        val tw: Float
        val th: Float
        when (target) {
            State.COLLAPSED -> { tw = wCollapsed; th = hCollapsed }
            State.COMPACT -> { tw = wCompact; th = hCompact }
            State.EXPANDED -> { tw = wExpanded; th = hExpanded() }
        }
        val targetAlpha = if (target == State.COLLAPSED) 0f else 1f

        anim?.cancel()
        if (!animate) {
            curW = tw; curH = th; contentAlpha = targetAlpha
            requestLayout(); invalidate()
        } else {
            val fromW = curW; val fromH = curH; val fromA = contentAlpha
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 460
                interpolator = OvershootInterpolator(if (target == State.COLLAPSED) 0.6f else 1.1f)
                addUpdateListener {
                    val p = it.animatedValue as Float
                    curW = fromW + (tw - fromW) * p
                    curH = fromH + (th - fromH) * p
                    contentAlpha = (fromA + (targetAlpha - fromA) * it.animatedFraction).coerceIn(0f, 1f)
                    requestLayout(); invalidate()
                }
                start()
            }
        }
        if (target == State.EXPANDED) {
            handler.postDelayed(autoCollapse, if (media?.playing == true) 8000 else 6000)
        }
        handler.removeCallbacks(loop)
        handler.post(loop)
    }

    // ------------------------------------------------------------- sentuhan

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> return true
            MotionEvent.ACTION_UP -> { onTap(e.x, e.y); performClick() }
        }
        return true
    }

    override fun performClick(): Boolean = super.performClick()

    private fun onTap(x: Float, y: Float) {
        if (state == State.EXPANDED && media != null && y > height - 60 * d) {
            val w = width.toFloat()
            val hit = 34 * d
            when {
                abs(x - w * 0.30f) < hit -> MediaWatcher.previous()
                abs(x - w * 0.50f) < hit -> MediaWatcher.toggle()
                abs(x - w * 0.70f) < hit -> MediaWatcher.next()
                else -> { setState(restState()); return }
            }
            handler.removeCallbacks(autoCollapse)
            handler.postDelayed(autoCollapse, 8000)
            return
        }
        setState(if (state == State.EXPANDED) restState() else State.EXPANDED)
    }

    // --------------------------------------------------------------- gambar

    private fun color(c: Int, a: Int) { text.color = c; text.alpha = a }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = minOf(h / 2f, 40 * d)
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, r, r, bodyPaint)

        if (state != State.EXPANDED) {
            canvas.drawCircle(w - 18 * d, h / 2f, 6 * d, lensPaint)
            // titik hijau kecil di kiri kapsul selama hotspot menyala
            if (hotspot && pulseKind != Pulse.HOTSPOT) {
                fillPaint.color = green
                canvas.drawCircle(18 * d, h / 2f, 3.5f * d, fillPaint)
            }
        }

        val a = (contentAlpha * 255).toInt()
        if (a <= 4) return
        ringBg.alpha = a; ringFg.alpha = a

        val levelColor = when {
            charging -> green
            batteryLevel <= 20 -> Color.parseColor("#FF453A")
            else -> Color.WHITE
        }
        val compactNow = state == State.COMPACT ||
            (state == State.COLLAPSED && curH > hCollapsed + 2 * d)

        when {
            state == State.EXPANDED ->
                if (media != null) drawMediaExpanded(canvas, w, h, a) else drawExpanded(canvas, w, h, levelColor, a)
            compactNow -> when {
                pulseKind == Pulse.HOTSPOT -> drawHotspotCompact(canvas, w, h, a)
                pulseKind == null && media?.playing == true -> drawMediaCompact(canvas, w, h, a)
                else -> drawClockCompact(canvas, w, h, levelColor, a)
            }
        }
    }

    private fun baseline(h: Float, size: Float): Float {
        text.textSize = size
        return h / 2f - (text.descent() + text.ascent()) / 2f
    }

    private fun drawClockCompact(c: Canvas, w: Float, h: Float, levelColor: Int, a: Int) {
        val base = baseline(h, 14 * d)
        text.textAlign = Paint.Align.LEFT
        color(Color.WHITE, a)
        c.drawText(hhmm.format(Date()), 18 * d, base, text)
        text.textAlign = Paint.Align.RIGHT
        color(levelColor, a)
        c.drawText((if (charging) "⚡" else "") + "$batteryLevel%", w - 38 * d, base, text)
        text.textAlign = Paint.Align.LEFT
    }

    private fun drawHotspotCompact(c: Canvas, w: Float, h: Float, a: Int) {
        val pulse = 0.5f + 0.5f * sin(SystemClock.uptimeMillis() / 220.0).toFloat()
        fillPaint.color = Color.argb((a * 0.35f * pulse).toInt(), 48, 209, 88)
        c.drawCircle(22 * d, h / 2f, 10 * d, fillPaint)
        fillPaint.color = Color.argb(a, 48, 209, 88)
        c.drawCircle(22 * d, h / 2f, 5 * d, fillPaint)
        val base = baseline(h, 14 * d)
        text.textAlign = Paint.Align.LEFT
        color(Color.WHITE, a)
        c.drawText("Hotspot", 42 * d, base, text)
        text.textAlign = Paint.Align.RIGHT
        color(green, a)
        c.drawText("ON", w - 38 * d, base, text)
        text.textAlign = Paint.Align.LEFT
    }

    private fun drawArt(c: Canvas, art: Bitmap?, x: Float, y: Float, size: Float, radius: Float, a: Int) {
        rect.set(x, y, x + size, y + size)
        if (art == null) {
            fillPaint.color = Color.argb(a, 58, 58, 62)
            c.drawRoundRect(rect, radius, radius, fillPaint)
            color(Color.argb(a, 174, 174, 178), a)
            text.textAlign = Paint.Align.CENTER
            text.textSize = size * 0.5f
            c.drawText("♪", x + size / 2f, y + size * 0.68f, text)
            text.textAlign = Paint.Align.LEFT
            return
        }
        c.save()
        path.reset()
        path.addRoundRect(rect, radius, radius, Path.Direction.CW)
        c.clipPath(path)
        fillPaint.alpha = a
        c.drawBitmap(art, null, rect, fillPaint)
        fillPaint.alpha = 255
        c.restore()
    }

    private fun drawMediaCompact(c: Canvas, w: Float, h: Float, a: Int) {
        drawArt(c, media?.art, 9 * d, (h - 24 * d) / 2f, 24 * d, 6 * d, a)
        // equalizer: tiga batang yang bergerak selama lagu jalan
        val t = SystemClock.uptimeMillis() / 170.0
        fillPaint.color = Color.argb(a, 48, 209, 88)
        for (i in 0 until 3) {
            val bh = (6 + 10 * (0.5 + 0.5 * sin(t + i * 1.9))).toFloat() * d
            val x = w - 62 * d + i * 6 * d
            rect.set(x, h / 2f - bh / 2f, x + 3 * d, h / 2f + bh / 2f)
            c.drawRoundRect(rect, 1.5f * d, 1.5f * d, fillPaint)
        }
    }

    private fun drawMediaExpanded(c: Canvas, w: Float, h: Float, a: Int) {
        val m = media ?: return
        drawArt(c, m.art, 20 * d, 20 * d, 64 * d, 14 * d, a)

        val tx = 98 * d
        val maxW = w - tx - 22 * d
        text.textAlign = Paint.Align.LEFT
        text.textSize = 17 * d
        color(Color.WHITE, a)
        c.drawText(TextUtils.ellipsize(m.title, text, maxW, TextUtils.TruncateAt.END).toString(), tx, 46 * d, text)
        text.textSize = 14 * d
        color(grey, a)
        c.drawText(TextUtils.ellipsize(m.artist, text, maxW, TextUtils.TruncateAt.END).toString(), tx, 68 * d, text)

        // progress
        val left = 22 * d
        val right = w - 22 * d
        val y = 108 * d
        fillPaint.color = Color.argb((a * 0.25f).toInt(), 255, 255, 255)
        rect.set(left, y, right, y + 4 * d)
        c.drawRoundRect(rect, 2 * d, 2 * d, fillPaint)
        if (m.duration > 0) {
            val elapsed = if (m.playing) (SystemClock.elapsedRealtime() - m.stamp) * m.speed else 0f
            val frac = ((m.position + elapsed) / m.duration).coerceIn(0f, 1f)
            fillPaint.color = Color.argb(a, 255, 255, 255)
            rect.set(left, y, left + (right - left) * frac, y + 4 * d)
            c.drawRoundRect(rect, 2 * d, 2 * d, fillPaint)
        }

        // tombol sebelumnya / putar-jeda / berikutnya
        val cy = h - 32 * d
        fillPaint.color = Color.argb(a, 255, 255, 255)
        skip(c, w * 0.30f, cy, false)
        skip(c, w * 0.70f, cy, true)
        val px = w * 0.5f
        val s = 12 * d
        if (m.playing) {
            rect.set(px - s * 0.8f, cy - s, px - s * 0.2f, cy + s); c.drawRoundRect(rect, d, d, fillPaint)
            rect.set(px + s * 0.2f, cy - s, px + s * 0.8f, cy + s); c.drawRoundRect(rect, d, d, fillPaint)
        } else {
            path.reset()
            path.moveTo(px - s * 0.7f, cy - s); path.lineTo(px - s * 0.7f, cy + s); path.lineTo(px + s, cy)
            path.close()
            c.drawPath(path, fillPaint)
        }
    }

    /** Ikon lompat lagu: batang tipis dan segitiga, [forward] = ke lagu berikutnya. */
    private fun skip(c: Canvas, x: Float, y: Float, forward: Boolean) {
        val s = 10 * d
        val bar = 2.5f * d
        path.reset()
        if (forward) {
            path.moveTo(x - s, y - s); path.lineTo(x - s, y + s); path.lineTo(x + s - bar, y)
            path.close(); c.drawPath(path, fillPaint)
            rect.set(x + s - bar, y - s, x + s, y + s)
        } else {
            path.moveTo(x + s, y - s); path.lineTo(x + s, y + s); path.lineTo(x - s + bar, y)
            path.close(); c.drawPath(path, fillPaint)
            rect.set(x - s, y - s, x - s + bar, y + s)
        }
        c.drawRoundRect(rect, d, d, fillPaint)
    }

    private fun drawExpanded(c: Canvas, w: Float, h: Float, levelColor: Int, a: Int) {
        val pad = 24 * d
        text.textAlign = Paint.Align.LEFT
        text.textSize = 38 * d
        color(Color.WHITE, a)
        c.drawText(hhmm.format(Date()), pad, 62 * d, text)

        text.textSize = 14 * d
        color(grey, a)
        c.drawText(dateFmt.format(Date()), pad, 88 * d, text)

        val size = 64 * d
        val left = w - pad - size
        val top = 30 * d
        rect.set(left, top, left + size, top + size)
        c.drawArc(rect, 0f, 360f, false, ringBg)
        ringFg.color = levelColor; ringFg.alpha = a
        c.drawArc(rect, -90f, 360f * batteryLevel / 100f, false, ringFg)

        text.textSize = 15 * d
        text.textAlign = Paint.Align.CENTER
        color(Color.WHITE, a)
        val cy = top + size / 2f - (text.descent() + text.ascent()) / 2f
        c.drawText("$batteryLevel", left + size / 2f, cy, text)
        text.textAlign = Paint.Align.LEFT

        text.textSize = 13 * d
        val hot = hotspot
        color(if (hot || charging) green else grey, a)
        val status = when {
            hot && charging -> "Hotspot aktif · mengisi daya"
            hot -> "Hotspot aktif"
            charging -> "Sedang mengisi daya"
            else -> "Baterai"
        }
        c.drawText(status, pad, h - 24 * d, text)
    }
}
