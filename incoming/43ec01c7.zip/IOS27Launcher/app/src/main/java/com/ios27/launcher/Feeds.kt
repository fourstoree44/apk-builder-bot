package com.ios27.launcher

import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/**
 * Layanan kosong. Android hanya mengizinkan aplikasi membaca sesi media aktif kalau
 * aplikasi itu punya listener notifikasi yang diberi akses oleh pengguna.
 */
class MediaListenerService : NotificationListenerService()

/** Membaca lagu yang sedang diputar (Spotify, YouTube Music, dsb) dari sesi media sistem. */
object MediaWatcher {

    data class Info(
        val title: String,
        val artist: String,
        val art: Bitmap?,
        val playing: Boolean,
        val duration: Long,
        val position: Long,
        val stamp: Long,     // SystemClock.elapsedRealtime saat position diambil
        val speed: Float
    )

    private val handler = Handler(Looper.getMainLooper())
    private val listeners = ArrayList<(Info?) -> Unit>()
    private var appCtx: Context? = null
    private var manager: MediaSessionManager? = null
    private var component: ComponentName? = null
    private var sessionListener: MediaSessionManager.OnActiveSessionsChangedListener? = null
    private var current: MediaController? = null
    private var started = false
    private var lastArtSrc: Bitmap? = null
    private var lastArtOut: Bitmap? = null

    var info: Info? = null
        private set

    fun isAccessGranted(ctx: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { repick() }
        override fun onMetadataChanged(metadata: MediaMetadata?) { rebuild() }
        override fun onSessionDestroyed() { repick() }
    }

    fun addListener(ctx: Context, l: (Info?) -> Unit) {
        appCtx = ctx.applicationContext
        listeners += l
        ensureStarted(ctx)
        l(info)
    }

    fun removeListener(l: (Info?) -> Unit) {
        listeners -= l
        if (listeners.isEmpty()) stop()
    }

    /** Dipanggil lagi saat layar kembali aktif, siapa tahu akses notifikasi baru saja diberikan. */
    fun ensureStarted(ctx: Context) {
        if (started || listeners.isEmpty() || !isAccessGranted(ctx)) return
        try {
            val app = ctx.applicationContext
            val m = app.getSystemService(MediaSessionManager::class.java)
            val cn = ComponentName(app, MediaListenerService::class.java)
            val l = MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }
            m.addOnActiveSessionsChangedListener(l, cn, handler)
            manager = m; component = cn; sessionListener = l; started = true
            pick(m.getActiveSessions(cn))
        } catch (_: SecurityException) {
            started = false
        }
    }

    private fun stop() {
        try { sessionListener?.let { manager?.removeOnActiveSessionsChangedListener(it) } } catch (_: Exception) {}
        try { current?.unregisterCallback(callback) } catch (_: Exception) {}
        sessionListener = null; current = null; started = false; info = null
    }

    private fun repick() {
        try { pick(manager?.getActiveSessions(component)) } catch (_: Exception) { rebuild() }
    }

    private fun pick(list: List<MediaController>?) {
        val all = list.orEmpty()
        val chosen = all.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: all.firstOrNull()
        if (chosen?.sessionToken != current?.sessionToken) {
            try { current?.unregisterCallback(callback) } catch (_: Exception) {}
            current = chosen
            chosen?.registerCallback(callback, handler)
        }
        rebuild()
    }

    private fun rebuild() {
        val c = current
        val md = c?.metadata
        val st = c?.playbackState
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        info = if (c == null || md == null || title.isBlank()) null else {
            val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                ?: md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
            val src = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            if (src !== lastArtSrc) {
                lastArtSrc = src
                lastArtOut = src?.let {
                    if (it.width > 160) Bitmap.createScaledBitmap(it, 160, 160 * it.height / it.width, true) else it
                }
            }
            val state = st?.state
            Info(
                title = title,
                artist = artist,
                art = lastArtOut,
                playing = state == PlaybackState.STATE_PLAYING || state == PlaybackState.STATE_BUFFERING,
                duration = md.getLong(MediaMetadata.METADATA_KEY_DURATION),
                position = st?.position ?: 0L,
                stamp = st?.lastPositionUpdateTime ?: SystemClock.elapsedRealtime(),
                speed = st?.playbackSpeed ?: 1f
            )
        }
        listeners.toList().forEach { it(info) }
    }

    fun previous() { current?.transportControls?.skipToPrevious() }
    fun next() { current?.transportControls?.skipToNext() }
    fun toggle() {
        val i = info ?: return
        if (i.playing) current?.transportControls?.pause() else current?.transportControls?.play()
    }
}

/** Status hotspot terakhir yang diketahui, dibaca juga oleh Control Center. */
object HotspotState {
    @Volatile var on = false
}

/**
 * Menghubungkan island ke sumber datanya: baterai, charger, hotspot, dan lagu.
 * Dipakai oleh island di dalam launcher maupun island overlay.
 */
class IslandFeeds(private val ctx: Context, private val island: DynamicIslandView) {

    private var batteryKnown = false
    private var charging = false
    private var hotspotKnown = false
    private var hotspot = false
    private var running = false

    private val mediaListener: (MediaWatcher.Info?) -> Unit = {
        island.setMedia(if (Prefs.bool(ctx, Prefs.ISLAND_MUSIC)) it else null)
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_BATTERY_CHANGED -> {
                    val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
                    val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                    val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                    val now = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                        status == BatteryManager.BATTERY_STATUS_FULL
                    island.batteryLevel = if (scale > 0) level * 100 / scale else level
                    island.charging = now
                    if (batteryKnown && now != charging) island.pulse(DynamicIslandView.Pulse.CHARGE)
                    charging = now
                    batteryKnown = true
                }
                Intent.ACTION_POWER_CONNECTED, Intent.ACTION_POWER_DISCONNECTED ->
                    island.pulse(DynamicIslandView.Pulse.CHARGE)
                "android.net.wifi.WIFI_AP_STATE_CHANGED" ->
                    // 13 = hotspot menyala, 11 = mati
                    setHotspot(i.getIntExtra("wifi_state", 11) == 13)
                "android.net.conn.TETHER_STATE_CHANGED" ->
                    setHotspot(!i.getStringArrayListExtra("tetherArray").isNullOrEmpty())
            }
        }
    }

    private fun setHotspot(on: Boolean) {
        HotspotState.on = on
        if (!Prefs.bool(ctx, Prefs.ISLAND_HOTSPOT)) { island.hotspot = false; hotspot = on; hotspotKnown = true; return }
        if (hotspotKnown && on == hotspot) return
        val changed = hotspotKnown
        hotspot = on; hotspotKnown = true
        island.hotspot = on
        if (changed) island.pulse(DynamicIslandView.Pulse.HOTSPOT, 3200)
    }

    fun start() {
        if (running) return
        running = true
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction("android.net.wifi.WIFI_AP_STATE_CHANGED")
            addAction("android.net.conn.TETHER_STATE_CHANGED")
        }
        ContextCompat.registerReceiver(ctx, receiver, f, ContextCompat.RECEIVER_EXPORTED)
        MediaWatcher.addListener(ctx, mediaListener)
        // keadaan awal hotspot (API tersembunyi, tidak selalu tersedia)
        try {
            val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            val on = wm.javaClass.getMethod("isWifiApEnabled").invoke(wm) as Boolean
            hotspot = on; hotspotKnown = true
            HotspotState.on = on
            island.hotspot = on && Prefs.bool(ctx, Prefs.ISLAND_HOTSPOT)
        } catch (_: Throwable) {}
    }

    fun refreshMedia() = MediaWatcher.ensureStarted(ctx)

    fun stop() {
        if (!running) return
        running = false
        try { ctx.unregisterReceiver(receiver) } catch (_: Exception) {}
        MediaWatcher.removeListener(mediaListener)
    }
}
