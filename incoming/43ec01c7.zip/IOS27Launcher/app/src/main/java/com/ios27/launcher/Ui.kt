package com.ios27.launcher

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** Panel kaca gelap tembus pandang, dipakai untuk dock, widget, dan kartu. */
fun Context.glass(radiusDp: Int, strong: Boolean = false): GlassDrawable =
    GlassDrawable(this, dp(radiusDp).toFloat(), strong)

fun TextView.softShadow() {
    setShadowLayer(context.dp(2).toFloat(), 0f, context.dp(1).toFloat(), Color.parseColor("#99000000"))
}

/** ListView tanpa garis pemisah, sorotan, atau efek tarik, supaya terlihat seperti daftar iOS. */
fun Context.plainList(): ListView = ListView(this).apply {
    divider = null
    dividerHeight = 0
    setSelector(android.R.color.transparent)
    cacheColorHint = Color.TRANSPARENT
    overScrollMode = View.OVER_SCROLL_NEVER
    isVerticalScrollBarEnabled = false
    isFastScrollEnabled = false
}

/**
 * Adapter daftar aplikasi. Baris di-recycle oleh ListView, jadi ratusan aplikasi tetap ringan.
 * Isi daftar boleh campuran: String = judul huruf, AppEntry = baris aplikasi.
 */
class AppListAdapter(
    private val ctx: Context,
    private val icon: (AppEntry, Int) -> Bitmap,
    private val onClick: (AppEntry, View) -> Unit,
    private val onLongClick: ((AppEntry, View) -> Unit)? = null,
    private val rightPadDp: Int = 0
) : BaseAdapter() {

    var items: List<Any> = emptyList()
        set(v) { field = v; notifyDataSetChanged() }

    private val iconPx = ctx.dp(44)

    override fun getCount() = items.size
    override fun getItem(i: Int): Any = items[i]
    override fun getItemId(i: Int) = i.toLong()
    override fun getViewTypeCount() = 2
    override fun getItemViewType(i: Int) = if (items[i] is String) 0 else 1
    override fun isEnabled(position: Int) = false

    override fun getView(i: Int, convert: View?, parent: ViewGroup): View {
        val item = items[i]
        if (item is String) {
            val tv = (convert as? TextView) ?: TextView(ctx).apply {
                textSize = 14f
                setTextColor(Color.parseColor("#AEAEB2"))
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setPadding(0, ctx.dp(12), 0, ctx.dp(4))
            }
            tv.text = item
            return tv
        }
        val app = item as AppEntry
        val row = (convert as? LinearLayout) ?: LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, ctx.dp(6), ctx.dp(rightPadDp), ctx.dp(6))
            addView(ImageView(ctx), LinearLayout.LayoutParams(iconPx, iconPx))
            addView(TextView(ctx).apply {
                textSize = 16f; setTextColor(Color.WHITE); maxLines = 1
                ellipsize = TextUtils.TruncateAt.END; softShadow()
            }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = ctx.dp(14) })
        }
        val iv = row.getChildAt(0) as ImageView
        iv.setImageBitmap(icon(app, iconPx))
        (row.getChildAt(1) as TextView).text = app.label
        row.setOnClickListener { onClick(app, iv) }
        row.setOnLongClickListener { onLongClick?.invoke(app, iv); onLongClick != null }
        return row
    }
}

/** Layar pencarian penuh, atau daftar isi satu kategori jika [fixed] diisi. */
class SearchOverlay(
    private val activity: Activity,
    private val root: FrameLayout,
    private val icon: (AppEntry, Int) -> Bitmap,
    private val launch: (AppEntry, View) -> Unit
) {
    private var view: FrameLayout? = null
    val isShowing: Boolean get() = view != null

    fun show(allApps: List<AppEntry>, title: String?, fixed: List<AppEntry>?) {
        close()
        val ctx = activity
        val scrim = FrameLayout(ctx).apply {
            setBackgroundColor(Color.parseColor("#E6101012"))
            isClickable = true
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.dp(18), ctx.dp(84), ctx.dp(18), ctx.dp(12))
        }
        val adapter = AppListAdapter(ctx, icon, { app, v -> launch(app, v); close() })
        val list = ctx.plainList().also { it.adapter = adapter }

        if (fixed != null) {
            col.addView(TextView(ctx).apply {
                text = title
                textSize = 26f
                setTextColor(Color.WHITE)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = ctx.dp(12) })
            adapter.items = fixed
        } else {
            val input = EditText(ctx).apply {
                hint = "Search"
                setHintTextColor(Color.parseColor("#8E8E93"))
                setTextColor(Color.WHITE)
                textSize = 17f
                isSingleLine = true
                background = ctx.glass(14, true)
                setPadding(ctx.dp(16), ctx.dp(12), ctx.dp(16), ctx.dp(12))
            }
            fun filtered(q: String) =
                if (q.isBlank()) allApps else allApps.filter { it.label.contains(q.trim(), ignoreCase = true) }
            input.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { adapter.items = filtered(s?.toString().orEmpty()) }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            input.setOnEditorActionListener { _, _, _ ->
                filtered(input.text.toString()).firstOrNull()?.let { launch(it, input); close() }
                true
            }
            col.addView(input, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = ctx.dp(12) })
            adapter.items = allApps
            input.postDelayed({
                input.requestFocus()
                (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            }, 150)
        }
        col.addView(list, LinearLayout.LayoutParams(MATCH, 0, 1f))
        scrim.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        scrim.alpha = 0f
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))
        scrim.animate().alpha(1f).setDuration(160).start()
        view = scrim
    }

    fun close() {
        val v = view ?: return
        view = null
        (activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(v.windowToken, 0)
        v.animate().alpha(0f).setDuration(120).withEndAction { root.removeView(v) }.start()
    }
}
