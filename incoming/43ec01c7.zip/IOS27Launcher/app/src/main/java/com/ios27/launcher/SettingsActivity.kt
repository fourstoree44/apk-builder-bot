package com.ios27.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

/** Pengaturan bergaya iOS gelap: daftar utama, lalu sub-halaman dengan switch dan slider. */
class SettingsActivity : Activity() {

    private lateinit var host: FrameLayout
    private val stack = ArrayList<String>()
    private var top = 0
    private var bottom = 0

    private val white = Color.WHITE
    private val dim = Color.parseColor("#8E8E93")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        host = FrameLayout(this).apply { setBackgroundColor(Color.parseColor("#0B0B10")) }
        setContentView(host)
        ViewCompat.setOnApplyWindowInsetsListener(host) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            top = bars.top; bottom = bars.bottom
            show(stack.lastOrNull() ?: "main", push = false)
            insets
        }
        show("main", push = false)
    }

    @Deprecated("Back lokal")
    override fun onBackPressed() {
        if (stack.size > 1) { stack.removeAt(stack.size - 1); show(stack.last(), push = false) }
        else finish()
    }

    private fun show(page: String, push: Boolean = true) {
        if (push) stack.add(page) else if (stack.isEmpty() || stack.last() != page) { stack.clear(); stack.add(page) }
        host.removeAllViews()
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), top + dp(8), dp(16), bottom + dp(24))
        }
        header(col, page)
        when (page) {
            "main" -> main(col)
            "general" -> general(col)
            "island" -> island(col)
            "grid" -> grid(col)
            "glass" -> glassPage(col)
            "icons" -> icons(col)
            "control" -> control(col)
        }
        host.addView(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        }, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    // ------------------------------------------------------------ pieces

    private fun title(page: String) = when (page) {
        "main" -> "Settings"; "general" -> "General"; "island" -> "Island"; "grid" -> "Screen Grid"
        "glass" -> "Glass & Blur"; "icons" -> "Icons"; else -> "Control & Notifications"
    }

    private fun header(col: LinearLayout, page: String) {
        if (page == "main") {
            col.addView(TextView(this).apply {
                text = title(page); textSize = 32f; setTextColor(white)
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(24); bottomMargin = dp(16) })
            return
        }
        val bar = FrameLayout(this)
        bar.addView(TextView(this).apply {
            text = "‹"; textSize = 26f; setTextColor(white); gravity = Gravity.CENTER
            background = glass(22, true)
            setOnClickListener { onBackPressed() }
        }, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.START))
        bar.addView(TextView(this).apply {
            text = title(page); textSize = 17f; setTextColor(white); gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(MATCH, dp(44)))
        bar.addView(TextView(this).apply {
            text = "↺"; textSize = 20f; setTextColor(white); gravity = Gravity.CENTER
            background = glass(22, true)
            setOnClickListener { Prefs.resetAll(this@SettingsActivity); show(page, push = false) }
        }, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.END))
        col.addView(bar, LinearLayout.LayoutParams(MATCH, dp(44)).apply { bottomMargin = dp(16) })
    }

    private fun card(col: LinearLayout, label: String? = null): LinearLayout {
        if (label != null) col.addView(TextView(this).apply {
            text = label; textSize = 13f; setTextColor(dim)
        }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(10); bottomMargin = dp(6); marginStart = dp(8) })
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = glass(22)
            setPadding(dp(16), dp(4), dp(16), dp(4))
        }
        col.addView(c, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(8) })
        return c
    }

    private fun nav(card: LinearLayout, label: String, value: String?, color: Int, page: String) {
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, dp(12))
            setOnClickListener { show(page) }
        }
        row.addView(TextView(this).apply {
            text = "●"; textSize = 20f; setTextColor(color); gravity = Gravity.CENTER
            background = GradientDrawable().apply { cornerRadius = dp(8).toFloat(); setColor(Color.parseColor("#26FFFFFF")) }
        }, LinearLayout.LayoutParams(dp(32), dp(32)))
        row.addView(TextView(this).apply {
            text = label; textSize = 16f; setTextColor(white)
        }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(14) })
        if (value != null) row.addView(TextView(this).apply {
            text = value; textSize = 14f; setTextColor(dim)
        })
        row.addView(TextView(this).apply {
            text = "›"; textSize = 20f; setTextColor(dim)
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(8) })
        card.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun toggle(card: LinearLayout, label: String, key: String, onChange: (() -> Unit)? = null) {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, dp(10)) }
        row.addView(TextView(this).apply { text = label; textSize = 15f; setTextColor(white) },
            LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(Switch(this).apply {
            isChecked = Prefs.bool(this@SettingsActivity, key)
            setOnCheckedChangeListener { _, on -> Prefs.setBool(this@SettingsActivity, key, on); onChange?.invoke() }
        })
        card.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun slider(card: LinearLayout, label: String, key: String, min: Int, max: Int, unit: String,
                       onChange: (() -> Unit)? = null) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(6)) }
        val head = LinearLayout(this)
        val value = TextView(this).apply {
            textSize = 14f; setTextColor(dim)
            text = "${Prefs.int(this@SettingsActivity, key)}$unit"
        }
        head.addView(TextView(this).apply { text = label; textSize = 15f; setTextColor(white) },
            LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(value)
        box.addView(head, LinearLayout.LayoutParams(MATCH, WRAP))
        box.addView(SeekBar(this).apply {
            this.max = max - min
            progress = Prefs.int(this@SettingsActivity, key) - min
            progressTintList = android.content.res.ColorStateList.valueOf(Prefs.accent(this@SettingsActivity))
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    Prefs.setInt(this@SettingsActivity, key, p + min)
                    value.text = "${p + min}$unit"
                    onChange?.invoke()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }, LinearLayout.LayoutParams(MATCH, WRAP))
        card.addView(box, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    /** Pilihan segmen, misal Rows 4..8 atau Top/Center/Bottom. */
    private fun segmented(card: LinearLayout, label: String, key: String, options: List<String>, base: Int) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(10), 0, dp(10)) }
        box.addView(TextView(this).apply { text = label; textSize = 13f; setTextColor(dim) },
            LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(6) })
        val row = LinearLayout(this).apply {
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(Color.parseColor("#33000000")) }
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        val cur = Prefs.int(this, key) - base
        options.forEachIndexed { i, name ->
            row.addView(TextView(this).apply {
                text = name; textSize = 14f; gravity = Gravity.CENTER
                setTextColor(if (i == cur) white else dim)
                if (i == cur) background = GradientDrawable().apply {
                    cornerRadius = dp(10).toFloat(); setColor(Color.parseColor("#4D8E8E93"))
                }
                setOnClickListener { Prefs.setInt(this@SettingsActivity, key, i + base); show(stack.last(), push = false) }
            }, LinearLayout.LayoutParams(0, dp(34), 1f))
        }
        box.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        card.addView(box, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    private fun action(card: LinearLayout, label: String, run: () -> Unit) {
        card.addView(TextView(this).apply {
            text = label; textSize = 15f; setTextColor(Prefs.accent(this@SettingsActivity))
            setPadding(0, dp(12), 0, dp(12)); setOnClickListener { run() }
        }, LinearLayout.LayoutParams(MATCH, WRAP))
    }

    // ------------------------------------------------------------- pages

    private fun main(col: LinearLayout) {
        val hero = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = glass(22, true)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        hero.addView(TextView(this).apply {
            text = "27"; textSize = 22f; setTextColor(white); gravity = Gravity.CENTER
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#BF5AF2"), Color.parseColor("#5E5CE6"))).apply { cornerRadius = dp(14).toFloat() }
        }, LinearLayout.LayoutParams(dp(56), dp(56)))
        val t = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        t.addView(TextView(this).apply { text = "iOS 27 Launcher"; textSize = 18f; setTextColor(white) })
        t.addView(TextView(this).apply { text = "Your home screen, made of glass"; textSize = 12f; setTextColor(dim) })
        hero.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = dp(14) })
        col.addView(hero, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) })

        val a = card(col)
        nav(a, "General", null, Color.parseColor("#8E8E93"), "general")
        nav(a, "Island", null, Color.parseColor("#BF5AF2"), "island")
        nav(a, "Control & Notifications", null, Color.parseColor("#FF453A"), "control")
        val b = card(col)
        nav(b, "Screen Grid", "${Prefs.int(this, Prefs.COLS)}×${Prefs.int(this, Prefs.ROWS)}", Color.parseColor("#5E5CE6"), "grid")
        nav(b, "Glass & Blur", null, Color.parseColor("#64D2FF"), "glass")
        nav(b, "Icons", null, Color.parseColor("#30D158"), "icons")
        val c = card(col)
        action(c, "Ganti wallpaper") {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
        }
        action(c, "Pilih launcher default") { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
    }

    private fun general(col: LinearLayout) {
        val c = card(col)
        toggle(c, "iOS status bar (sembunyikan status bar Android)", Prefs.HIDE_STATUS)
        toggle(c, "Hide navigation", Prefs.HIDE_NAV)
        toggle(c, "Blur effect (bisa berat di HP lemah)", Prefs.BLUR)
        toggle(c, "Custom text size", Prefs.CUSTOM_TEXT) { show("general", push = false) }
        if (Prefs.bool(this, Prefs.CUSTOM_TEXT)) {
            slider(c, "Icon label size", Prefs.TEXT_SIZE, 70, 130, "%")
            slider(c, "Icon label spacing", Prefs.LABEL_SPACING, 0, 16, " dp")
        }
        val d = card(col, "Gesture")
        toggle(d, "Swipe down to search", Prefs.SWIPE_SEARCH)
        toggle(d, "Haptic feedback", Prefs.HAPTIC)
        toggle(d, "App Library as list (A–Z)", Prefs.LIB_LIST)
    }

    private fun island(col: LinearLayout) {
        val c = card(col)
        toggle(c, "Show over all apps", Prefs.OVERLAY) {
            if (Prefs.bool(this, Prefs.OVERLAY) && !Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        slider(c, "Vertical position", Prefs.ISLAND_Y, 0, 60, " dp") { IslandOverlayService.refresh(this) }
        slider(c, "Size", Prefs.ISLAND_SCALE, 70, 130, "%") { IslandOverlayService.refresh(this) }
        val live = card(col, "Live activity")
        toggle(live, "Lagu yang diputar", Prefs.ISLAND_MUSIC) { IslandOverlayService.refresh(this) }
        toggle(live, "Hotspot menyala", Prefs.ISLAND_HOTSPOT) { IslandOverlayService.refresh(this) }
        val d = card(col, "Izin")
        action(d, "Izinkan tampil di atas aplikasi lain") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        val granted = MediaWatcher.isAccessGranted(this)
        action(d, if (granted) "Akses notifikasi untuk lagu: aktif" else "Beri akses notifikasi supaya lagu tampil") {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        action(d, "Izinkan ubah pengaturan sistem (kecerahan di Control Center)") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    private fun grid(col: LinearLayout) {
        val c = card(col, "Layout")
        segmented(c, "Columns", Prefs.COLS, listOf("3", "4", "5", "6"), 3)
        segmented(c, "Rows", Prefs.ROWS, listOf("4", "5", "6", "7", "8"), 4)
        val m = card(col, "Margins")
        slider(m, "Sides", Prefs.M_SIDES, 0, 48, " dp")
        slider(m, "Top", Prefs.M_TOP, 0, 80, " dp")
        slider(m, "Bottom", Prefs.M_BOTTOM, 0, 80, " dp")
        val v = card(col)
        segmented(v, "Vertical position", Prefs.V_POS, listOf("Top", "Center", "Bottom"), 0)
    }

    private fun glassPage(col: LinearLayout) {
        val preview = LinearLayout(this).apply {
            gravity = Gravity.CENTER; background = glass(26, true)
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        preview.addView(TextView(this).apply { text = "Search"; textSize = 14f; setTextColor(white); gravity = Gravity.CENTER },
            LinearLayout.LayoutParams(0, dp(40), 1f))
        col.addView(preview, LinearLayout.LayoutParams(MATCH, dp(90)).apply { bottomMargin = dp(12) })
        val c = card(col, "Dock, pills and menus")
        toggle(c, "Blur effect", Prefs.BLUR)
        slider(c, "Glass brightness", Prefs.GLASS_BRIGHT, 0, 100, "%") { GlassRegistry.refresh() }
        toggle(c, "Edge highlight", Prefs.EDGE) { GlassRegistry.refresh() }
        slider(c, "Refraction", Prefs.REFRACT, 0, 100, "%") { GlassRegistry.refresh() }
        toggle(c, "Highlight follows tilt", Prefs.TILT)
    }

    private fun icons(col: LinearLayout) {
        val c = card(col)
        slider(c, "Icon size", Prefs.ICON_SIZE, 60, 110, "%")
        slider(c, "Dock icon size", Prefs.DOCK_ICON_SIZE, 60, 110, "%")
        slider(c, "Corner rounding", Prefs.ICON_ROUND, 0, 100, "%")
        toggle(c, "Glass icon tile", Prefs.ICON_GLASS)
        toggle(c, "App names", Prefs.SHOW_NAMES)
        val note = TextView(this).apply {
            text = "0% is a square, 100% a circle."; textSize = 12f; setTextColor(dim)
        }
        col.addView(note, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(8); topMargin = dp(4) })
    }

    private fun control(col: LinearLayout) {
        val c = card(col)
        toggle(c, "Dynamic Color", Prefs.DYN_COLOR)
        action(c, "Akses notifikasi") { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        action(c, "Pengaturan aplikasi default") { startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) }
        action(c, "Reset semua pengaturan") {
            AlertDialog.Builder(this).setMessage("Kembalikan semua pengaturan ke bawaan?")
                .setPositiveButton("Reset") { _, _ -> Prefs.resetAll(this); show("main", push = false) }
                .setNegativeButton("Batal", null).show()
        }
    }
}
