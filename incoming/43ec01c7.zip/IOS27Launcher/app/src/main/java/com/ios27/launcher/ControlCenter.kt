package com.ios27.launcher

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Slider vertikal tebal ala iOS (kecerahan, volume). */
class VSlider(ctx: Context, private val glyph: String, private val onValue: (Float) -> Unit) : View(ctx) {
    var value = 0.5f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F2FFFFFF") }
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val clip = Path()
    private val rect = RectF()

    init { background = ctx.glass(28, true) }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val r = context.dp(28).toFloat()
        rect.set(0f, 0f, w, h)
        clip.reset(); clip.addRoundRect(rect, r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        c.drawRect(0f, h * (1f - value), w, h, fill)
        c.restore()
        icon.textSize = context.dp(22).toFloat()
        val iconY = h - context.dp(28).toFloat()
        icon.color = if (h * (1f - value) < iconY - context.dp(14)) Color.BLACK else Color.WHITE
        c.drawText(glyph, w / 2f, iconY + icon.textSize * 0.35f, icon)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                value = 1f - e.y / height
                onValue(value)
            }
        }
        return true
    }
}

/**
 * Control Center bergaya iOS: konektivitas, senter, hotspot, kecerahan, volume, dan kontrol lagu.
 * Dibuka dengan geser ke bawah dari pojok kanan atas layar utama.
 *
 * Catatan Android: aplikasi biasa tidak boleh menyalakan Wi-Fi, data, atau Bluetooth langsung.
 * Tombol-tombol itu menampilkan statusnya dan membuka panel sistem untuk mengubahnya.
 * Senter, kecerahan, dan volume bisa dikontrol langsung.
 */
class ControlCenter(
    private val activity: Activity,
    private val root: FrameLayout,
    private val topInset: () -> Int,
    private val openSearch: () -> Unit
) {
    private var view: FrameLayout? = null
    val isShowing: Boolean get() = view != null

    private val handler = Handler(Looper.getMainLooper())
    private val camera = activity.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val audio = activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var torchId: String? = null
    private var torchOn = false
    private var askedWrite = false

    private var tAirplane: Tile? = null
    private var tData: Tile? = null
    private var tWifi: Tile? = null
    private var tBt: Tile? = null
    private var tHotspot: Tile? = null
    private var tTorch: Tile? = null
    private var mediaTitle: TextView? = null
    private var mediaArtist: TextView? = null
    private var mediaPlay: TextView? = null
    private var mediaArt: android.widget.ImageView? = null

    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(id: String, enabled: Boolean) {
            if (id == torchId) { torchOn = enabled; tTorch?.setOn(enabled) }
        }
    }

    private val mediaListener: (MediaWatcher.Info?) -> Unit = { updateMedia(it) }

    private fun ctx(): Context = activity

    // ------------------------------------------------------------ tombol

    private inner class Tile(
        val glyph: String, val label: String, val sizeDp: Int,
        val onColor: Int, val click: () -> Unit
    ) {
        val circle = TextView(activity).apply {
            text = glyph; textSize = 22f; gravity = Gravity.CENTER
            setOnClickListener { click() }
        }
        val box = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(circle, LinearLayout.LayoutParams(activity.dp(sizeDp), activity.dp(sizeDp)))
            addView(TextView(activity).apply {
                text = label; textSize = 11f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            }, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = activity.dp(4) })
        }
        init { setOn(false) }

        fun setOn(on: Boolean) {
            circle.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (on) onColor else Color.parseColor("#66FFFFFF"))
            }
            circle.setTextColor(if (on) (if (onColor == Color.WHITE) Color.BLACK else Color.WHITE) else Color.WHITE)
        }
    }

    private fun tile(glyph: String, label: String, onColor: Int, click: () -> Unit) =
        Tile(glyph, label, 56, onColor, click)

    private fun go(intent: Intent) {
        close()
        try { activity.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(activity, "Tidak bisa dibuka di HP ini", Toast.LENGTH_SHORT).show() }
    }

    // ------------------------------------------------------------- status

    private fun refreshStates() {
        try {
            tAirplane?.setOn(Settings.Global.getInt(activity.contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1)
        } catch (_: Exception) {}
        try {
            val cm = activity.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            tData?.setOn(caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true)
        } catch (_: Exception) {}
        try {
            val wm = activity.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            tWifi?.setOn(wm.isWifiEnabled)
        } catch (_: Exception) {}
        try { tBt?.setOn(BluetoothAdapter.getDefaultAdapter()?.isEnabled == true) } catch (_: Exception) {}
        tHotspot?.setOn(HotspotState.on)
        tTorch?.setOn(torchOn)
    }

    private fun findTorch() {
        if (torchId != null) return
        torchId = try {
            camera.cameraIdList.firstOrNull {
                val ch = camera.getCameraCharacteristics(it)
                ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
        } catch (_: Exception) { null }
    }

    private fun toggleTorch() {
        val id = torchId
        if (id == null) { Toast.makeText(activity, "HP ini tidak punya senter", Toast.LENGTH_SHORT).show(); return }
        try { camera.setTorchMode(id, !torchOn) } catch (_: Exception) {
            Toast.makeText(activity, "Senter sedang dipakai aplikasi lain", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setBrightness(v: Float) {
        if (Settings.System.canWrite(activity)) {
            try {
                Settings.System.putInt(activity.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(activity.contentResolver, Settings.System.SCREEN_BRIGHTNESS,
                    (v * 255).toInt().coerceIn(1, 255))
            } catch (_: Exception) {}
        } else {
            val lp = activity.window.attributes
            lp.screenBrightness = v.coerceIn(0.02f, 1f)
            activity.window.attributes = lp
            if (!askedWrite) {
                askedWrite = true
                Toast.makeText(activity, "Izinkan \"Ubah pengaturan sistem\" supaya kecerahan berlaku di semua aplikasi", Toast.LENGTH_LONG).show()
                try {
                    activity.startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
                        android.net.Uri.parse("package:${activity.packageName}")))
                } catch (_: Exception) {}
            }
        }
    }

    private fun currentBrightness(): Float = try {
        Settings.System.getInt(activity.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
    } catch (_: Exception) { 0.5f }

    // --------------------------------------------------------------- lagu

    private fun updateMedia(i: MediaWatcher.Info?) {
        mediaTitle?.text = i?.title ?: "Tidak ada lagu"
        mediaArtist?.text = i?.artist ?: if (MediaWatcher.isAccessGranted(activity)) "" else "Ketuk untuk beri akses"
        mediaPlay?.text = if (i?.playing == true) "❚❚" else "▶"
        i?.art?.let { mediaArt?.setImageBitmap(it) } ?: mediaArt?.setImageDrawable(null)
    }

    private fun mediaCard(): View {
        val d = activity
        val card = LinearLayout(d).apply {
            orientation = LinearLayout.VERTICAL
            background = d.glass(28, true)
            setPadding(d.dp(14), d.dp(14), d.dp(14), d.dp(10))
            setOnClickListener {
                if (!MediaWatcher.isAccessGranted(d)) go(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            }
        }
        val top = LinearLayout(d).apply { gravity = Gravity.CENTER_VERTICAL }
        mediaArt = android.widget.ImageView(d).apply {
            scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply { cornerRadius = d.dp(10).toFloat(); setColor(Color.parseColor("#33FFFFFF")) }
            clipToOutline = true
        }
        top.addView(mediaArt, LinearLayout.LayoutParams(d.dp(44), d.dp(44)))
        val names = LinearLayout(d).apply { orientation = LinearLayout.VERTICAL }
        mediaTitle = TextView(d).apply {
            textSize = 13f; setTextColor(Color.WHITE); maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        mediaArtist = TextView(d).apply {
            textSize = 11f; setTextColor(Color.parseColor("#AEAEB2")); maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        names.addView(mediaTitle); names.addView(mediaArtist)
        top.addView(names, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = d.dp(10) })
        card.addView(top, LinearLayout.LayoutParams(MATCH, WRAP))

        val row = LinearLayout(d).apply { gravity = Gravity.CENTER }
        fun btn(t: String, f: () -> Unit) = TextView(d).apply {
            text = t; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setOnClickListener { f() }
        }
        row.addView(btn("⏮") { MediaWatcher.previous() }, LinearLayout.LayoutParams(0, MATCH, 1f))
        mediaPlay = btn("▶") { MediaWatcher.toggle() }
        row.addView(mediaPlay, LinearLayout.LayoutParams(0, MATCH, 1f))
        row.addView(btn("⏭") { MediaWatcher.next() }, LinearLayout.LayoutParams(0, MATCH, 1f))
        card.addView(row, LinearLayout.LayoutParams(MATCH, 0, 1f))
        updateMedia(MediaWatcher.info)
        return card
    }

    // --------------------------------------------------------------- tampil

    fun show() {
        close()
        val d = activity
        val accent = Prefs.accent(d)
        findTorch()
        try { camera.registerTorchCallback(torchCb, handler) } catch (_: Exception) {}

        val scrim = FrameLayout(d).apply {
            setBackgroundColor(Color.parseColor("#B3000000"))
            isClickable = true
            setOnClickListener { close() }
        }
        val col = LinearLayout(d).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d.dp(18), topInset() + d.dp(60), d.dp(18), d.dp(28))
            isClickable = true
        }

        // baris 1: konektivitas dan lagu
        val conn = LinearLayout(d).apply {
            orientation = LinearLayout.VERTICAL
            background = d.glass(28, true)
            setPadding(d.dp(8), d.dp(12), d.dp(8), d.dp(8))
        }
        tAirplane = tile("✈", "Pesawat", Color.parseColor("#FF9F0A")) { go(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) }
        tData = tile("📶", "Data", Color.parseColor("#30D158")) { go(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) }
        tWifi = tile("📡", "Wi-Fi", accent) { go(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) }
        tBt = tile("🎧", "Bluetooth", accent) { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        listOf(listOf(tAirplane!!, tData!!), listOf(tWifi!!, tBt!!)).forEach { pair ->
            val r = LinearLayout(d).apply { gravity = Gravity.CENTER }
            pair.forEach { r.addView(it.box, LinearLayout.LayoutParams(0, WRAP, 1f)) }
            conn.addView(r, LinearLayout.LayoutParams(MATCH, 0, 1f))
        }
        val rowA = LinearLayout(d)
        rowA.addView(conn, LinearLayout.LayoutParams(0, d.dp(170), 1f).apply { marginEnd = d.dp(7) })
        rowA.addView(mediaCard(), LinearLayout.LayoutParams(0, d.dp(170), 1f).apply { marginStart = d.dp(7) })
        col.addView(rowA, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = d.dp(14) })

        // baris 2: senter, hotspot, kamera, kalkulator
        val rowB = LinearLayout(d).apply {
            background = d.glass(28, true)
            gravity = Gravity.CENTER
            setPadding(d.dp(6), d.dp(12), d.dp(6), d.dp(10))
        }
        tTorch = tile("🔦", "Senter", Color.WHITE) { toggleTorch() }
        tHotspot = tile("🔗", "Hotspot", Color.parseColor("#30D158")) {
            go(Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"))
        }
        val tCam = tile("📷", "Kamera", Color.WHITE) { go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
        val tCalc = tile("🧮", "Kalkulator", Color.WHITE) {
            go(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR))
        }
        listOf(tTorch!!, tHotspot!!, tCam, tCalc).forEach { rowB.addView(it.box, LinearLayout.LayoutParams(0, WRAP, 1f)) }
        col.addView(rowB, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = d.dp(14) })

        // baris 3: kecerahan, volume, dan pintasan
        val bright = VSlider(d, "☀") { setBrightness(it) }.also { it.value = currentBrightness() }
        val vol = VSlider(d, "🔊") {
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, (it * max).toInt(), 0)
        }.also {
            it.value = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() /
                audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        }
        val side = LinearLayout(d).apply { orientation = LinearLayout.VERTICAL }
        val tSet = tile("⚙", "Pengaturan", Color.WHITE) { go(Intent(d, SettingsActivity::class.java)) }
        val tSearch = tile("🔍", "Cari", Color.WHITE) { close(); openSearch() }
        listOf(tSet, tSearch).forEach {
            side.addView(it.box, LinearLayout.LayoutParams(MATCH, 0, 1f))
        }
        side.background = d.glass(28, true)
        side.setPadding(d.dp(6), d.dp(12), d.dp(6), d.dp(8))
        val rowC = LinearLayout(d)
        rowC.addView(bright, LinearLayout.LayoutParams(0, d.dp(170), 1f).apply { marginEnd = d.dp(7) })
        rowC.addView(vol, LinearLayout.LayoutParams(0, d.dp(170), 1f).apply { marginStart = d.dp(7); marginEnd = d.dp(7) })
        rowC.addView(side, LinearLayout.LayoutParams(0, d.dp(170), 1f).apply { marginStart = d.dp(7) })
        col.addView(rowC, LinearLayout.LayoutParams(MATCH, WRAP))

        scrim.addView(ScrollView(d).apply {
            isVerticalScrollBarEnabled = false
            addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        }, FrameLayout.LayoutParams(MATCH, MATCH))

        refreshStates()
        MediaWatcher.addListener(d, mediaListener)

        scrim.alpha = 0f
        scrim.translationY = -d.dp(40).toFloat()
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))
        scrim.animate().alpha(1f).translationY(0f).setDuration(200).start()
        view = scrim
    }

    fun close() {
        val v = view ?: return
        view = null
        try { camera.unregisterTorchCallback(torchCb) } catch (_: Exception) {}
        MediaWatcher.removeListener(mediaListener)
        mediaTitle = null; mediaArtist = null; mediaPlay = null; mediaArt = null
        v.animate().alpha(0f).translationY(-activity.dp(30).toFloat()).setDuration(150)
            .withEndAction { root.removeView(v) }.start()
    }
}
