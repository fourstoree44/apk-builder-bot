package com.ios27.launcher

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager

/**
 * Menampilkan Dynamic Island di atas semua aplikasi.
 * Butuh izin "Tampil di atas aplikasi lain" (SYSTEM_ALERT_WINDOW).
 */
class IslandOverlayService : Service() {

    private var wm: WindowManager? = null
    private var island: DynamicIslandView? = null
    private var feeds: IslandFeeds? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_REFRESH) removeIsland()
        if (island == null) {
            if (!Settings.canDrawOverlays(this) || !Prefs.bool(this, Prefs.OVERLAY)) {
                stopSelf()
                return START_NOT_STICKY
            }
            addIsland()
        } else {
            feeds?.refreshMedia()
        }
        return START_STICKY
    }

    private fun addIsland() {
        val d = resources.displayMetrics.density
        val view = DynamicIslandView(this)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (Prefs.int(this@IslandOverlayService, Prefs.ISLAND_Y) * d).toInt()
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm?.addView(view, lp)
        island = view
        feeds = IslandFeeds(this, view).also { it.start() }
    }

    private fun removeIsland() {
        feeds?.stop(); feeds = null
        island?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        island = null
    }

    override fun onDestroy() {
        removeIsland()
        super.onDestroy()
    }

    companion object {
        const val ACTION_REFRESH = "com.ios27.launcher.REFRESH_ISLAND"

        fun start(ctx: Context) {
            if (Settings.canDrawOverlays(ctx)) {
                ctx.startService(Intent(ctx, IslandOverlayService::class.java))
            }
        }

        /** Dipanggil setelah posisi atau ukuran island diubah. */
        fun refresh(ctx: Context) {
            if (Settings.canDrawOverlays(ctx)) {
                ctx.startService(
                    Intent(ctx, IslandOverlayService::class.java).setAction(ACTION_REFRESH)
                )
            }
        }
    }
}
