package com.ios27.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import java.lang.ref.WeakReference
import kotlin.math.abs
import kotlin.math.roundToInt

/** Arah cahaya tepi kaca. Berubah mengikuti kemiringan HP bila "Highlight follows tilt" aktif. */
object GlassRegistry {
    @Volatile var tx = -0.6f
    @Volatile var ty = -0.8f
    private var lastTx = 9f
    private var lastTy = 9f
    private val list = ArrayList<WeakReference<GlassDrawable>>()

    @Synchronized fun add(d: GlassDrawable) {
        if (list.size > 200) list.removeAll { it.get() == null }
        list.add(WeakReference(d))
    }

    /** Gambar ulang semua panel. Dipakai saat slider berubah. */
    @Synchronized fun refresh() {
        list.removeAll { it.get() == null }
        list.forEach { it.get()?.invalidateSelf() }
    }

    /** Dari sensor: hanya gambar ulang kalau arahnya berubah cukup jauh, supaya scroll tetap ringan. */
    fun tilt(x: Float, y: Float) {
        if (abs(x - lastTx) < 0.12f && abs(y - lastTy) < 0.12f) return
        lastTx = x; lastTy = y
        tx = x; ty = y
        refresh()
    }
}

/**
 * Panel "Liquid Glass": isi kaca gelap tembus pandang, kilau lembut di atas,
 * dan garis tepi bercahaya. Shader disimpan dan hanya dibuat ulang kalau ukuran atau
 * pengaturannya berubah, bukan di setiap frame.
 */
class GlassDrawable(
    private val ctx: Context,
    private val radiusPx: Float,
    private val strong: Boolean = false
) : Drawable() {

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = ctx.dp(1) * 1.4f
    }
    private val rect = RectF()
    private var key = ""

    init { GlassRegistry.add(this) }

    private fun rebuild(w: Int, h: Int, bright: Int, refract: Int, edgeOn: Boolean, tx: Float, ty: Float) {
        val inset = edge.strokeWidth / 2f
        rect.set(inset, inset, w - inset, h - inset)

        val baseAlpha = (0.30f + 0.42f * bright / 100f + if (strong) 0.08f else 0f).coerceAtMost(0.95f)
        fill.color = Color.argb((255 * baseAlpha).toInt(), 24, 24, 30)

        val rf = refract / 100f
        sheen.shader = LinearGradient(
            0f, rect.top, 0f, rect.bottom,
            intArrayOf(
                Color.argb((70 * rf).toInt(), 255, 255, 255),
                Color.argb((10 * rf).toInt(), 255, 255, 255),
                Color.argb((28 * rf).toInt(), 120, 160, 255)
            ),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )

        if (edgeOn) {
            val cx = rect.centerX(); val cy = rect.centerY()
            val hw = rect.width() / 2f; val hh = rect.height() / 2f
            edge.shader = LinearGradient(
                cx + tx * hw, cy + ty * hh, cx - tx * hw, cy - ty * hh,
                intArrayOf(
                    Color.argb(if (strong) 230 else 190, 255, 255, 255),
                    Color.argb(34, 255, 255, 255),
                    Color.argb(if (strong) 150 else 110, 190, 215, 255)
                ),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        } else {
            edge.shader = null
            edge.color = Color.argb(46, 255, 255, 255)
        }
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val bright = Prefs.int(ctx, Prefs.GLASS_BRIGHT)
        val refract = Prefs.int(ctx, Prefs.REFRACT)
        val edgeOn = Prefs.bool(ctx, Prefs.EDGE)
        val follow = Prefs.bool(ctx, Prefs.TILT)
        val tx = if (follow) (GlassRegistry.tx * 10).roundToInt() / 10f else -0.6f
        val ty = if (follow) (GlassRegistry.ty * 10).roundToInt() / 10f else -0.8f

        val k = "${b.width()}x${b.height()}|$bright|$refract|$edgeOn|$tx|$ty"
        if (k != key) { key = k; rebuild(b.width(), b.height(), bright, refract, edgeOn, tx, ty) }

        canvas.save()
        canvas.translate(b.left.toFloat(), b.top.toFloat())
        val r = minOf(radiusPx, rect.height() / 2f, rect.width() / 2f)
        canvas.drawRoundRect(rect, r, r, fill)
        canvas.drawRoundRect(rect, r, r, sheen)
        canvas.drawRoundRect(rect, r, r, edge)
        canvas.restore()
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
