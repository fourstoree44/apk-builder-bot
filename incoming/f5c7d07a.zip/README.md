# rzkylauncher 1.2

Launcher Android bergaya iOS dengan home screen, dock, App Library, Dynamic Island overlay, personalisasi wallpaper, serta halaman widget Android.

## Fitur pada source ini
- Home screen dengan halaman aplikasi, dock, pencarian, dan App Library.
- Wallpaper dan foto widget dipilih melalui Android Photo Picker / document picker.
- Halaman Widget memakai `AppWidgetHost`, sehingga pengguna dapat memilih widget yang disediakan aplikasi lain (jam, kalender, cuaca, musik, dan lainnya jika tersedia pada perangkat).
- Widget dapat dihapus dengan tekan lama.
- Dynamic Island overlay untuk status baterai/charging, dengan izin tampil di atas aplikasi lain.
- Mode performa, ukuran ikon, warna aksen, dan pintasan pengaturan Android.

## Batasan platform Android
- Widget pihak ketiga dirender oleh aplikasi penyedianya. Launcher tidak dapat memaksa desain internal semua widget menjadi Liquid Glass/iOS. Widget bawaan rzkylauncher dapat memakai tema sendiri; widget pihak ketiga tetap mengikuti desain pembuatnya.
- Dynamic Island saat ini menampilkan jam dan baterai/charging. Informasi musik dan notifikasi real-time memerlukan integrasi media session dan Notification Listener terpisah serta izin eksplisit pengguna.
- Android/OEM dapat menghentikan service latar belakang karena kebijakan baterai. `START_STICKY` membantu pemulihan service, tetapi bukan jaminan permanen.
- Launcher harus dipilih sebagai aplikasi Home default agar tampil saat tombol Home ditekan. Saat Spotify dibuka, Spotify memang tampil di depan dan launcher tetap berada di belakang; ini perilaku Android yang normal.

## Build
Buka folder project ini di Android Studio dan jalankan:

```bash
./gradlew assembleDebug
```

Konfigurasi Android/Gradle dipertahankan: Gradle 8.7, AGP 8.5.2, Kotlin 1.9.24, JDK 17, compileSdk/targetSdk 34, namespace dan applicationId tetap.
