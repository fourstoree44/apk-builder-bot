package com.ios27.launcher

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** Panel kaca gelap tembus pandang, dipakai untuk dock, widget, dan kartu. */
fun Context.glass(radiusDp: Int): GradientDrawable = GradientDrawable().apply {
    cornerRadius = dp(radiusDp).toFloat()
    val prefs = getSharedPreferences("island", Context.MODE_PRIVATE)
    val accent = prefs.getInt("accent_color", Color.WHITE)
    val tint = Color.argb(34, Color.red(accent), Color.green(accent), Color.blue(accent))
    setColor(Color.parseColor("#B326262B"))
    setStroke(dp(1), tint)
}

fun TextView.softShadow() {
    setShadowLayer(context.dp(2).toFloat(), 0f, context.dp(1).toFloat(), Color.parseColor("#99000000"))
}

/** Layar pencarian penuh, atau daftar isi satu kategori jika [fixed] diisi. */
class SearchOverlay(
    private val activity: Activity,
    private val root: FrameLayout,
    private val icon: (AppEntry, Int) -> Bitmap,
    private val launch: (AppEntry, View) -> Unit
) {
    private var view: FrameLayout? = null
    val isShowing: Boolean get() = view != null

    fun show(allApps: List<AppEntry>, title: String?, fixed: List<AppEntry>?) {
        close()
        val ctx = activity
        val scrim = FrameLayout(ctx).apply {
            setBackgroundColor(Color.parseColor("#E6101012"))
            isClickable = true
            setOnClickListener { close() }
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.dp(18), ctx.dp(84), ctx.dp(18), ctx.dp(12))
        }
        val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(ctx).apply {
            isVerticalScrollBarEnabled = false
            addView(list, FrameLayout.LayoutParams(MATCH, WRAP))
        }

        fun fill(items: List<AppEntry>) {
            list.removeAllViews()
            items.take(60).forEach { app ->
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(0, ctx.dp(8), 0, ctx.dp(8))
                }
                val iv = ImageView(ctx).apply { setImageBitmap(icon(app, ctx.dp(44))) }
                row.addView(iv, LinearLayout.LayoutParams(ctx.dp(44), ctx.dp(44)))
                row.addView(TextView(ctx).apply {
                    text = app.label
                    textSize = 17f
                    setTextColor(Color.WHITE)
                    maxLines = 1
                }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = ctx.dp(14) })
                row.setOnClickListener { launch(app, iv); close() }
                list.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
            }
        }

        if (fixed != null) {
            col.addView(TextView(ctx).apply {
                text = title
                textSize = 26f
                setTextColor(Color.WHITE)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = ctx.dp(12) })
            fill(fixed)
        } else {
            val input = EditText(ctx).apply {
                hint = "Search"
                setHintTextColor(Color.parseColor("#8E8E93"))
                setTextColor(Color.WHITE)
                textSize = 17f
                isSingleLine = true
                background = ctx.glass(14)
                setPadding(ctx.dp(16), ctx.dp(12), ctx.dp(16), ctx.dp(12))
            }
            fun filtered(q: String) =
                if (q.isBlank()) allApps else allApps.filter { it.label.contains(q.trim(), ignoreCase = true) }
            input.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { fill(filtered(s?.toString().orEmpty())) }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            input.setOnEditorActionListener { _, _, _ ->
                filtered(input.text.toString()).firstOrNull()?.let { launch(it, input); close() }
                true
            }
            col.addView(input, LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = ctx.dp(12) })
            fill(allApps)
            input.postDelayed({
                input.requestFocus()
                (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
                    .showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
            }, 150)
        }
        col.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        scrim.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        scrim.alpha = 0f
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))
        scrim.animate().alpha(1f).setDuration(180).start()
        view = scrim
    }

    fun close() {
        val v = view ?: return
        view = null
        (activity.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(v.windowToken, 0)
        v.animate().alpha(0f).setDuration(140).withEndAction { root.removeView(v) }.start()
    }
}
