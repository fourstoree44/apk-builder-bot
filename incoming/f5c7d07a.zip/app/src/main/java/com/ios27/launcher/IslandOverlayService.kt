package com.ios27.launcher

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.core.content.ContextCompat

/**
 * Menampilkan Dynamic Island di atas semua aplikasi.
 * Butuh izin "Tampil di atas aplikasi lain" (SYSTEM_ALERT_WINDOW).
 */
class IslandOverlayService : Service() {

    private var wm: WindowManager? = null
    private var island: DynamicIslandView? = null
    private var lastCharging: Boolean? = null
    private var receiverRegistered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_BATTERY_CHANGED -> {
                    val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
                    val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                    val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                        status == BatteryManager.BATTERY_STATUS_FULL
                    island?.batteryLevel = if (scale > 0) level * 100 / scale else level
                    island?.charging = charging
                    if (lastCharging != null && lastCharging != charging) island?.pulse()
                    lastCharging = charging
                }
                Intent.ACTION_POWER_CONNECTED, Intent.ACTION_POWER_DISCONNECTED -> island?.pulse()
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_REFRESH) removeIsland()
        if (island == null) {
            if (!Settings.canDrawOverlays(this)) {
                stopSelf()
                return START_NOT_STICKY
            }
            try {
                addIsland()
            } catch (e: Exception) {
                android.util.Log.e("rzkylauncher", "Dynamic Island overlay failed", e)
                removeIsland()
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun addIsland() {
        val d = resources.displayMetrics.density
        val view = DynamicIslandView(this)
        val prefs = getSharedPreferences("island", MODE_PRIVATE)
        val yDp = prefs.getInt("y", 12)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (yDp * d).toInt()
            layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        wm?.addView(view, lp)
        island = view

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
        }
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        receiverRegistered = true
    }

    private fun removeIsland() {
        if (receiverRegistered) {
            try { unregisterReceiver(receiver) } catch (e: Exception) {
                android.util.Log.d("rzkylauncher", "Island receiver already unregistered", e)
            }
            receiverRegistered = false
        }
        island?.let { view ->
            try { wm?.removeView(view) } catch (e: Exception) {
                android.util.Log.d("rzkylauncher", "Island overlay already removed", e)
            }
        }
        island = null
        lastCharging = null
    }

    override fun onDestroy() {
        removeIsland()
        super.onDestroy()
    }

    companion object {
        const val ACTION_REFRESH = "com.ios27.launcher.REFRESH_ISLAND"

        fun start(ctx: Context) {
            if (Settings.canDrawOverlays(ctx)) {
                try {
                    ctx.startService(Intent(ctx, IslandOverlayService::class.java))
                } catch (e: Exception) {
                    android.util.Log.e("rzkylauncher", "Unable to start island service", e)
                }
            }
        }

        /** Dipanggil setelah posisi island diubah. */
        fun refresh(ctx: Context) {
            if (Settings.canDrawOverlays(ctx)) {
                try {
                    ctx.startService(
                        Intent(ctx, IslandOverlayService::class.java).setAction(ACTION_REFRESH)
                    )
                } catch (e: Exception) {
                    android.util.Log.e("rzkylauncher", "Unable to refresh island service", e)
                }
            }
        }
    }
}
