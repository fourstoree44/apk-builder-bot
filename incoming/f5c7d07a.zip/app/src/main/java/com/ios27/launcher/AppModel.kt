package com.ios27.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.provider.MediaStore

data class AppEntry(
    val label: String,
    val pkg: String,
    val component: ComponentName,
    val category: Int
)

/** Semua aplikasi yang punya icon launcher, kecuali launcher ini sendiri. */
fun loadApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(query, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map { ri ->
            val ai = ri.activityInfo
            AppEntry(
                label = ri.loadLabel(pm).toString(),
                pkg = ai.packageName,
                component = ComponentName(ai.packageName, ai.name),
                category = ai.applicationInfo.category
            )
        }
        .sortedBy { it.label.lowercase() }
}

/** Dock: Telepon, Pesan, Browser, Kamera. Kalau tidak ketemu, diisi aplikasi lain. */
fun resolveDock(ctx: Context, apps: List<AppEntry>): List<AppEntry> {
    val pm = ctx.packageManager
    val wanted = listOf(
        Intent(Intent.ACTION_DIAL),
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
        Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER),
        Intent(MediaStore.ACTION_IMAGE_CAPTURE)
    )
    val result = mutableListOf<AppEntry>()
    for (intent in wanted) {
        val pkg = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            ?.activityInfo?.packageName
        val hit = apps.firstOrNull { it.pkg == pkg && result.none { r -> r.pkg == it.pkg } }
        if (hit != null) result += hit
    }
    for (a in apps) {
        if (result.size >= 4) break
        if (result.none { it.pkg == a.pkg }) result += a
    }
    return result.take(4)
}

fun categoryName(a: AppEntry): String = when (a.category) {
    ApplicationInfo.CATEGORY_SOCIAL -> "Sosial"
    ApplicationInfo.CATEGORY_AUDIO,
    ApplicationInfo.CATEGORY_VIDEO,
    ApplicationInfo.CATEGORY_IMAGE -> "Hiburan"
    ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Produktivitas"
    ApplicationInfo.CATEGORY_GAME -> "Game"
    ApplicationInfo.CATEGORY_NEWS -> "Berita"
    ApplicationInfo.CATEGORY_MAPS -> "Perjalanan"
    else -> "Utilitas"
}

val CATEGORY_ORDER = listOf(
    "Sosial", "Hiburan", "Produktivitas", "Game", "Berita", "Perjalanan", "Utilitas"
)

/** Ikon dipotong jadi squircle ala iOS, apa pun bentuk aslinya (bulat, kotak, dsb). */
fun makeIcon(ctx: Context, app: AppEntry, sizePx: Int): Bitmap {
    val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val s = sizePx.toFloat()
    val clip = Path().apply { addRoundRect(RectF(0f, 0f, s, s), s * 0.225f, s * 0.225f, Path.Direction.CW) }
    c.clipPath(clip)
    try {
        val raw = ctx.packageManager.getActivityIcon(app.component)
        val dr = raw.constantState?.newDrawable()?.mutate() ?: raw
        if (dr is AdaptiveIconDrawable) {
            // layer adaptif berukuran 108dp, area aman 72dp: perbesar 1.5x biar penuh
            val ext = (sizePx * 0.25f).toInt()
            dr.background?.let {
                it.setBounds(-ext, -ext, sizePx + ext, sizePx + ext); it.draw(c)
            }
            dr.foreground?.let {
                it.setBounds(-ext, -ext, sizePx + ext, sizePx + ext); it.draw(c)
            }
        } else {
            c.drawColor(Color.WHITE)
            val inset = (sizePx * 0.12f).toInt()
            dr.setBounds(inset, inset, sizePx - inset, sizePx - inset)
            dr.draw(c)
        }
    } catch (e: Exception) {
        c.drawColor(Color.parseColor("#48484A"))
    }
    return bmp
}
