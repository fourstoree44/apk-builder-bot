package com.ios27.launcher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.OvershootInterpolator
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Pill hitam ala Dynamic Island.
 * Ukuran view = ukuran pill saat ini, jadi sentuhan di luar pill tidak ditahan
 * (penting buat overlay di atas aplikasi lain).
 */
class DynamicIslandView(context: Context) : View(context) {

    enum class State { COLLAPSED, COMPACT, EXPANDED }

    private val d = resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())

    private val wCollapsed = 126 * d
    private val hCollapsed = 36 * d
    private val wCompact = 214 * d
    private val hCompact = 36 * d
    private val wExpanded = 352 * d
    private val hExpanded = 148 * d

    private var curW = wCollapsed
    private var curH = hCollapsed
    private var contentAlpha = 0f
    var state = State.COLLAPSED
        private set

    var batteryLevel = 100
        set(v) { field = v.coerceIn(0, 100); invalidate() }
    var charging = false
        set(v) { field = v; invalidate() }

    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val lensPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#14161A") }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8E8E93")
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }
    private val ringBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 6 * d; color = Color.parseColor("#2C2C2E")
        strokeCap = Paint.Cap.ROUND
    }
    private val ringFg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 6 * d; strokeCap = Paint.Cap.ROUND
    }
    private val rect = RectF()
    private val hhmm = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("EEEE, d MMM", Locale.getDefault())

    private var anim: ValueAnimator? = null

    private val autoCollapse = Runnable { setState(State.COLLAPSED) }
    private val tick = object : Runnable {
        override fun run() {
            invalidate()
            handler.postDelayed(this, 15_000)
        }
    }

    init {
        setOnClickListener {
            setState(if (state == State.EXPANDED) State.COLLAPSED else State.EXPANDED)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        handler.post(tick)
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacks(tick)
        handler.removeCallbacks(autoCollapse)
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(curW.toInt(), curH.toInt())
    }

    /** Munculkan mode compact sebentar (misal saat mulai charging). */
    fun pulse(durationMs: Long = 2800) {
        if (state == State.EXPANDED) return
        setState(State.COMPACT)
        handler.removeCallbacks(autoCollapse)
        handler.postDelayed(autoCollapse, durationMs)
    }

    fun setState(target: State, animate: Boolean = true) {
        if (target == state && animate) return
        state = target
        handler.removeCallbacks(autoCollapse)

        val (tw, th) = when (target) {
            State.COLLAPSED -> wCollapsed to hCollapsed
            State.COMPACT -> wCompact to hCompact
            State.EXPANDED -> wExpanded to hExpanded
        }
        val targetAlpha = if (target == State.COLLAPSED) 0f else 1f

        anim?.cancel()
        if (!animate) {
            curW = tw; curH = th; contentAlpha = targetAlpha
            requestLayout(); invalidate()
        } else {
            val fromW = curW; val fromH = curH; val fromA = contentAlpha
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = when (context.getSharedPreferences("island", Context.MODE_PRIVATE).getInt("performance_mode", 1)) {
                    0 -> 180L
                    1 -> 350L
                    else -> 480L
                }
                interpolator = OvershootInterpolator(if (target == State.COLLAPSED) 0.6f else 1.15f)
                addUpdateListener {
                    val p = it.animatedValue as Float
                    curW = fromW + (tw - fromW) * p
                    curH = fromH + (th - fromH) * p
                    val pa = it.animatedFraction
                    contentAlpha = (fromA + (targetAlpha - fromA) * pa).coerceIn(0f, 1f)
                    requestLayout(); invalidate()
                }
                start()
            }
        }
        if (target == State.EXPANDED) handler.postDelayed(autoCollapse, 6000)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = minOf(h / 2f, 40 * d)
        rect.set(0f, 0f, w, h)
        canvas.drawRoundRect(rect, r, r, bodyPaint)

        // lensa kamera depan
        if (state != State.EXPANDED) {
            val cx = w - 18 * d
            canvas.drawCircle(cx, h / 2f, 6 * d, lensPaint)
        }

        val a = (contentAlpha * 255).toInt()
        if (a <= 4) return
        textPaint.alpha = a; subPaint.alpha = a
        ringBg.alpha = a; ringFg.alpha = a

        val green = Color.parseColor("#30D158")
        val levelColor = when {
            charging -> green
            batteryLevel <= 20 -> Color.parseColor("#FF453A")
            else -> Color.WHITE
        }

        when (state) {
            State.COMPACT -> drawCompact(canvas, w, h, levelColor, a)
            State.EXPANDED -> drawExpanded(canvas, w, h, levelColor, a)
            else -> if (contentAlpha > 0.05f && curH > hCollapsed + 2 * d) {
                drawCompact(canvas, w, h, levelColor, a)
            }
        }
    }

    private fun drawCompact(c: Canvas, w: Float, h: Float, levelColor: Int, a: Int) {
        textPaint.textSize = 14 * d
        textPaint.color = Color.WHITE; textPaint.alpha = a
        textPaint.textAlign = Paint.Align.LEFT
        val base = h / 2f - (textPaint.descent() + textPaint.ascent()) / 2f
        c.drawText(hhmm.format(Date()), 18 * d, base, textPaint)

        textPaint.color = levelColor; textPaint.alpha = a
        textPaint.textAlign = Paint.Align.RIGHT
        val label = (if (charging) "⚡" else "") + "$batteryLevel%"
        c.drawText(label, w - 38 * d, base, textPaint)
        textPaint.textAlign = Paint.Align.LEFT
        textPaint.color = Color.WHITE
    }

    private fun drawExpanded(c: Canvas, w: Float, h: Float, levelColor: Int, a: Int) {
        val pad = 24 * d

        textPaint.textAlign = Paint.Align.LEFT
        textPaint.color = Color.WHITE; textPaint.alpha = a
        textPaint.textSize = 38 * d
        c.drawText(hhmm.format(Date()), pad, 62 * d, textPaint)

        subPaint.textSize = 14 * d
        c.drawText(dateFmt.format(Date()), pad, 88 * d, subPaint)

        // cincin baterai
        val size = 64 * d
        val left = w - pad - size
        val top = 30 * d
        rect.set(left, top, left + size, top + size)
        c.drawArc(rect, 0f, 360f, false, ringBg)
        ringFg.color = levelColor; ringFg.alpha = a
        c.drawArc(rect, -90f, 360f * batteryLevel / 100f, false, ringFg)

        textPaint.textSize = 15 * d
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.color = Color.WHITE; textPaint.alpha = a
        val cy = top + size / 2f - (textPaint.descent() + textPaint.ascent()) / 2f
        c.drawText("$batteryLevel", left + size / 2f, cy, textPaint)
        textPaint.textAlign = Paint.Align.LEFT

        // baris status bawah
        subPaint.textSize = 13 * d
        subPaint.color = if (charging) Color.parseColor("#30D158") else Color.parseColor("#8E8E93")
        subPaint.alpha = a
        val status = if (charging) "Sedang mengisi daya" else "Baterai"
        c.drawText(status, pad, h - 24 * d, subPaint)
        subPaint.color = Color.parseColor("#8E8E93")
    }
}
